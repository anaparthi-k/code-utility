from instances.workflows.smart_workflow_instance import SmartWorkflowInstance
from models.references.workflow_parameter_model import WorkflowParameterModel


class WorkflowInstance:
    smart: SmartWorkflowInstance

    def __init__(self, parameter: WorkflowParameterModel):
        self.smart = SmartWorkflowInstance(parameter)
        pass
