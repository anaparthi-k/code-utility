from models.references.workflow_parameter_model import WorkflowParameterModel
from workflows.smart.attachment_workflow import AttachmentWorkflow
from workflows.smart.subsection_workflow import SubsectionWorkflow


class SmartWorkflowInstance:
    attachment: AttachmentWorkflow
    subsection: SubsectionWorkflow

    def __init__(self, parameter: WorkflowParameterModel):
        self.attachment = AttachmentWorkflow(parameter)
        self.subsection = SubsectionWorkflow(parameter)
        pass
