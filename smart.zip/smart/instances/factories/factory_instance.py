from instances.factories.pages.page_factory_instance import PageFactoryInstance
from instances.factories.workflows.workflow_factory_instance import WorkflowFactoryInstance


class FactoryInstance:
    page: PageFactoryInstance
    workflow: WorkflowFactoryInstance

    def __init__(self):
        self.page = PageFactoryInstance()
        self.workflow = WorkflowFactoryInstance()
