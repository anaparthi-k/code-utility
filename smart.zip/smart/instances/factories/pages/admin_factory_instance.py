from factories.pages.admin.manage_user_factory import ManageUserSearchFactory, \
    ManageUserAddFactory
from factories.pages.admin.group_mapping_factory import GroupMappingFactory
from factories.pages.admin.frequency_configuration_factory import FrequencyConfigurationFactory
from factories.pages.admin.scorecard_update_factory import ScorecardUpdateFactory
from factories.pages.admin.notifications_configuration_factory import NotificationsConfigurationSearchFactory, \
    NotificationsConfigurationAddFactory
from factories.pages.admin.smart_configurations_factory import SmartConfigurationsFactory


class AdminFactoryInstance:
    manage_user_search: ManageUserSearchFactory
    manage_user_add: ManageUserAddFactory
    group_mapping: GroupMappingFactory
    frequency_configuration: FrequencyConfigurationFactory
    scorecard_update: ScorecardUpdateFactory
    notification_configuration_search: NotificationsConfigurationSearchFactory
    notification_configuration_add: NotificationsConfigurationAddFactory
    smart_configurations: SmartConfigurationsFactory

    def __init__(self):
        self.manage_user_search = ManageUserSearchFactory()
        self.manage_user_add = ManageUserAddFactory()
        self.group_mapping = GroupMappingFactory()
        self.frequency_configuration = FrequencyConfigurationFactory()
        self.scorecard_update = ScorecardUpdateFactory()
        self.notification_configuration_search = NotificationsConfigurationSearchFactory()
        self.notification_configuration_add = NotificationsConfigurationAddFactory()
        self.smart_configurations = SmartConfigurationsFactory()
