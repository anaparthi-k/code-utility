from factories.pages.non_production_time_tracker.non_production_time_tracker_add_time_factory import \
    NonProductionTimeTrackerAddTimeFactory
from factories.pages.non_production_time_tracker.non_production_time_tracker_search_factory import \
    NonProductionTimeTrackerSearchFactory


class NonProductionTimeTrackerFactoryInstance:
    search: NonProductionTimeTrackerSearchFactory
    add_time: NonProductionTimeTrackerAddTimeFactory

    def __init__(self):
        self.search = NonProductionTimeTrackerSearchFactory()
        self.add_time = NonProductionTimeTrackerAddTimeFactory()
