from factories.pages.scorecard.scorecard_generation_factory import ScorecardGenerationFactory
from factories.pages.scorecard.scorecard_history_factory import ScorecardHistoryFactory


class ScorecardFactoryInstance:
    scorecard_generation: ScorecardGenerationFactory
    scorecard_history: ScorecardHistoryFactory

    def __init__(self):
        self.scorecard_generation = ScorecardGenerationFactory()
        self.scorecard_history = ScorecardHistoryFactory()
