from factories.pages.report.report_factory import ReportFactory


class ReportFactoryInstance:
    report: ReportFactory

    def __init__(self):
        self.report = ReportFactory()
