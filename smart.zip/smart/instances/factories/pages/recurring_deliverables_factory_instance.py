from factories.pages.recurring_deliverables.recurring_deliverables_factory import RecurringDeliverablesFactory
from factories.pages.recurring_deliverables.child_task_section_factory import ChildTaskSectionFactory


class RecurringDeliverablesFactoryInstance:
    creation: RecurringDeliverablesFactory
    child_task: ChildTaskSectionFactory

    def __init__(self):
        self.creation = RecurringDeliverablesFactory()
        self.child_task = ChildTaskSectionFactory()
