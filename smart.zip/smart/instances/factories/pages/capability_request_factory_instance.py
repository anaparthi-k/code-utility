from factories.pages.capability_request.create_capability_request_factory import CreateCapabilityRequestFactory


class CapabilityRequestFactoryInstance:
    create_capability_request: CreateCapabilityRequestFactory

    def __init__(self):
        self.create_capability_request = CreateCapabilityRequestFactory()
