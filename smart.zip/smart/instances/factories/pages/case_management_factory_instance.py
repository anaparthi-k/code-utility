from instances.factories.pages.create_sam_request_factory_instance import CreateSamRequestFactoryInstance
from instances.factories.pages.create_crt_request_factory_instance import CreateCrtRequestFactoryInstance


class CaseManagementFactoryInstance:
    create_sam_request: CreateSamRequestFactoryInstance
    create_crt_request: CreateCrtRequestFactoryInstance

    def __init__(self):
        self.create_sam_request = CreateSamRequestFactoryInstance()
        self.create_crt_request = CreateCrtRequestFactoryInstance()
