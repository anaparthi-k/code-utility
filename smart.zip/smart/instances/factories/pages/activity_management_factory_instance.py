from instances.factories.pages.create_sam_activity_factory_instance import CreateSamActivityFactoryInstance
from instances.factories.pages.create_crt_projects_factory_instance import CreateCrtProjectsFactoryInstance


class ActivityManagementFactoryInstance:
    create_sam_activity: CreateSamActivityFactoryInstance
    create_crt_projects: CreateCrtProjectsFactoryInstance

    def __init__(self):
        self.create_sam_activity = CreateSamActivityFactoryInstance()
        self.create_crt_projects = CreateCrtProjectsFactoryInstance()
