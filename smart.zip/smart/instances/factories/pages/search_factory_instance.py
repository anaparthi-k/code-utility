from factories.pages.search.search_requests_factory import SearchRequestsFactory
from factories.pages.search.search_activities_factory import SearchActivitiesFactory
from factories.pages.search.search_deliverables_factory import SearchDeliverablesFactory
from factories.pages.search.search_capabilities_factory import SearchCapabilitiesFactory
from factories.pages.search.search_value_tracker_requests_factory import SearchValueTrackerRequestsFactory


class SearchFactoryInstance:
    search_requests: SearchRequestsFactory
    search_activities: SearchActivitiesFactory
    search_deliverables: SearchDeliverablesFactory
    search_capabilities: SearchCapabilitiesFactory
    search_value_tracker_requests: SearchValueTrackerRequestsFactory

    def __init__(self):
        self.search_requests = SearchRequestsFactory()
        self.search_activities = SearchActivitiesFactory()
        self.search_deliverables = SearchDeliverablesFactory()
        self.search_capabilities = SearchCapabilitiesFactory()
        self.search_value_tracker_requests = SearchValueTrackerRequestsFactory()
