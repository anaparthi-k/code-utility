from factories.pages.activity_management.create_crt_projects.crt_request_subsection_factory import CrtRequestSubsectionFactory
from factories.pages.activity_management.create_crt_projects.crt_resolution_subsection_factory import CrtResolutionSubsectionFactory
from factories.pages.activity_management.create_crt_projects.group_information_subsection_factory import GroupInformationSubsectionFactory
from factories.pages.activity_management.create_crt_projects.bulk_upload_subsection_factory import BulkUploadSubsectionFactory
from factories.pages.activity_management.create_crt_projects.bp_engagement_details_subsection_factory import BpEngagementDetailsSubsectionFactory
from factories.pages.activity_management.create_crt_projects.additional_info_tracking_subsection_factory import AdditionalInfoTrackingSubsectionFactory
from factories.pages.activity_management.create_crt_projects.root_cause_tracking_subsection_factory import RootCauseTrackingSubsectionFactory
from factories.pages.activity_management.create_crt_projects.post_resolution_subsection_factory import PostResolutionSubsectionFactory
from factories.pages.activity_management.create_crt_projects.adherence_section_subsection_factory import AdherenceSectionSubsectionFactory


class CreateCrtProjectsFactoryInstance:
    crt_request_subsection: CrtRequestSubsectionFactory
    crt_resolution_subsection: CrtResolutionSubsectionFactory
    group_information_subsection: GroupInformationSubsectionFactory
    bulk_upload_subsection: BulkUploadSubsectionFactory
    bp_engagement_details_subsection: BpEngagementDetailsSubsectionFactory
    additional_info_tracking_subsection: AdditionalInfoTrackingSubsectionFactory
    root_cause_tracking_subsection: RootCauseTrackingSubsectionFactory
    post_resolution_subsection: PostResolutionSubsectionFactory
    adherence_section_subsection: AdherenceSectionSubsectionFactory

    def __init__(self):
        self.crt_request_subsection = CrtRequestSubsectionFactory()
        self.crt_resolution_subsection = CrtResolutionSubsectionFactory()
        self.group_information_subsection = GroupInformationSubsectionFactory()
        self.bulk_upload_subsection = BulkUploadSubsectionFactory()
        self.bp_engagement_details_subsection = BpEngagementDetailsSubsectionFactory()
        self.additional_info_tracking_subsection = AdditionalInfoTrackingSubsectionFactory()
        self.root_cause_tracking_subsection = RootCauseTrackingSubsectionFactory()
        self.post_resolution_subsection = PostResolutionSubsectionFactory()
        self.adherence_section_subsection = AdherenceSectionSubsectionFactory()
