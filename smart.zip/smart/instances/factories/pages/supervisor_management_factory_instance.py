from factories.pages.supervisor_management.supervisor_management_factory import SupervisorManagementSearchFactory, \
    SupervisorManagementAddFactory


class SupervisorManagementFactoryInstance:
    supervisor_management_search: SupervisorManagementSearchFactory
    supervisor_management_add: SupervisorManagementAddFactory

    def __init__(self):
        self.supervisor_management_search = SupervisorManagementSearchFactory()
        self.supervisor_management_add = SupervisorManagementAddFactory()
