from instances.factories.pages.home_factory_instance import HomeFactoryInstance
from instances.factories.pages.case_management_factory_instance import CaseManagementFactoryInstance
from instances.factories.pages.activity_management_factory_instance import ActivityManagementFactoryInstance
from instances.factories.pages.search_factory_instance import SearchFactoryInstance
from instances.factories.pages.non_production_time_tracker_factory_instance import NonProductionTimeTrackerFactoryInstance
from instances.factories.pages.admin_factory_instance import AdminFactoryInstance
from instances.factories.pages.supervisor_management_factory_instance import SupervisorManagementFactoryInstance
from instances.factories.pages.recurring_deliverables_factory_instance import RecurringDeliverablesFactoryInstance
from instances.factories.pages.scorecard_factory_instance import ScorecardFactoryInstance
from instances.factories.pages.capability_request_factory_instance import CapabilityRequestFactoryInstance
from instances.factories.pages.report_factory_instance import ReportFactoryInstance


class FactoryFactoryInstance:
    home: HomeFactoryInstance
    case_management: CaseManagementFactoryInstance
    activity_management: ActivityManagementFactoryInstance
    search: SearchFactoryInstance
    non_production_time_tracker: NonProductionTimeTrackerFactoryInstance
    admin: AdminFactoryInstance
    supervisor_management: SupervisorManagementFactoryInstance
    recurring_deliverables: RecurringDeliverablesFactoryInstance
    scorecard: ScorecardFactoryInstance
    capability_request: CapabilityRequestFactoryInstance
    report: ReportFactoryInstance

    def __init__(self):
        self.home = HomeFactoryInstance()
        self.case_management = CaseManagementFactoryInstance()
        self.activity_management = ActivityManagementFactoryInstance()
        self.search = SearchFactoryInstance()
        self.non_production_time_tracker = NonProductionTimeTrackerFactoryInstance()
        self.admin = AdminFactoryInstance()
        self.supervisor_management = SupervisorManagementFactoryInstance()
        self.recurring_deliverables = RecurringDeliverablesFactoryInstance()
        self.scorecard = ScorecardFactoryInstance()
        self.capability_request = CapabilityRequestFactoryInstance()
        self.report = ReportFactoryInstance()
