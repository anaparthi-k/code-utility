from factories.pages.home.home_factory import HomeFactory


class HomeFactoryInstance:
    home: HomeFactory

    def __init__(self):
        self.home = HomeFactory()
