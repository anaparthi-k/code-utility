from factories.pages.case_management.create_sam_request.sam_request_subsection_factory import SamRequestSubsectionFactory
from factories.pages.case_management.create_sam_request.sam_resolution_subsection_factory import SamResolutionSubsectionFactory
from factories.pages.case_management.create_sam_request.member_information_subsection_factory import MemberInformationSubsectionFactory
from factories.pages.case_management.create_sam_request.bp_engagement_details_subsection_factory import BpEngagementDetailsSubsectionFactory
from factories.pages.case_management.create_sam_request.additional_info_tracking_subsection_factory import AdditionalInfoTrackingSubsectionFactory
from factories.pages.case_management.create_sam_request.calltracking_section_subsection_factory import CalltrackingSectionSubsectionFactory
from factories.pages.case_management.create_sam_request.follow_up_needed_subsection_factory import FollowUpNeededSubsectionFactory


class CreateSamRequestFactoryInstance:
    sam_request_subsection: SamRequestSubsectionFactory
    sam_resolution_subsection: SamResolutionSubsectionFactory
    member_information_subsection: MemberInformationSubsectionFactory
    bp_engagement_details_subsection: BpEngagementDetailsSubsectionFactory
    additional_info_tracking_subsection: AdditionalInfoTrackingSubsectionFactory
    calltracking_section_subsection: CalltrackingSectionSubsectionFactory
    follow_up_needed_subsection: FollowUpNeededSubsectionFactory

    def __init__(self):
        self.sam_request_subsection = SamRequestSubsectionFactory()
        self.sam_resolution_subsection = SamResolutionSubsectionFactory()
        self.member_information_subsection = MemberInformationSubsectionFactory()
        self.bp_engagement_details_subsection = BpEngagementDetailsSubsectionFactory()
        self.additional_info_tracking_subsection = AdditionalInfoTrackingSubsectionFactory()
        self.calltracking_section_subsection = CalltrackingSectionSubsectionFactory()
        self.follow_up_needed_subsection = FollowUpNeededSubsectionFactory()
