from instances.factories.workflows.smart_workflow_factory_instance import SmartWorkflowFactoryInstance


class WorkflowFactoryInstance:
    smart: SmartWorkflowFactoryInstance

    def __init__(self):
        self.smart = SmartWorkflowFactoryInstance()
