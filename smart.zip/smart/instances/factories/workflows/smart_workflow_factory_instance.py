from factories.workflows.smart.attachment_workflow_factory import AttachmentWorkflowFactory


class SmartWorkflowFactoryInstance:
    attachment: AttachmentWorkflowFactory

    def __init__(self):
        self.attachment = AttachmentWorkflowFactory()
