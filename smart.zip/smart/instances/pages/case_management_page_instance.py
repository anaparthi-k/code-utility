from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from instances.pages.create_sam_request_page_instance import CreateSamRequestPageInstance
from instances.pages.create_crt_request_page_instance import CreateCrtRequestPageInstance


class CaseManagementPageInstance:
    create_sam_request: CreateSamRequestPageInstance
    create_crt_request: CreateCrtRequestPageInstance

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.create_sam_request = CreateSamRequestPageInstance(driver, converter)
        self.create_crt_request = CreateCrtRequestPageInstance(driver, converter)
