from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.search.search_requests_page import SearchRequestsPage
from pages.search.search_activities_page import SearchActivitiesPage
from pages.search.search_deliverables_page import SearchDeliverablesPage
from pages.search.search_capabilities_page import SearchCapabilitiesPage
from pages.search.search_value_tracker_requests_page import SearchValueTrackerRequestsPage


class SearchPageInstance:
    search_requests: SearchRequestsPage
    search_activities: SearchActivitiesPage
    search_deliverables: SearchDeliverablesPage
    search_capabilities: SearchCapabilitiesPage
    search_value_tracker_requests: SearchValueTrackerRequestsPage

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.search_requests = SearchRequestsPage(driver, converter)
        self.search_activities = SearchActivitiesPage(driver, converter)
        self.search_deliverables = SearchDeliverablesPage(driver, converter)
        self.search_capabilities = SearchCapabilitiesPage(driver, converter)
        self.search_value_tracker_requests = SearchValueTrackerRequestsPage(driver, converter)
