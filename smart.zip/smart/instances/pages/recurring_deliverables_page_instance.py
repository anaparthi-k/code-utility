from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.recurring_deliverables.recurring_deliverables_page import RecurringDeliverablesPage
from pages.recurring_deliverables.child_task_section_page import ChildTaskSectionPage


class RecurringDeliverablesPageInstance:
    creation: RecurringDeliverablesPage
    child_task: ChildTaskSectionPage

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.creation = RecurringDeliverablesPage(driver, converter)
        self.child_task = ChildTaskSectionPage(driver, converter)
