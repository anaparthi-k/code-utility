from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.report.report_page import ReportPage


class ReportPageInstance:
    report: ReportPage

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.report = ReportPage(driver, converter)
