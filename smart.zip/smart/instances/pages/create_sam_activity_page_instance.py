from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.activity_management.create_sam_activity.sam_activity_subsection_page import SamActivitySubsectionPage
from pages.activity_management.create_sam_activity.sam_resolution_subsection_page import SamResolutionSubsectionPage
from pages.activity_management.create_sam_activity.member_information_subsection_page import MemberInformationSubsectionPage
from pages.activity_management.create_sam_activity.bp_engagement_details_subsection_page import BpEngagementDetailsSubsectionPage
from pages.activity_management.create_sam_activity.additional_info_tracking_subsection_page import AdditionalInfoTrackingSubsectionPage
from pages.activity_management.create_sam_activity.calltracking_section_subsection_page import CalltrackingSectionSubsectionPage
from pages.activity_management.create_sam_activity.follow_up_needed_subsection_page import FollowUpNeededSubsectionPage


class CreateSamActivityPageInstance:
    sam_activity_subsection: SamActivitySubsectionPage
    sam_resolution_subsection: SamResolutionSubsectionPage
    member_information_subsection: MemberInformationSubsectionPage
    bp_engagement_details_subsection: BpEngagementDetailsSubsectionPage
    additional_info_tracking_subsection: AdditionalInfoTrackingSubsectionPage
    calltracking_section_subsection: CalltrackingSectionSubsectionPage
    follow_up_needed_subsection: FollowUpNeededSubsectionPage

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.sam_activity_subsection = SamActivitySubsectionPage(driver, converter)
        self.sam_resolution_subsection = SamResolutionSubsectionPage(driver, converter)
        self.member_information_subsection = MemberInformationSubsectionPage(driver, converter)
        self.bp_engagement_details_subsection = BpEngagementDetailsSubsectionPage(driver, converter)
        self.additional_info_tracking_subsection = AdditionalInfoTrackingSubsectionPage(driver, converter)
        self.calltracking_section_subsection = CalltrackingSectionSubsectionPage(driver, converter)
        self.follow_up_needed_subsection = FollowUpNeededSubsectionPage(driver, converter)
