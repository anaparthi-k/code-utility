from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.supervisor_management.supervisor_management_page import SupervisorManagementSearchForm, \
    SupervisorManagementAddForm


class SupervisorManagementPageInstance:
    supervisor_management_search: SupervisorManagementSearchForm
    supervisor_management_add: SupervisorManagementAddForm

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.supervisor_management_search = SupervisorManagementSearchForm(driver, converter)
        self.supervisor_management_add = SupervisorManagementAddForm(driver, converter)
