from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from instances.pages.create_sam_activity_page_instance import CreateSamActivityPageInstance
from instances.pages.create_crt_projects_page_instance import CreateCrtProjectsPageInstance


class ActivityManagementPageInstance:
    create_sam_activity: CreateSamActivityPageInstance
    create_crt_projects: CreateCrtProjectsPageInstance

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.create_sam_activity = CreateSamActivityPageInstance(driver, converter)
        self.create_crt_projects = CreateCrtProjectsPageInstance(driver, converter)
