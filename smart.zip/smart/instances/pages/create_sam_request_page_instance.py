from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.case_management.create_sam_request.sam_request_subsection_page import SamRequestSubsectionPage
from pages.case_management.create_sam_request.sam_resolution_subsection_page import SamResolutionSubsectionPage
from pages.case_management.create_sam_request.member_information_subsection_page import MemberInformationSubsectionPage
from pages.case_management.create_sam_request.bp_engagement_details_subsection_page import BpEngagementDetailsSubsectionPage
from pages.case_management.create_sam_request.additional_info_tracking_subsection_page import AdditionalInfoTrackingSubsectionPage
from pages.case_management.create_sam_request.calltracking_section_subsection_page import CalltrackingSectionSubsectionPage
from pages.case_management.create_sam_request.follow_up_needed_subsection_page import FollowUpNeededSubsectionPage


class CreateSamRequestPageInstance:
    sam_request_subsection: SamRequestSubsectionPage
    sam_resolution_subsection: SamResolutionSubsectionPage
    member_information_subsection: MemberInformationSubsectionPage
    bp_engagement_details_subsection: BpEngagementDetailsSubsectionPage
    additional_info_tracking_subsection: AdditionalInfoTrackingSubsectionPage
    calltracking_section_subsection: CalltrackingSectionSubsectionPage
    follow_up_needed_subsection: FollowUpNeededSubsectionPage

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.sam_request_subsection = SamRequestSubsectionPage(driver, converter)
        self.sam_resolution_subsection = SamResolutionSubsectionPage(driver, converter)
        self.member_information_subsection = MemberInformationSubsectionPage(driver, converter)
        self.bp_engagement_details_subsection = BpEngagementDetailsSubsectionPage(driver, converter)
        self.additional_info_tracking_subsection = AdditionalInfoTrackingSubsectionPage(driver, converter)
        self.calltracking_section_subsection = CalltrackingSectionSubsectionPage(driver, converter)
        self.follow_up_needed_subsection = FollowUpNeededSubsectionPage(driver, converter)
