from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from instances.pages.common_page_instance import CommonPageInstance
from instances.pages.home_page_instance import HomePageInstance
from instances.pages.case_management_page_instance import CaseManagementPageInstance
from instances.pages.activity_management_page_instance import ActivityManagementPageInstance
from instances.pages.search_page_instance import SearchPageInstance
from instances.pages.non_production_time_tracker_page_instance import NonProductionTimeTrackerPageInstance
from instances.pages.admin_page_instance import AdminPageInstance
from instances.pages.supervisor_management_page_instance import SupervisorManagementPageInstance
from instances.pages.recurring_deliverables_page_instance import RecurringDeliverablesPageInstance
from instances.pages.scorecard_page_instance import ScorecardPageInstance
from instances.pages.capability_request_page_instance import CapabilityRequestPageInstance
from instances.pages.report_page_instance import ReportPageInstance


class PageInstance:
    home: HomePageInstance
    common: CommonPageInstance
    case_management: CaseManagementPageInstance
    activity_management: ActivityManagementPageInstance
    search: SearchPageInstance
    non_production_time_tracker: NonProductionTimeTrackerPageInstance
    admin: AdminPageInstance
    supervisor_management: SupervisorManagementPageInstance
    recurring_deliverables: RecurringDeliverablesPageInstance
    scorecard: ScorecardPageInstance
    capability_request: CapabilityRequestPageInstance
    report: ReportPageInstance

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.home = HomePageInstance(driver, converter)
        self.common = CommonPageInstance(driver, converter)
        self.case_management = CaseManagementPageInstance(driver, converter)
        self.activity_management = ActivityManagementPageInstance(driver, converter)
        self.search = SearchPageInstance(driver, converter)
        self.non_production_time_tracker = NonProductionTimeTrackerPageInstance(driver, converter)
        self.admin = AdminPageInstance(driver, converter)
        self.supervisor_management = SupervisorManagementPageInstance(driver, converter)
        self.recurring_deliverables = RecurringDeliverablesPageInstance(driver, converter)
        self.scorecard = ScorecardPageInstance(driver, converter)
        self.capability_request = CapabilityRequestPageInstance(driver, converter)
        self.report = ReportPageInstance(driver, converter)
