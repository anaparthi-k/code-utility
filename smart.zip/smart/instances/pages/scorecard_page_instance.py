from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.scorecard.scorecard_generation_page import ScorecardGenerationPage
from pages.scorecard.scorecard_history_page import ScorecardHistoryPage


class ScorecardPageInstance:
    scorecard_generation: ScorecardGenerationPage
    scorecard_history: ScorecardHistoryPage

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.scorecard_generation = ScorecardGenerationPage(driver, converter)
        self.scorecard_history = ScorecardHistoryPage(driver, converter)
