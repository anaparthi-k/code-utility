from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.admin.manage_user_page import ManageUserSearchForm, ManageUserAddForm
from pages.admin.group_mapping_page import GroupMappingPage
from pages.admin.frequency_configuration_page import FrequencyConfigurationPage
from pages.admin.scorecard_update_page import ScorecardUpdatePage
from pages.admin.notifications_configuration_page import NotificationsConfigurationSearchPage, \
    NotificationsConfigurationAddPage
from pages.admin.smart_configurations_page import SmartConfigurationsPage


class AdminPageInstance:
    manage_user_search: ManageUserSearchForm
    manage_user_add: ManageUserAddForm
    group_mapping: GroupMappingPage
    frequency_configuration: FrequencyConfigurationPage
    scorecard_update: ScorecardUpdatePage
    notification_configuration_search: NotificationsConfigurationSearchPage
    notification_configuration_add: NotificationsConfigurationAddPage
    smart_configurations: SmartConfigurationsPage

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.manage_user_search = ManageUserSearchForm(driver, converter)
        self.manage_user_add = ManageUserAddForm(driver, converter)
        self.group_mapping = GroupMappingPage(driver, converter)
        self.frequency_configuration = FrequencyConfigurationPage(driver, converter)
        self.scorecard_update = ScorecardUpdatePage(driver, converter)
        self.notification_configuration_search = NotificationsConfigurationSearchPage(driver, converter)
        self.notification_configuration_add = NotificationsConfigurationAddPage(driver, converter)
        self.smart_configurations = SmartConfigurationsPage(driver, converter)
