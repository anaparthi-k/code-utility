from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.home.home_page import HomePage


class HomePageInstance:
    home: HomePage

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.home = HomePage(driver, converter)
