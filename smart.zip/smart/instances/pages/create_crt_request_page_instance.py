from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.case_management.create_crt_request.crt_request_subsection_page import CrtRequestSubsectionPage
from pages.case_management.create_crt_request.crt_resolution_subsection_page import CrtResolutionSubsectionPage
from pages.case_management.create_crt_request.group_information_subsection_page import GroupInformationSubsectionPage
from pages.case_management.create_crt_request.bulk_upload_subsection_page import BulkUploadSubsectionPage
from pages.case_management.create_crt_request.bp_engagement_details_subsection_page import BpEngagementDetailsSubsectionPage
from pages.case_management.create_crt_request.additional_info_tracking_subsection_page import AdditionalInfoTrackingSubsectionPage
from pages.case_management.create_crt_request.root_cause_tracking_subsection_page import RootCauseTrackingSubsectionPage
from pages.case_management.create_crt_request.post_resolution_subsection_page import PostResolutionSubsectionPage
from pages.case_management.create_crt_request.adherence_section_subsection_page import AdherenceSectionSubsectionPage


class CreateCrtRequestPageInstance:
    crt_request_subsection: CrtRequestSubsectionPage
    crt_resolution_subsection: CrtResolutionSubsectionPage
    group_information_subsection: GroupInformationSubsectionPage
    bulk_upload_subsection: BulkUploadSubsectionPage
    bp_engagement_details_subsection: BpEngagementDetailsSubsectionPage
    additional_info_tracking_subsection: AdditionalInfoTrackingSubsectionPage
    root_cause_tracking_subsection: RootCauseTrackingSubsectionPage
    post_resolution_subsection: PostResolutionSubsectionPage
    adherence_section_subsection: AdherenceSectionSubsectionPage

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.crt_request_subsection = CrtRequestSubsectionPage(driver, converter)
        self.crt_resolution_subsection = CrtResolutionSubsectionPage(driver, converter)
        self.group_information_subsection = GroupInformationSubsectionPage(driver, converter)
        self.bulk_upload_subsection = BulkUploadSubsectionPage(driver, converter)
        self.bp_engagement_details_subsection = BpEngagementDetailsSubsectionPage(driver, converter)
        self.additional_info_tracking_subsection = AdditionalInfoTrackingSubsectionPage(driver, converter)
        self.root_cause_tracking_subsection = RootCauseTrackingSubsectionPage(driver, converter)
        self.post_resolution_subsection = PostResolutionSubsectionPage(driver, converter)
        self.adherence_section_subsection = AdherenceSectionSubsectionPage(driver, converter)
