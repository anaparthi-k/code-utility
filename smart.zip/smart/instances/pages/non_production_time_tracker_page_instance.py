from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.non_production_time_tracker.non_production_time_tracker_page import NonProductionTimeTrackerAddTimeFrom, \
    NonProductionTimeTrackerSearchForm


class NonProductionTimeTrackerPageInstance:
    # non_production_time_tracker: NonProductionTimeTrackerPage
    search: NonProductionTimeTrackerSearchForm
    add_time: NonProductionTimeTrackerAddTimeFrom

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        # self.non_production_time_tracker = NonProductionTimeTrackerPage(driver, converter)
        self.search = NonProductionTimeTrackerSearchForm(driver, converter)
        self.add_time = NonProductionTimeTrackerAddTimeFrom(driver, converter)
