from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.capability_request.create_capability_request_page import CreateCapabilityRequestPage


class CapabilityRequestPageInstance:
    create_capability_request: CreateCapabilityRequestPage

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.create_capability_request = CreateCapabilityRequestPage(driver, converter)
