from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.common.dialog import Dialog
from pages.common.menu import Menu
from pages.common.attachment_page import AttachmentPage


class CommonPageInstance:
    menu: Menu
    dialog: Dialog
    attachment: AttachmentPage

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self.menu = Menu(driver, converter)
        self.dialog = Dialog(driver, converter)
        self.attachment = AttachmentPage(driver, converter)
