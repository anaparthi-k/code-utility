from verifications.verification import *


class VerificationInstance:
    element: ElementTextVerification
    toaster: ToasterMessageVerification
    pagination: PaginationVerification
    reset: ResetVerification

    def __init__(self, driver: DriverProxy):
        self.element = ElementTextVerification(driver)
        self.toaster = ToasterMessageVerification(driver)
        self.pagination = PaginationVerification(driver)
        self.reset = ResetVerification(driver)
