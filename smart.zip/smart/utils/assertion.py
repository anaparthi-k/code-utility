from datetime import datetime
from logging import Logger
from typing import List
import os.path
from math import isnan

from utils import config_reader
from utils.constants import DATE_FORMAT


class Assertion:
    logger: Logger

    def contains(self, message: str, sub: str) -> bool:
        self.logger.debug(f"Trying to verify the '{sub}' contains '{message}' or equals in '{message}'")
        is_contain = sub.upper() == message.upper() or sub.upper() in message.upper()
        assert is_contain
        return is_contain

    def date_equals(self, expected: datetime, actual: any, message: str) -> bool:
        assert isinstance(expected, datetime)
        self.logger.debug(message)
        self.logger.debug(f"Comparing expected:{str(expected)}")
        self.logger.debug(f"Comparing actual  :{str(actual)}")
        return self._simple_equals(datetime.strftime(expected, DATE_FORMAT), actual)

    def equals(self, expected: any, actual: any, message: str) -> bool:
        self.logger.debug(message)
        self.logger.debug(f"Comparing expected:{str(expected)}")
        self.logger.debug(f"Comparing actual  :{str(actual)}")

        if hasattr(actual, '__iter__') and hasattr(expected, '__iter__'):
            return self._iterator_equals(expected, actual)
        else:
            return self._simple_equals(expected, actual)

    def _simple_equals(self, expected: any, actual: any) -> bool:
        are_equals = expected == actual
        self.logger.debug(f"Result is:{are_equals}")
        assert are_equals
        return are_equals

    def _iterator_equals(self, expected_items: any, actual_items: any) -> bool:
        are_none_types = expected_items is None or actual_items is None

        if are_none_types:
            self.logger.debug(f"Can't compare None with other :{str(expected_items)}")
            return False

        is_not_end = True
        expected = None
        actual = None
        index = 0

        is_matched = len(expected_items) == len(actual_items)

        if not is_matched:
            self.logger.debug(f"Lengths are not matching, expected:{len(expected_items)}, actual:{len(actual_items)}")
            assert False

        expected_items = iter(expected_items)
        actual_items = iter(actual_items)

        while is_matched and is_not_end:
            try:
                expected = next(expected_items)
            except StopIteration:
                is_not_end = False
            try:
                actual = next(actual_items)
            except StopIteration:
                is_not_end = False

            if is_not_end:
                expected_value = self._clean_up(expected)
                actual_value = self._clean_up(actual)
                is_matched = expected_value == actual_value
                if not is_matched:
                    self.logger.debug(f"Matching failed at {index}"
                                      f" expected:{expected_value}, actual:{actual_value}")
                assert is_matched

            index += 1

        return is_matched

    @staticmethod
    def _clean_up(value: any):
        if value is None or isinstance(value, float) and isnan(value):
            value = ''

        if isinstance(value, str):
            value = value.strip()
        else:
            value = str(value)
        return value

    def not_equals(self, expected: any, actual: any, message: str) -> bool:
        are_equals = expected != actual
        self.logger.debug(message)
        self.logger.debug(f"Comparing expected:{str(expected)}")
        self.logger.debug(f"Comparing actual  :{str(actual)}")
        self.logger.debug(f"Result is :{are_equals}")
        assert are_equals
        return are_equals

    def iter_contains(self, expected: any, iterator: any, message: str) -> bool:
        assert hasattr(iterator, '__iter__')
        is_contains = str(expected).lower().strip() in [str(x).lower().strip() for x in iterator]
        self.logger.debug(message)
        self.logger.debug(f"Comparing expected:{expected}")
        self.logger.debug(f"Comparing actual  :{iterator}")
        self.logger.debug(f"Result is :{is_contains}")
        assert is_contains
        return is_contains

    def table_column_with_in_date_range(self,
                                        table: List[List[str]],
                                        column: int,
                                        dt_format: str,
                                        from_date: str,
                                        to_date: str) -> None:
        """Table row parameter type is two dimensional which is red form converter.
        Treating the first row as header row so skipping the first row from comparison process"""
        assert len(table) >= 2
        assert 0 <= column <= len(table[0])
        assert len(dt_format) > 0
        assert len(from_date) > 0
        assert len(to_date) > 0

        self.logger.debug(f"Comparing the table {str(table)}")
        self.logger.debug(f"Date column between {to_date} and {from_date}")

        dt_from = datetime.strptime(from_date, dt_format)
        dt_to = datetime.strptime(to_date, dt_format)
        for i in range(1, len(table)):
            col_value = table[i][column]
            dt_val = datetime.strptime(col_value, dt_format)
            is_between = dt_from <= dt_val <= dt_to
            if not is_between:
                self.logger.debug(f"Verified that column at '{col_value}'"
                                  f" is in not between '{from_date}' and '{to_date}'")
            assert is_between

    def is_file_exist_in_downloads(self, file_name):
        downloads_path = config_reader.config_get("defaults", "local_download_path")
        file_full_path = f'{downloads_path}{file_name}'
        is_exists = os.path.isfile(file_full_path)
        self.logger.debug(f"Verified that '{file_full_path}' is {is_exists and '' or 'not '}exists")
        assert is_exists

    def validate_intersection(self, items_in_assigned, items_in_available):
        intersected_list = [value for value in items_in_assigned if value in items_in_available]
        if len(intersected_list) == 0:
            self.logger.debug("Items moved Successfully")
        else:
            common_elements = str()
            self.logger.debug("These itmes " + common_elements.join(intersected_list) + " not moved")
            assert False
