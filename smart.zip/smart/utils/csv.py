import pandas as pd
from utils.path import Path


def read_csv_file(file_name):
    full_path = Path.get_full_path(file_name)
    data = pd.read_csv(full_path, encoding="utf-8", delimiter=",")
    values = [tuple(x) for x in data.values]
    return values
