import os
from pathlib import Path as PathRef
from utils import config_reader


def clean_file_in_download(file_pattern: str):
    """This is used for creating the directory if not exits"""
    assert file_pattern is not None and len(file_pattern) > 0
    downloads_path = config_reader.config_get("defaults", "local_download_path")
    file_full_pah = f'{downloads_path}{file_pattern}'
    file_paths = PathRef(downloads_path).rglob(file_pattern)
    for file_path in file_paths:
        os.remove(file_path)
