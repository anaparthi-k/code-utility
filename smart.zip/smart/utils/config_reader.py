from configparser import ConfigParser
from utils.path import Path


def config_get(section, key):
    config = ConfigParser()
    root_path = Path.get_full_path('conf.ini')
    config.read(root_path)
    value = config.get(section, key)
    if value is None:
        value = ''
    return value
