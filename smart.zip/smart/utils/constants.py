
DATE_FORMAT = "%m/%d/%Y"
DATE_TIME_FORMAT = "%m/%d/%Y %H:%M:%s"
