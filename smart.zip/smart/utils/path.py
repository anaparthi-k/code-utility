import os


class Path:
    _root_path = None

    @classmethod
    def get_full_path(cls, relative_path: str) -> str:
        """This is used to get full path from relative path"""
        assert relative_path is not None and len(relative_path) > 0
        path = os.path.join(cls._get_root_path(), relative_path)
        return path

    @classmethod
    def _get_root_path(cls) -> str:
        if cls._root_path is None:
            path = os.path.abspath('.')
            print(f"Root path {path}")
            index = path.index("\\SMART_Automation")
            path = path[:index] + "\\SMART_Automation\\"
            cls._root_path = path
        return cls._root_path

    @classmethod
    def create_directory(cls, location: str) -> str:
        """This is used for creating the directory if not exits"""
        assert location is not None and len(location) > 0
        directory_path = os.path.dirname(location)
        if not os.path.exists(directory_path):
            os.makedirs(directory_path)
