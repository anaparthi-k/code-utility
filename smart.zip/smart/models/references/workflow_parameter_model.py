from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from instances.factories.factory_instance import FactoryInstance
from instances.pages.page_instance import PageInstance
from instances.verifications.verification_instance import VerificationInstance
from utils.assertion import Assertion


class WorkflowParameterModel:
    driver: DriverProxy
    converter: DriverElementProxy
    page: PageInstance
    assertion: Assertion
    factory: FactoryInstance
    verification: VerificationInstance
