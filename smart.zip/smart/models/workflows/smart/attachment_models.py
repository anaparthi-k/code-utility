class AddAttachmentModel:
    file_path: str = None
    description: str = None
