class PostResolutionSubsectionModel:
    pass
