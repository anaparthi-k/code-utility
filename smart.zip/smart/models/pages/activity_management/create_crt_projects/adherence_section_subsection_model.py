class AdherenceSectionSubsectionModel:
    pass
