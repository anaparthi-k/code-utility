class AdditionalInfoTrackingSubsectionModel:
    pass
