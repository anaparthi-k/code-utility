class GroupInformationSubsectionModel:
    pass
