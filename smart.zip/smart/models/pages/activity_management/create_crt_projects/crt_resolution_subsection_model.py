class CrtResolutionSubsectionModel:
    pass
