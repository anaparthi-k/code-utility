class RootCauseTrackingSubsectionModel:
    pass
