class BulkUploadSubsectionModel:
    pass
