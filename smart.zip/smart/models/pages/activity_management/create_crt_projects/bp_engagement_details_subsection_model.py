class BpEngagementDetailsSubsectionModel:
    pass
