class MemberInformationSubsectionModel:
    pass
