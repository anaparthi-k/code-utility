class CallTrackingSectionSubsectionModel:
    inboundoutbound: str = None
    person_contacted: str = None
    person_contacted_description: str = None
    date: str = None
    time: str = None
    phone_number: str = None
    call_outcome: str = None
    comments: str = None
