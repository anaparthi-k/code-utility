class SamActivitySubsectionModel:
    activity_id: str = None
    status: str = None
    owner: str = None
    age: str = None
    activity_creation_date: str = None
    activity_category: str = None
    activity_sub_category: str = None
    manager_name: str = None
    activity_subject: str = None
    activity_description: str = None
    resolution_date: str = None
    resolution_comments: str = None
    final_resolution: str = None
