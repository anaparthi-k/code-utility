class SamResolutionSubsectionModel:
    pass
