class AdditionalInfoTrackingSubsectionModel:
    category: str = None
    sub_category: str = None
    tracking_indicator: str = None
    additional_tracking_details: str = None
