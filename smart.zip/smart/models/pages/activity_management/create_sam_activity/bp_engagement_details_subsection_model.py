class BpEngagementDetailsSubsectionModel:
    business_partner: str = None
    routed_status: str = None
    routed_date: str = None
    bp_resolution: str = None
    bp_age: str = None
    routing_option: str = None
    routing_detail: str = None
    sla: str = None
    routed_to_contact: str = None
    reference_numbers: str = None
    description: str = None
    resolution: str = None
    pass
