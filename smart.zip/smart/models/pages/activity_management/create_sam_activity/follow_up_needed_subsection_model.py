class FollowUpNeededSubsectionModel:
    follow_up_date: str = None
    follow_up_status: str = None
    follow_up_owner: str = None
    follow_up_details: str = None
    follow_up_resolution: str = None
