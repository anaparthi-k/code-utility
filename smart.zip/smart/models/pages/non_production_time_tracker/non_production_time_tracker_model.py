class NonProductionTimeTrackerSearchModel:
    user: str = None
    supervisor: str = None
    from_date: str = None
    to_date: str = None
    time_category: str = None
    status: str = None
    all_day: bool = None


class NonProductionTimeTrackerAddFormModel:
    hour: str = None
    time_category: str = None
    comments: str = None

