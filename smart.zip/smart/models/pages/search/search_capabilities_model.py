class SearchCapabilitiesModel:
    request_id: str = None
    title: str = None
    category: str = None
    sub_category: str = None
    impacted_teams: str = None
    submitter: str = None
    from_submitted_date: str = None
    to_submitted_date: str = None
    owner: str = None
    status: str = None
    from_completion_date: str = None
    to_completion_date: str = None
