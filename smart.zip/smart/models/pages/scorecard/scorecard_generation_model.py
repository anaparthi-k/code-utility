from typing import List


class ScorecardGenerationModel:
    year: str = None
    quarter: str = None
    clients: List[str] = None
