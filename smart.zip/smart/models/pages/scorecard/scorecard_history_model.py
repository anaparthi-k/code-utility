class ScorecardHistoryModel:
    from_date: str = None
    to_date: str = None
    customer_name: str = None
