class SmartConfigurationsModel:
    user_name: str = None
    report_type: str = None
