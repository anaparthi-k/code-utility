class GroupMappingModel:
    customer_name: str = None
    metrics: str = None
    name_to_replace: str = None
    new_name: str = None
