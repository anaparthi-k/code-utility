class ScorecardUpdateModel:
    year: str = None
    quarter: str = None
    customer: str = None
    description: str = None
    file_path: str = None
