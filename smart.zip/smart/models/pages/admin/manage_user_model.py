class ManageUserSearchModel:
    ms_id: str = None
    first_name: str = None
    last_name: str = None
    status: str = None


class ManageUserAddModel:
    ms_id: str = None
    first_name: str = None
    last_name: str = None
    email_id: str = None
    status: str = None
    supervisor_ms_id: str = None

