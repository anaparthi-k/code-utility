class FrequencyConfigurationModel:
    customer_name: str = None
    quarter: str = None
    sae: str = None
    csm: str = None
    sam: str = None
    segment_manager: str = None