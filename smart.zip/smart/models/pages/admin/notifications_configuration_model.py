class NotificationsConfigurationSearchModel:
    metric_name: str = None
    key_name: str = None
    customer: str = None


class NotificationsConfigurationAddModel:
    customer_name: str = None
    metric_name: str = None
    key_name: str = None
    upper_threshold: str = None
    lower_threshold: str = None
    value_by: str = None
