class ChildTaskSectionModel:
    child_task_id: str = None
    task_name: str = None
    recurrance_pattern: str = None
    owner: str = None
    task_creation_date: str = None
    task_due_date: str = None
    child_task_status: str = None
    completion_date: str = None
    widgets_count: str = None
    time_to_complete_mins: str = None
    description: str = None
    quality_check: str = None
    date: str = None
    quality_notes: str = None
