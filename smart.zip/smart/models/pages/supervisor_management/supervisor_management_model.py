class SupervisorManagementSearchModel:
    user_name: str = None
    user_role: str = None
    from_date: str = None
    to_date: str = None
    user_full_name: str = None


class SupervisorManagementAddModel:
    user_name: str = None
    supervisor: str = None
    start_date: str = None
    end_date: str = None
    user_full_name: str = None
    supervisor_full_name: str = None
