class ReportModel:
    pass
