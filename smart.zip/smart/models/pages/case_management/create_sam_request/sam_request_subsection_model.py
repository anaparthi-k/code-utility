class SamRequestSubsectionModel:
    pass
