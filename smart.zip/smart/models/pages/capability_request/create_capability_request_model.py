class CreateCapabilityRequestModel:
    pass
