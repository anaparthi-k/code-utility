from faker import Faker
from models.workflows.smart.attachment_models import AddAttachmentModel
from utils.path import Path


class AttachmentWorkflowFactory:
    _faker = Faker()

    def create_add(self):
        form = AddAttachmentModel()
        form.file_path = Path.get_full_path('resources\\smart\\RD\\recurring_deliverables\\add_attachment.jpeg')
        form.description = self._faker.sentence()
        return form

    pass
