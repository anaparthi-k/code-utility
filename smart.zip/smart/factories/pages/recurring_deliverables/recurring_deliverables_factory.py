from faker import Faker
from models.pages.recurring_deliverables.recurring_deliverables_model import RecurringDeliverablesModel
from utils.config_reader import config_get


class RecurringDeliverablesFactory:
    _faker: Faker = Faker()

    def create_save(self) -> RecurringDeliverablesModel:
        model = RecurringDeliverablesModel()
        model.task_status = "Scheduled"
        model.category = "Adherence"
        model.sub_category = "Process"
        model.task_name = self._faker.name()
        model.task_name = self._faker.name()
        model.delivery_method = self._faker.word()
        model.delivery_detail = self._faker.word() + self._faker.word()
        model.description = self._faker.sentence()
        model.owner = config_get('user', 'id')
        return model
