from faker import Faker
from models.pages.recurring_deliverables.child_task_section_model import ChildTaskSectionModel
# from utils.config_reader import config_get


class ChildTaskSectionFactory:
    _faker: Faker = Faker()

    def create_edit(self) -> ChildTaskSectionModel:
        model = ChildTaskSectionModel()
        # model.child_task_id =
        # model.task_name =
        # model.recurrance_pattern =
        # model.owner =
        # model.task_creation_date =
        # model.task_due_date =
        # model.completion_date =
        model.widgets_count = 0
        model.time_to_complete_mins = 30
        model.child_task_status = 'Completed'
        model.description = self._faker.sentence()
        # model.date =
        # model.quality_notes =
        return model
