from faker import Faker
from models.pages.scorecard.scorecard_history_model import ScorecardHistoryModel
from datetime import datetime
from utils import constants


class ScorecardHistoryFactory:
    _faker = Faker

    @staticmethod
    def create_view_history():
        form = ScorecardHistoryModel()
        form.from_date = datetime.today().date().replace(day=1).strftime(constants.DATE_FORMAT)
        form.to_date = datetime.today().date().strftime(constants.DATE_FORMAT)
        form.customer_name = 'ASRS'
        return form
