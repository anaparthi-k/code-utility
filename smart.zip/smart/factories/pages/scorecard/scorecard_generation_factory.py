from faker import Faker
from models.pages.scorecard.scorecard_generation_model import ScorecardGenerationModel


class ScorecardGenerationFactory:
    _faker = Faker()

    @staticmethod
    def create_generate_csv():
        form = ScorecardGenerationModel()
        form.year = '2021'
        form.quarter = 'Q2'
        return form

    def create_generate_single_ppt(self):
        form = self.create_generate_csv()
        form.clients = ['Bank of America']
        return form

    def create_generate_multiple_ppt(self):
        form = self.create_generate_csv()
        form.clients = ['MetLife', 'Bank of America', 'CalPERS']
        return form
