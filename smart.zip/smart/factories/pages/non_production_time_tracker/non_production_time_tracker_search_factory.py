from datetime import datetime
from models.pages.non_production_time_tracker.non_production_time_tracker_model import \
    NonProductionTimeTrackerSearchModel
from utils.constants import DATE_FORMAT
from utils.config_reader import config_get


class NonProductionTimeTrackerSearchFactory:

    @staticmethod
    def create_search():
        form = NonProductionTimeTrackerSearchModel()
        form.user = config_get('user', 'id')
        form.supervisor = ""
        form.from_date = datetime.now().strftime(DATE_FORMAT)
        form.to_date = datetime.now().strftime(DATE_FORMAT)
        form.time_category = "Training"
        form.status = "Approved"
        return form
