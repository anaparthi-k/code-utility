from faker import Faker
from models.pages.non_production_time_tracker.non_production_time_tracker_model import \
    NonProductionTimeTrackerAddFormModel


class NonProductionTimeTrackerAddTimeFactory:
    _faker = Faker()

    def create_add(self):
        form = NonProductionTimeTrackerAddFormModel()
        form.hour = '4'
        form.time_category = "Auditing"
        form.comments = self._faker.sentence()

        return form
