from faker import Faker
from models.pages.home.home_model import HomeModel


class HomeFactory:
    _faker = Faker()
    pass
