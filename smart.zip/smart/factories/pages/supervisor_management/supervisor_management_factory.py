from faker import Faker
from datetime import datetime
from models.pages.supervisor_management.supervisor_management_model import SupervisorManagementSearchModel
from models.pages.supervisor_management.supervisor_management_model import SupervisorManagementAddModel
from utils import constants


class SupervisorManagementSearchFactory:

    @staticmethod
    def create_search():
        form = SupervisorManagementSearchModel()
        form.user_name = 'vkuma459'
        form.user_role = 'User'
        form.user_full_name = 'Kumar, Veeranki (vkuma459)'
        form.from_date = datetime.today().date().replace(day=1).strftime(constants.DATE_FORMAT)
        form.to_date = datetime.today().date().strftime(constants.DATE_FORMAT)
        return form


class SupervisorManagementAddFactory:
    _faker = Faker()

    @staticmethod
    def create_add():
        form = SupervisorManagementAddModel()
        form.user_name = 'vkuma459'
        form.supervisor = 'bavinas4'
        form.user_full_name = 'Kumar,Veeranki (vkuma459)'
        form.supervisor_full_name = 'Avinash,Bussa (bavinas4)'
        form.start_date = datetime.today().date().strftime(constants.DATE_FORMAT)
        return form
