from faker import Faker
from models.pages.capability_request.create_capability_request_model import CreateCapabilityRequestModel


class CreateCapabilityRequestFactory:
    _faker = Faker()
    pass
