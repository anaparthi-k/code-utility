from faker import Faker
from models.pages.report.report_model import ReportModel


class ReportFactory:
    _faker = Faker()
    pass
