from faker import Faker
from models.pages.activity_management.create_crt_projects.bp_engagement_details_subsection_model import BpEngagementDetailsSubsectionModel


class BpEngagementDetailsSubsectionFactory:
    _faker = Faker()
    pass
