from faker import Faker
from models.pages.activity_management.create_crt_projects.crt_resolution_subsection_model import CrtResolutionSubsectionModel


class CrtResolutionSubsectionFactory:
    _faker = Faker()
    pass
