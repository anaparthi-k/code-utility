from faker import Faker
from models.pages.activity_management.create_crt_projects.bulk_upload_subsection_model import BulkUploadSubsectionModel


class BulkUploadSubsectionFactory:
    _faker = Faker()
    pass
