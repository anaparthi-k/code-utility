from faker import Faker
from models.pages.activity_management.create_crt_projects.adherence_section_subsection_model import AdherenceSectionSubsectionModel


class AdherenceSectionSubsectionFactory:
    _faker = Faker()
    pass
