from faker import Faker
from models.pages.activity_management.create_crt_projects.additional_info_tracking_subsection_model import AdditionalInfoTrackingSubsectionModel


class AdditionalInfoTrackingSubsectionFactory:
    _faker = Faker()
    pass
