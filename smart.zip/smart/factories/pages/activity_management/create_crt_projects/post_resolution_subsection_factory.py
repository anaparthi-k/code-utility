from faker import Faker
from models.pages.activity_management.create_crt_projects.post_resolution_subsection_model import PostResolutionSubsectionModel


class PostResolutionSubsectionFactory:
    _faker = Faker()
    pass
