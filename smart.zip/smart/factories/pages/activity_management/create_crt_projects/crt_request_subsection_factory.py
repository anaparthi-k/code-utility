from faker import Faker
from models.pages.activity_management.create_crt_projects.crt_request_subsection_model import CrtRequestSubsectionModel


class CrtRequestSubsectionFactory:
    _faker = Faker()
    pass
