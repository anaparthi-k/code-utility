from faker import Faker
from models.pages.activity_management.create_crt_projects.group_information_subsection_model import GroupInformationSubsectionModel


class GroupInformationSubsectionFactory:
    _faker = Faker()
    pass
