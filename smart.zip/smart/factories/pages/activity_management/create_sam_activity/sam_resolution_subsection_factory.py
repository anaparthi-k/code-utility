from faker import Faker
from models.pages.activity_management.create_sam_activity.sam_resolution_subsection_model import SamResolutionSubsectionModel


class SamResolutionSubsectionFactory:
    _faker = Faker()
    pass
