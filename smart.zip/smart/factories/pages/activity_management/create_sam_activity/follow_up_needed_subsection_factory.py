from faker import Faker
from datetime import datetime
from utils.constants import DATE_FORMAT
from models.pages.activity_management.create_sam_activity.follow_up_needed_subsection_model \
    import FollowUpNeededSubsectionModel


class FollowUpNeededSubsectionFactory:
    _faker = Faker()

    def create_save(self) -> FollowUpNeededSubsectionModel:
        model = FollowUpNeededSubsectionModel()
        model.follow_up_date = datetime.now().strftime(DATE_FORMAT)
        model.follow_up_status = 'Scheduled'
        # model.follow_up_owner = self._faker.name()
        model.follow_up_details = self._faker.sentence()
        model.follow_up_resolution = self._faker.sentence()
        return model

    def create_edit(self) -> FollowUpNeededSubsectionModel:
        model = FollowUpNeededSubsectionModel()
        model.follow_up_date = datetime.now().strftime(DATE_FORMAT)
        model.follow_up_status = 'Inprogress'
        # model.follow_up_owner = self._faker.name()
        model.follow_up_details = self._faker.sentence()
        model.follow_up_resolution = self._faker.sentence()
        return model

    def create_search(self) -> FollowUpNeededSubsectionModel:
        model = FollowUpNeededSubsectionModel()
        model.follow_up_date = self._faker.name()
        model.follow_up_status = self._faker.name()
        model.follow_up_owner = self._faker.name()
        model.follow_up_details = self._faker.name()
        model.follow_up_resolution = self._faker.name()
        return model
    pass
