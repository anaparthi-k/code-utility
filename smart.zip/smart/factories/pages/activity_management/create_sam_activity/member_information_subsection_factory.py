from faker import Faker
from models.pages.activity_management.create_sam_activity.member_information_subsection_model import MemberInformationSubsectionModel


class MemberInformationSubsectionFactory:
    _faker = Faker()
    pass
