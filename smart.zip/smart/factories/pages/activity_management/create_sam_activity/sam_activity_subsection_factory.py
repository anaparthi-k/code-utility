from faker import Faker
from models.pages.activity_management.create_sam_activity.sam_activity_subsection_model import SamActivitySubsectionModel
from models.workflows.smart.attachment_models import AddAttachmentModel
# from datetime import datetime
# from utils.constants import DATE_FORMAT
from utils.path import Path


class SamActivitySubsectionFactory:
    _faker = Faker()

    def create_simple_save(self, creation_date: str) -> SamActivitySubsectionModel:
        assert creation_date is not None and len(creation_date) > 0
        # date_value = datetime.strptime(creation_date, DATE_FORMAT)
        model = SamActivitySubsectionModel()
        # model.activity_id = self._faker.name()
        model.status = 'Open'
        # model.owner = self._faker.name()
        # model.age = self._faker.name()
        # model.activity_creation_date = self._faker.name()
        model.activity_category = 'CTM-Client Remediation '
        model.activity_sub_category = ' CTM Member Outreach'
        # model.manager_name = self._faker.name()
        model.activity_subject = self._faker.sentence()
        model.activity_description = self._faker.sentence()
        # model.resolution_date = self._faker.name()
        # model.resolution_comments = self._faker.name()
        # model.final_resolution = self._faker.name()
        return model

    def create_add_attachment_model(self, file_name: str):
        form = AddAttachmentModel()
        form.file_path = Path.get_full_path(f'resources\\smart\\SAM\\request\\{file_name}')
        form.description = self._faker.sentence()
        return form

    def create_search(self) -> SamActivitySubsectionModel:
        model = SamActivitySubsectionModel()
        model.activity_id = self._faker.name()
        model.status = self._faker.name()
        model.owner = self._faker.name()
        model.age = self._faker.name()
        model.activity_created_date = self._faker.name()
        model.activity_category = self._faker.name()
        model.activity_sub_category = self._faker.name()
        model.manager_name = self._faker.name()
        model.activity_subject = self._faker.name()
        model.activity_description = self._faker.name()
        model.resolution_date = self._faker.name()
        model.resolution_comments = self._faker.name()
        model.final_resolution = self._faker.name()
        return model
