from faker import Faker
from models.pages.activity_management.create_sam_activity.additional_info_tracking_subsection_model import AdditionalInfoTrackingSubsectionModel


class AdditionalInfoTrackingSubsectionFactory:
    _faker = Faker()

    def create_save(self) -> AdditionalInfoTrackingSubsectionModel:
        model = AdditionalInfoTrackingSubsectionModel()
        model.category = 'Ad Hoc'
        model.sub_category = 'Team Lead Involvement'
        model.tracking_indicator = 'Yes'
        model.additional_tracking_details = self._faker.sentence()
        return model

    def create_edit(self) -> AdditionalInfoTrackingSubsectionModel:
        model = AdditionalInfoTrackingSubsectionModel()
        model.category = 'test'
        model.sub_category = 'test_sub'
        model.tracking_indicator = 'simple'
        model.additional_tracking_details = self._faker.sentence()
        return model

    def create_search(self) -> AdditionalInfoTrackingSubsectionModel:
        model = AdditionalInfoTrackingSubsectionModel()
        model.category = self._faker.name()
        model.sub_category = self._faker.name()
        model.tracking_indicator = self._faker.name()
        model.additional_tracking_details = self._faker.name()
        return model

