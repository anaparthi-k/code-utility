from faker import Faker
from models.pages.activity_management.create_sam_activity.bp_engagement_details_subsection_model \
    import BpEngagementDetailsSubsectionModel


class BpEngagementDetailsSubsectionFactory:
    _faker = Faker()

    @staticmethod
    def create_description_validation():
        model = BpEngagementDetailsSubsectionModel()
        model.business_partner = 'AARP Medicare Supplement  (email) (5) '
        return model

    def create_form_data(self):
        model = BpEngagementDetailsSubsectionModel()
        model.business_partner = 'Account Management Team (email) (2) '
        model.routed_to_contact = self._faker.last_name()
        model.description = self._faker.sentense()
        model.resolution = self._faker.sentense()
        return model
    pass
