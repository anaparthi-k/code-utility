from faker import Faker
from datetime import datetime
from models.pages.case_management.create_sam_request.calltracking_section_subsection_model import \
    CallTrackingSectionSubsectionModel
from utils.constants import DATE_FORMAT


class CalltrackingSectionSubsectionFactory:
    _faker : Faker = Faker()

    def create_save(self) -> CallTrackingSectionSubsectionModel:
        model = CallTrackingSectionSubsectionModel()
        model.inboundoutbound = 'Inbound'
        model.person_contacted = self._faker.first_name()
        model.person_contacted_description = 'Client Representative'
        model.date = datetime.now().strftime(DATE_FORMAT)
        v = self._faker.random_int(7,11)
        hours = v<9 and '0'+str(v) or str(v)
        model.time = f'{hours}:{self._faker.random_int(10,59)}AM'
        model.phone_number = self._faker.random_int(111111111,9999999999)
        model.call_outcome = 'Contact Made'
        model.comments = self._faker.sentence()
        return model

    def create_edit(self) -> CallTrackingSectionSubsectionModel:
        model = CallTrackingSectionSubsectionModel()
        model.inboundoutbound = 'Inbound'
        model.person_contacted = self._faker.first_name()
        model.person_contacted_description = 'Member'
        model.date = datetime.now().strftime(DATE_FORMAT)
        model.time = f'{self._faker.random_int(1,6)}:{self._faker.random_int(10,59)}PM'
        model.phone_number = self._faker.random_int(111111111,9999999999)
        model.call_outcome = 'Contact Made'
        model.comments = self._faker.sentence()
        return model

    def create_search(self) -> CallTrackingSectionSubsectionModel:
        model = CallTrackingSectionSubsectionModel()
        model.inboundoutbound = 'Inbound'
        model.person_contacted = self._faker.first_name()
        model.person_contacted_description = 'Client Representative'
        model.date = datetime.now().strftime(DATE_FORMAT)
        model.time = '09:00 AM'
        model.phone_number = self._faker.random_int(111111111,9999999999)
        model.call_outcome = 'Contact Made'
        model.comments = self._faker.sentence()
        return model
