from faker import Faker
from models.pages.case_management.create_sam_request.sam_request_subsection_model import SamRequestSubsectionModel


class SamRequestSubsectionFactory:
    _faker = Faker()
    pass
