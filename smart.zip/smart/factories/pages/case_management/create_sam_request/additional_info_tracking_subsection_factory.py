from faker import Faker
from models.pages.case_management.create_sam_request.additional_info_tracking_subsection_model import \
    AdditionalInfoTrackingSubsectionModel


class AdditionalInfoTrackingSubsectionFactory:
    _faker: Faker = Faker()

    def create_save(self) -> AdditionalInfoTrackingSubsectionModel:
        model = AdditionalInfoTrackingSubsectionModel()
        model.category = 'Ad Hoc'
        model.sub_category = 'Team Lead Involvement'
        model.tracking_indicator = 'Yes'
        model.additional_tracking_details = self._faker.sentence()
        return model

    def create_edit(self) -> AdditionalInfoTrackingSubsectionModel:
        model = AdditionalInfoTrackingSubsectionModel()
        model.category = 'New_Cat'
        model.sub_category = 'New_Sub_Cat'
        model.tracking_indicator = 'NA'
        model.additional_tracking_details = self._faker.sentence()
        return model

    def create_search(self) -> AdditionalInfoTrackingSubsectionModel:
        model = AdditionalInfoTrackingSubsectionModel()
        model.category = self._faker.name()
        model.sub_category = self._faker.name()
        model.tracking_indicator = self._faker.name()
        model.additional_tracking_details = self._faker.name()
        return model
