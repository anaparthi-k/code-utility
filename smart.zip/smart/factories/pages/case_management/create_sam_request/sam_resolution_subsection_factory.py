from faker import Faker
from models.pages.case_management.create_sam_request.sam_resolution_subsection_model import SamResolutionSubsectionModel


class SamResolutionSubsectionFactory:
    _faker = Faker()
    pass
