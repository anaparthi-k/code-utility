from faker import Faker
from models.pages.case_management.create_crt_request.bulk_upload_subsection_model import BulkUploadSubsectionModel


class BulkUploadSubsectionFactory:
    _faker = Faker()
    pass
