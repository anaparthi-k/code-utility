from faker import Faker
from models.pages.case_management.create_crt_request.root_cause_tracking_subsection_model import RootCauseTrackingSubsectionModel


class RootCauseTrackingSubsectionFactory:
    _faker = Faker()
    pass
