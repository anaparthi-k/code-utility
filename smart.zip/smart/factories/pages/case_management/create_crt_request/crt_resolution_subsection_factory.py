from faker import Faker
from models.pages.case_management.create_crt_request.crt_resolution_subsection_model import CrtResolutionSubsectionModel


class CrtResolutionSubsectionFactory:
    _faker = Faker()
    pass
