from faker import Faker
from models.pages.case_management.create_crt_request.adherence_section_subsection_model import AdherenceSectionSubsectionModel


class AdherenceSectionSubsectionFactory:
    _faker = Faker()
    pass
