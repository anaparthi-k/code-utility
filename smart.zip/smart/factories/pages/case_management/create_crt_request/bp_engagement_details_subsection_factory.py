from faker import Faker
from models.pages.case_management.create_crt_request.bp_engagement_details_subsection_model import BpEngagementDetailsSubsectionModel


class BpEngagementDetailsSubsectionFactory:
    _faker = Faker()
    pass
