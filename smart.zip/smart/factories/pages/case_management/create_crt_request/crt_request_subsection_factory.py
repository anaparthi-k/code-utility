from faker import Faker
from models.pages.case_management.create_crt_request.crt_request_subsection_model import CrtRequestSubsectionModel


class CrtRequestSubsectionFactory:
    _faker = Faker()
    pass
