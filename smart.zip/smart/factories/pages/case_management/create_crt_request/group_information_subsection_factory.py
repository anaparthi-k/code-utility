from faker import Faker
from models.pages.case_management.create_crt_request.group_information_subsection_model import GroupInformationSubsectionModel


class GroupInformationSubsectionFactory:
    _faker = Faker()
    pass
