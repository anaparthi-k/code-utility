from faker import Faker
from models.pages.case_management.create_crt_request.additional_info_tracking_subsection_model import AdditionalInfoTrackingSubsectionModel


class AdditionalInfoTrackingSubsectionFactory:
    _faker = Faker()
    pass
