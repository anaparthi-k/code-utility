from faker import Faker
from datetime import datetime
from models.pages.search.search_capabilities_model import SearchCapabilitiesModel
from utils.constants import DATE_FORMAT


class SearchCapabilitiesFactory:
    _faker = Faker()

    def create_capabilities_search(self) -> SearchCapabilitiesModel:
        model = SearchCapabilitiesModel()
        today = datetime.now().strftime(DATE_FORMAT)

        model.request_id = 'CAPR_273'
        model.title = 'test'
        model.category = 'GRIP'
        model.sub_category = 'Access issue'
        model.impacted_teams = 'Group Retiree SAM'
        model.submitter = 'Kumar'
        model.from_submitted_date = today
        model.to_submitted_date = today
        model.owner = 'Kumar'
        model.status = 'In Progress'
        model.from_completion_date = today
        model.to_completion_date = today
        return model