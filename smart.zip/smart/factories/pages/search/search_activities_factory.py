from datetime import datetime
from faker import Faker
from models.pages.search.search_activities_model import *
from utils.constants import DATE_FORMAT


class SearchActivitiesFactory:
    _faker = Faker()

    def create_sact_search(self):
        model = SamSearchActivityModel()
        today = datetime.now().strftime(DATE_FORMAT)

        model.search_type = 'SAM Activity'
        model.activity_id = 'SACT_' + str(self._faker.random_int(1, 100))
        model.bp_tracking_id = self._faker.random_int(1, 100)
        model.call_tracking_id = self._faker.random_int(1, 100)
        model.follow_up_id = self._faker.random_int(1, 100)
        model.owner = 'Pramod'
        model.activity_status = 'Open'
        model.from_created_date = today
        model.to_created_date = today
        model.from_resolution_date = today
        model.to_resolution_date = today
        model.from_bp_routed_date = today
        model.to_bp_routed_date = today
        model.from_call_tracking_date = today
        model.to_call_tracking_date = today
        model.from_follow_up_date = today
        model.to_follow_up_date = today
        model.business_partner = 'AARP Medicare Supplement (email) (5)'
        model.business_partner_routed_status = 'Routed'
        model.inbound_outbound = 'Inbound'
        model.additional_tracking_category = 'Ad Hoc'
        model.member_id = self._faker.random_int(100000000, 999999999)
        model.member_first_name = self._faker.first_name()
        model.member_last_name = self._faker.last_name()
        model.group_name = self._faker.word()
        return model

    def create_cact_search(self):
        model = CrtSearchActivityModel()
        today = datetime.now().strftime(DATE_FORMAT)

        model.search_type = 'CRT Projects'
        model.activity_id = 'CACT_' + str(self._faker.random_int(1, 100))
        model.bp_tracking_id = self._faker.random_int(1, 100)
        model.follow_up_id = self._faker.random_int(1, 100)
        model.owner = 'Pramod'
        model.activity_status = 'Open'
        model.from_created_date = today
        model.to_created_date = today
        model.from_resolution_date = today
        model.to_resolution_date = today
        model.from_bp_routed_date = today
        model.to_bp_routed_date = today
        model.from_follow_up_date = today
        model.to_follow_up_date = today
        model.business_partner = 'A&G (email) (5)'
        model.business_partner_routed_status = 'Routed'
        model.root_cause_category = 'Ancillary'
        model.root_cause_sub_category = 'File - Reporting error'
        model.group_name = self._faker.word()
        model.gps_employer_id = self._faker.random_int(1, 1000)
        return model
