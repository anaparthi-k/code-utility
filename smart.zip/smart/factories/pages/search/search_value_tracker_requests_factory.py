from faker import Faker
from datetime import datetime
from models.pages.search.search_value_tracker_requests_model import SearchValueTrackerRequestsModel
from utils.constants import DATE_FORMAT


class SearchValueTrackerRequestsFactory:
    _faker = Faker()

    def create_value_tracker_requests_search(self) -> SearchValueTrackerRequestsModel:
        model = SearchValueTrackerRequestsModel()
        today = datetime.now().strftime(DATE_FORMAT)

        model.request_id = 'VAL_68'
        model.bp_tracking_id = '553'
        model.follow_up_id = '428'
        model.owner = 'vkuma459'
        model.owner_team = 'Audit Manager'
        model.request_status = 'InProgress'
        model.requested_by_area = 'testing area'
        model.group_name = 'Emigrant Bank'
        model.from_start_date = today
        model.to_start_date = today
        model.from_completion_date = today
        model.to_completion_date = today
        model.from_bp_routed_date = today
        model.to_bp_routed_date = today
        model.from_follow_up_date = today
        model.to_follow_up_date = today
        model.business_partner = 'Team Performance and Capabilities (email) (2)'
        model.business_partner_routed_status = 'Routed'
        model.additional_tracking_category = 'Quality Tracking'
        return model