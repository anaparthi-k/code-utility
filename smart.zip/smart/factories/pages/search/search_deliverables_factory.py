from faker import Faker
from models.pages.search.search_deliverables_model import SearchDeliverablesModel


class SearchDeliverablesFactory:
    _faker = Faker()
    pass
