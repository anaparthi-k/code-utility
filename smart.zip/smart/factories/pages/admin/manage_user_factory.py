from faker import Faker
from models.pages.admin.manage_user_model import ManageUserAddModel, ManageUserSearchModel


class ManageUserSearchFactory:

    @staticmethod
    def create_search():
        form = ManageUserSearchModel()
        form.ms_id = 'vkuma459'
        form.first_name = 'Veeranki'
        form.last_name = 'Kumar'
        form.status = 'Active'
        return form


class ManageUserAddFactory:
    _faker = Faker()

    @staticmethod
    def create_add():
        form = ManageUserAddModel()
        form.ms_id = 'vkuma459'
        form.first_name = 'Veeranki'
        form.last_name = 'Kumar'
        form.email_id = 'kumar_veeranki@optum.com'
        form.status = 'Active'
        return form

