from faker import Faker
from models.pages.admin.scorecard_update_model import ScorecardUpdateModel


class ScorecardUpdateFactory:
    _faker = Faker()

    @staticmethod
    def create_search():
        form = ScorecardUpdateModel()
        form.customer = 'CalPERS'
        form.year = '2021'
        form.quarter = 'Q1'
        return form

    def create_upload(self, path: str):
        form = self.create_search()
        form.description = self._faker.sentence(nb_words=4)
        form.file_path = path
        return form
