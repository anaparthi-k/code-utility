from faker import Faker
from models.pages.admin.frequency_configuration_model import FrequencyConfigurationModel


class FrequencyConfigurationFactory:
    _faker = Faker()

    @staticmethod
    def create_search():
        form = FrequencyConfigurationModel()
        form.customer_name = 'ASRS'
        form.quarter = 'Quarterly'
        return form

    def create_update(self):
        form = self.create_search()
        form.sae = self._faker.name()
        return form

    def create_save(self):
        form = FrequencyConfigurationModel()
        form.customer_name = 'ASRS'
        form.quarter = 'Quarterly'
        return form

