from faker import Faker
from models.pages.admin.group_mapping_model import GroupMappingModel


class GroupMappingFactory:
    _faker = Faker()

    @staticmethod
    def create_search():
        form = GroupMappingModel()
        form.customer_name = "ASRS"
        form.metrics = "Call Drivers"
        return form

    def create_map_to_group_name(self):
        form = self.create_search()
        form.name_to_replace = self._faker.name()
        return form

    def create_update(self):
        form = GroupMappingModel
        form.name_to_replace = self._faker.name()
        return form
