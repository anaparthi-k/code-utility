from models.pages.admin.smart_configurations_model import SmartConfigurationsModel
# from utils.constants import DATE_FORMAT
# from utils.config_reader import config_get


class SmartConfigurationsFactory:

    @staticmethod
    def create_search():
        form = SmartConfigurationsModel()
        form.user_name = "vkuma459"
        form.report_type = "Adherence Reports"
        return form

