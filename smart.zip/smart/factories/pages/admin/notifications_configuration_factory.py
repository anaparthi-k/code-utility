from models.pages.admin.notifications_configuration_model import NotificationsConfigurationSearchModel, \
    NotificationsConfigurationAddModel


class NotificationsConfigurationSearchFactory:

    @staticmethod
    def create_search():
        form = NotificationsConfigurationSearchModel()
        form.metric_name = 'A4me'
        form.key_name = 'A4O (Total Opportunities)'
        form.customer = 'ASRS'
        return form


class NotificationsConfigurationAddFactory:

    @staticmethod
    def create_add():
        form = NotificationsConfigurationAddModel()
        form.customer_name = 'ASRS'
        form.metric_name = 'A4me'
        form.key_name = 'A4O (Total Opportunities)'
        form.upper_threshold = '40'
        form.lower_threshold = '10'
        form.value_by = 'Count'
        return form
