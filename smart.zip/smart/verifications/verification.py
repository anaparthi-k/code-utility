from datetime import datetime
from typing import Callable

from core.driver_proxy import DriverProxy
from pages.common.pagination import Pagination
from pages.common.form_container import FormContainer
from utils.config_reader import config_get
from verifications.verification_base import VerificationBase


class ElementTextVerification(VerificationBase):

    def __init__(self, driver: DriverProxy):
        super().__init__(driver)

    def validate(self, value: str):
        assert value is not None and len(value) > 0
        self._driver.check_element_is_present('text found in the pages',
                                              f"//*[contains(text(),'{value}')]")
        pass


class ToasterMessageVerification(VerificationBase):

    def __init__(self, driver: DriverProxy):
        super().__init__(driver)

    def equals(self, value: str):
        assert value is not None and len(value) > 0
        text = self._driver.get_toaster_message_text()
        self.logger.debug(f"Verify that {repr(value)} equals with toaster message:{repr(text)}")
        assert text == value

    def contains(self, value: str):
        assert value is not None and len(value) > 0
        text = self._driver.get_toaster_message_text()
        self.logger.debug(f"Verify that '{value}' contains with toaster message:{repr(text)}")
        assert text.lower().__contains__(value.lower())

    def validate_at(self, index: int, value: str):
        assert value is not None and len(value) > 0
        text = self._driver.get_toaster_message_text(index=index)
        self.logger.debug(f"Verify that {repr(value)} equals with toaster message:{repr(text)}")
        assert text == value

    def validate_contains_in_any(self, value: str):
        assert value is not None and len(value) > 0
        messages = self._driver.get_all_toaster_messages_text()
        self.logger.debug(f"Verify that {repr(value)} equals with any of the toaster messages:{repr(messages)}")
        assert messages.index(value) >= 0

    def validate_any_list_item(self, value: str):
        assert value is not None and len(value) > 0
        messages = self._driver.get_all_toaster_messages_text_list()
        # actual_msg_text = [repr(text) for text in messages]
        self.logger.debug(f"Verify that {repr(value)} equals with any of the toaster messages:'{messages}'")
        assert messages.index(value) >= 0


class PaginationVerification(VerificationBase):

    def __init__(self, driver: DriverProxy):
        super().__init__(driver)

    def validate_equals(self, page: Pagination, column: int, value: str):

        def compare(col_value: str) -> bool:
            return col_value == value

        invalid_msg = "Verified that '{value}' is not equals to '" + value + "' at '{page}' page"

        self._validate(page, column, compare, invalid_msg)

        self.logger.debug(f"Verified that {column} column in all pages is equals to '{value}'")

    def validate_contains(self, page: Pagination, column: int, value: str):

        def compare(col_value: str) -> bool:
            return col_value.lower().__contains__(value.lower())

        invalid_msg = "Verified that '{value}' is not contains to '" + value + "' at '{page}' page"

        self._validate(page, column, compare, invalid_msg)

        self.logger.debug(f"Verified that {column} column in all pages contains '{value}'")

    def validate_not_equals(self, page: Pagination, column: int, value: str):

        def compare(col_value: str) -> bool:
            return col_value != value

        invalid_msg = "Verified that '{value}' is equals to '" + value + "' at '{page}' page"

        self._validate(page, column, compare, invalid_msg)

        self.logger.debug(f"Verified that {column} column in all pages is not equals to '{value}'")

    def validate_date_range(self, page: Pagination, column: int,
                            dt_format: str,
                            from_date: str,
                            to_date: str):

        dt_from = datetime.strptime(from_date, dt_format)
        dt_to = datetime.strptime(to_date, dt_format)

        def compare(col_value: str) -> bool:
            dt_val = datetime.strptime(col_value, dt_format)
            return dt_from <= dt_val <= dt_to

        invalid_msg = "Verified that column at '{value}' is in not between " \
                      + from_date + "' and '" + to_date + "' at '{page}' page"

        self._validate(page, column, compare, invalid_msg)

        self.logger.debug(f'Verified that {column} column in all pages is in between {from_date} and {to_date}')

        self.logger.debug(f"Verified that {column} column in all pages "
                          f"is in between '{from_date}' and '{to_date}'")

    def _validate(self, page: Pagination, column: int, compare: any, invalid_msg_format: str):
        assert column >= 0
        assert compare is not None
        assert invalid_msg_format is not None and isinstance(invalid_msg_format, str)

        total_page = page.get_last_page_number()
        max_page_size = total_page

        default_size = config_get('defaults', 'page_verification_size')
        if len(default_size) > 0:
            max_page_size = min(int(default_size), max_page_size)

        self.logger.debug(f"Trying to validate {max_page_size} page out of {total_page} pages")

        for page_no in range(max_page_size):
            if page_no > 0:
                page.click_on_next()
            current_page = page_no + 1
            self.logger.debug(f"Validating page {current_page}")
            table = page.get_data()
            for i in range(1, len(table)):
                col_value = table[i][column]
                if col_value is None:
                    col_value = ''
                is_matched = bool(compare(col_value))
                if not is_matched:
                    self.logger.debug(f"Current row values are:{table[i]}")
                    self.logger.debug(invalid_msg_format.format(page=current_page, value=col_value))
                assert is_matched


class ResetVerification(VerificationBase):

    def __init__(self, driver: DriverProxy):
        super().__init__(driver)

    def validate(self, container: FormContainer, enter_form_data_action: Callable):

        assert isinstance(container, FormContainer)
        assert callable(enter_form_data_action)

        container.click_on_reset_button()
        before_data = container.get_data()
        enter_form_data_action()
        container.click_on_reset_button()
        after_data = container.get_data()
        from utils.assertion import Assertion
        assertion = Assertion()
        assertion.logger = self.logger
        assertion.equals(before_data, after_data, 'Validating reset form data equality')
