import logging

from core.driver_proxy import DriverProxy


class VerificationBase:
    _driver: DriverProxy
    logger: logging.Logger = None

    def __init__(self, driver: DriverProxy):
        self._driver = driver
