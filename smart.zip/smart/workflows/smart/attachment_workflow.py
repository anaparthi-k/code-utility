from models.references.workflow_parameter_model import WorkflowParameterModel
from models.workflows.smart.attachment_models import AddAttachmentModel
from workflows.workflow_base import WorkflowBase


class AttachmentWorkflow(WorkflowBase):

    def __init__(self, parameter: WorkflowParameterModel):
        super().__init__(parameter)

    def verify_attachment_is_uploaded(self, form: AddAttachmentModel):
        page = self._page.common.attachment
        page.click_on_more_links()
        page.click_on_attachments()
        page.click_on_add_attachment()
        page.browse_file(form.file_path)
        page.enter_description(form.description)
        page.click_on_upload()
        self._verification.toaster.equals('Success\nUploaded Successfully')
        page.click_on_close()

    def verify_attachment_is_delete(self, file_path: str):
        page = self._page.common.attachment
        page.click_on_more_links()
        page.click_on_attachments()
        page.click_on_delete_document(file_path)
        self._page.common.dialog.click_yes_button()
        self._verification.toaster.equals('Success\nFile deleted Successfully')
        page.click_on_close()
