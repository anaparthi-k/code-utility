from models.references.workflow_parameter_model import WorkflowParameterModel
from pages.common.pagination import Pagination
from pages.common.subsection_page import SubsectionPage
from workflows.workflow_base import WorkflowBase


class SubsectionWorkflow(WorkflowBase):

    def __init__(self, parameter: WorkflowParameterModel):
        super().__init__(parameter)

    def verify_form_saved(self, page: SubsectionPage, form: any, msg: str):
        self.save_form(page, form)
        self._driver.wait_till_spinner_off()
        self._verification.toaster.contains(msg)
        pass

    def verify_form_edit(self, page: SubsectionPage, form: any, edit_value: str, msg: str) -> None:
        assert edit_value is not None and len(edit_value) > 0
        assert msg is not None and len(msg) > 0

        if not page.is_table_section_expanded():
            page.click_on_table_expand_button()
        page.click_on_table_edit_button(edit_value)

        self.verify_form_saved_with_spinner(page, form, msg)
        pass

    def verify_form_saved_with_spinner(self, page: SubsectionPage, form: any, msg: str):
        self.save_form(page, form)
        self._driver.wait_till_spinner_off()
        self._verification.toaster.contains(msg)
        pass
   
    def verify_form_delete(self, page: SubsectionPage, value: str, dialog_text: str, msg: str):
        assert value is not None and len(value) > 0
        assert msg is not None and len(msg) > 0

        if not page.is_table_section_expanded():
            page.click_on_table_expand_button()
        page.click_on_table_delete_button(value)
        self._assertion.equals(dialog_text, self._page.common.dialog.get_text(),
                               'Delete alert dialog box text validation')
        self._page.common.dialog.click_yes_button()
        # self._driver.wait_till_spinner_off()
        self._verification.toaster.contains(msg)
        pass

    @staticmethod
    def save_form(page: SubsectionPage, form: any):
        assert isinstance(page, SubsectionPage)
        if not page.is_form_section_expanded():
            page.click_on_form_expand_button()
        page.fill_form(form)
        page.click_on_save_button()
        pass

    def verify_form_reset(self, page: SubsectionPage, form: any):
        if not page.is_form_section_expanded():
            page.click_on_form_expand_button()
        page.click_on_reset_button()
        before_data = page.get_form_data()
        page.fill_form(form)
        page.click_on_reset_button()
        after_data = page.get_form_data()
        self._assertion.equals(before_data, after_data, 'Validating reset form data equality')
        pass

    def get_pagination_by_search(self, page: SubsectionPage, form: any) -> Pagination:
        assert isinstance(page, SubsectionPage)
        if not page.is_form_section_expanded():
            page.click_on_form_expand_button()
        page.click_on_reset_button()
        page.fill_form(form)
        page.click_on_search_button()
        pagination = page.create_pagination()
        pagination.logger = self.logger
        return pagination
