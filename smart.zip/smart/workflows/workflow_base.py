import logging
from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from instances.factories.pages.page_factory_instance import PageFactoryInstance
from instances.pages.page_instance import PageInstance
from instances.verifications.verification_instance import VerificationInstance
from models.references.workflow_parameter_model import WorkflowParameterModel
from utils.assertion import Assertion


class WorkflowBase:
    logger: logging.Logger = None
    _driver: DriverProxy
    _converter: DriverElementProxy
    _page: PageInstance
    _assertion: Assertion
    _factory: PageFactoryInstance
    _verification: VerificationInstance

    def __init__(self, parameter: WorkflowParameterModel):
        self._driver = parameter.driver
        self._converter = parameter.converter
        self._page = parameter.page
        self._assertion = parameter.assertion
        self._factory = parameter.factory
        self._verification = parameter.verification
