import logging
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.support.select import Select
from typing import List


class DriverElementProxy:
    logger: logging.Logger

    def __init__(self, driver: WebDriver) -> None:
        assert isinstance(driver, WebDriver)
        self._driver = driver

    def table_to_array(self, container_xpath: str) -> List[List[str]]:
        """ This is used to convert an element of context at table container to convert into two dimensional array.

        :param container_xpath:
        :return: table in the container to two dimensional array.
        """
        assert isinstance(container_xpath, str)
        container_element = self._driver.find_element_by_xpath(container_xpath)
        table = container_element.find_element_by_xpath('.//table')
        table_data = list()

        headers = table.find_elements_by_xpath("./thead/*/th")
        header_item = list()
        for header in headers:
            header_text = header.get_attribute('innerText')
            header_item.append(header_text)

        table_data.append(header_item)

        rows = table.find_elements_by_xpath("./tbody/tr")
        for row in rows:
            cells = row.find_elements_by_xpath('./td')
            row_item = list()
            for cell in cells:
                cell_text = cell.get_attribute('innerText')
                row_item.append(cell_text)
            table_data.append(row_item)

        return table_data

    def table_row_at_to_array(self, container_xpath: str, index: int) -> List[str]:
        """ This is used to convert an particular row in array.

        :param container_xpath: pass xpath where table structure contains.
        :param index: pass the index value from 1.
        :return: table in the container to two dimensional array.
        """
        assert index > 0
        assert isinstance(container_xpath, str)
        container_element = self._driver.find_element_by_xpath(container_xpath)
        table = container_element.find_element_by_xpath('.//table')
        try:
            row = table.find_element_by_xpath(f"./tbody/tr[{index}]")

            cells = row.find_elements_by_xpath('./td')
            row_item = list()
            for cell in cells:
                cell_text = cell.get_attribute('innerText')
                row_item.append(cell_text)
            return row_item
        except NoSuchElementException:
            self.logger.debug("Failed to load the row data due to invalid path")
        except Exception as e:
            self.logger.debug(f"Failed to load the row data due to {str(e)}")
            self.logger.error(f"Failed to load the row data due to {str(e)}", exc_info=e)
        return list()

    def fields_to_tuple(self, container_xpath: str):
        """This method is user helps to convert form to tuple with dropdown as text

        :parameter container_xpath: Pass form container path
        :return : all input, select fields into tuple
        """
        form: List[str] = []
        container = self._driver.find_element_by_xpath(container_xpath)
        inputs = container.find_elements_by_xpath(".//input")

        for input_element in inputs:
            if input_element.get_attribute('type').lower() == 'radio' or \
                    input_element.get_attribute('type').lower() == 'checkbox':
                value = bool(input_element.get_attribute('checked'))
            else:
                value = input_element.get_attribute('value')
            form.append(value)

        select_elements = container.find_elements_by_xpath(".//select")
        for select_element in select_elements:
            select = Select(select_element)
            selected_options = select.all_selected_options
            value = ''
            if len(selected_options) > 0:
                value = selected_options[0].text
            form.append(value)

        textarea_elements = container.find_elements_by_xpath(".//textarea")
        for textarea_element in textarea_elements:
            value = textarea_element.get_attribute('value')
            form.append(value)

        self.logger.debug(f"Form data in a container {container_xpath} is '{str(form)}'")
        return tuple(form)

    def elements_text_to_array(self, elements_xpath) -> List[str]:
        """This method used to capture elements in a table and store them into a list"""

        assert isinstance(elements_xpath, str)
        elements = self._driver.find_elements_by_xpath(elements_xpath)
        elements_text = []
        for item in elements:
            elements_text.append(item.get_attribute('innerText'))

        return elements_text
