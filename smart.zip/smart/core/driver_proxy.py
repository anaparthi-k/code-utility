import logging
import time
from datetime import datetime
from typing import List, Callable
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.select import Select
from utils.path import Path


class DriverProxy:
    logger: logging.Logger

    def __init__(self, driver: WebDriver) -> None:
        assert isinstance(driver, WebDriver)
        self._driver = driver

    def wait_till(self, action: Callable[[WebDriver], bool], time_out_secs: int = 120):
        assert callable(action)
        wait = WebDriverWait(self._driver, time_out_secs)
        try:
            wait.until(action,message='Failed to met the expected condition')
        # except Exception as e:
        #     self.logger.debug(f"Exception raised due to {e}")
        finally:
            pass

    def wait_till_spinner_off(self, time_out_secs: int = 120) -> None:
        spinner_xpath = '//*[@id="BusyIndicator"]'
        if self.is_exists(spinner_xpath):
            self.logger.debug("Waiting for spinner to unload")
            wait = WebDriverWait(self._driver, time_out_secs)
            try:
                wait.until(expected_conditions.invisibility_of_element((By.XPATH, spinner_xpath)))
            finally:
                self.logger.debug(f"Spinner is unloaded")
                pass
        else:
            self.logger.debug("Spinner is not present in the page")

    def wait_till_not_exists(self, xpath: str, name: str, time_out_secs: int = 30) -> None:
        self.logger.debug(f"Waiting for {name} to unload")
        wait = WebDriverWait(self._driver, time_out_secs)
        try:
            wait.until(expected_conditions.invisibility_of_element((By.XPATH, xpath)))
        except Exception as e:
            self.logger.error(f"{name} is already unload due to {str(e)}", exc_info=e)
            self.logger.debug(f"{name} is already unload due to {str(e)}")
            pass

    def get_toaster_message_text(self, index=1, time_out_secs: int = 30) -> str:
        self.logger.debug("Waiting for toaster to load")
        toaster_path = f"//*[@id='toast-container']/*[{index}]"
        wait = WebDriverWait(self._driver, time_out_secs)
        try:
            wait.until(expected_conditions.presence_of_element_located((By.XPATH, toaster_path)))
            return self.get_text(toaster_path, 'Toaster')
        except Exception as e:
            self.logger.error(f"Toaster is not able locate due to {str(e)}", exc_info=e)
            self.logger.debug(f"Toaster is not able locate due to {str(e)}")
            return ''

    def get_all_toaster_messages_text_list(self, time_out_secs: int = 30) -> List[str]:
        self.logger.debug("Waiting for toaster to load")
        toaster_child_path = f"//*[@id='toast-container']/*"
        wait = WebDriverWait(self._driver, time_out_secs)
        try:
            wait.until(expected_conditions.presence_of_element_located((By.XPATH, toaster_child_path)))
            message_elements = self._driver.find_elements(By.XPATH, toaster_child_path)
            messages = [self._get_element_text(element) for element in message_elements]
            return messages
        except Exception as e:
            self.logger.error(f"Toaster is not able locate due to {str(e)}", exc_info=e)
            self.logger.debug(f"Toaster is not able locate due to {str(e)}")
            return []

    def get_all_toaster_messages_text(self, time_out_secs: int = 30) -> str:
        self.logger.debug("Waiting for toaster to load")
        toaster_child_path = f"//*[@id='toast-container']/*"
        toaster_path = f"//*[@id='toast-container']"
        wait = WebDriverWait(self._driver, time_out_secs)
        try:
            wait.until(expected_conditions.presence_of_element_located((By.XPATH, toaster_child_path)))
            return self.get_text(toaster_path, 'Toaster')
        except Exception as e:
            self.logger.error(f"Toaster is not able locate due to {str(e)}", exc_info=e)
            self.logger.debug(f"Toaster is not able locate due to {str(e)}")
            return ''

    def wait_till_toaster_off(self, time_out_secs: int = 30) -> None:
        self.logger.debug("Waiting for toaster to unload")
        toaster_child_path = f"//*[@id='toast-container']/*"
        if self.is_exists(toaster_child_path):
            self.logger.debug("Waiting for toaster to unload")
            wait = WebDriverWait(self._driver, time_out_secs)
            try:
                wait.until(expected_conditions.staleness_of((By.XPATH, toaster_child_path)))
            finally:
                self.logger.error(f"Toaster is unloaded")
                pass
        else:
            self.logger.debug("Toaster is not present in the page")

    def wait_till_exists(self, xpath: str, name: str, time_out_secs: int = 30) -> None:
        self.logger.debug(f"Waiting for {name} to load")
        wait = WebDriverWait(self._driver, time_out_secs)
        try:
            wait.until(expected_conditions.presence_of_element_located((By.XPATH, xpath)))
        finally:
            self.logger.debug(f"Waiting for {name} is completed")
            pass

    def click(self, xpath: str, name: str) -> None:
        element = self._get_action_element_by_xpath(name, xpath)
        self.logger.debug(f"Ready to click on '{name}'")
        element.click()
        self.logger.debug(f"Clicked on element '{name}'")

    def check(self, xpath: str, name: str, is_checked: bool) -> None:
        if is_checked is None or not isinstance(is_checked, bool):
            return
        element = self._get_action_element_by_xpath(name, xpath)
        state = is_checked and 'checked' or 'unchecked'
        actual_state = bool(element.get_attribute('checked'))
        self.logger.debug(f"Ready to change the status to '{state}'")
        if actual_state ^ is_checked:
            element.click()
        self.logger.debug(f"'{name}' is '{state}'")

    def enter(self, xpath: str, name: str, value: str, is_clear: bool, focus_out: bool = False) -> None:

        if value is None:
            self.logger.debug(f"Value is not entered text in '{name}' due to value is none")
            return

        if not isinstance(value, str):
            value = str(value)

        element = self._get_action_element_by_xpath(name, xpath)
        self.logger.debug(f"Ready to enter text in '{name}' using '{xpath}'")

        if is_clear:
            self.logger.debug(f"Trying to clear '{name}' using '{xpath}'")
            content = element.get_attribute('value')
            if len(content) > 0:
                element.clear()
                content = element.get_attribute('value')
                total_content = len(content)
                if len(content) > 0:
                    total_back_spaces = [Keys.BACK_SPACE] * total_content
                    element.send_keys(total_back_spaces)
                time.sleep(1)

        if len(value) == 0:
            self.logger.debug(f"Value is not entered text in '{name}' due to whose length is 0")
            return

        element.send_keys(value)
        self.logger.debug(f"Entered text in '{value}' using '{xpath}'")

        if focus_out:
            self.logger.debug(f"Exiting focus from '{name}'")
            self._driver.execute_script('arguments[0].blur()', element)

    def select_by_text(self, xpath: str, name: str, value: str):
        if value is None or not isinstance(value, str) or len(value) == 0:
            return
        element = self._get_action_element_by_xpath(name, xpath)
        self.logger.debug(f"Ready to select '{name}' by text '{value}' using '{xpath}'")
        dropdown = Select(element)
        # self.logger.debug(f"Options {dropdown.options}")
        # self.logger.debug(f"Options type {type(dropdown.options)}")
        # self.logger.debug(f"Options Length :{len(dropdown.options)}")
        self.wait_till(lambda driver: len(dropdown.options) > 0, 30)
        dropdown.select_by_visible_text(value)

    def select_by_index(self, xpath: str, name: str, index: int):
        if index is None or not isinstance(index, int) or index <= 0:
            return
        element = self._get_action_element_by_xpath(name, xpath)
        self.logger.debug(f"Ready to select '{name}' by index at '{index}' using '{xpath}'")
        dropdown = Select(element)
        self.wait_till(lambda: len(dropdown.options) > 0, 30)
        dropdown.select_by_index(index)

    def select_by_value(self, xpath: str, name: str, value: str):
        if value is None or not isinstance(value, str) or len(value) == 0:
            return
        assert isinstance(value, int)
        element = self._get_action_element_by_xpath(name, xpath)
        self.logger.debug(f"Ready to select '{name}' by '{value}' at '{xpath}'")
        dropdown = Select(element)
        dropdown.select_by_value(value)

    def get_drop_down_text(self, xpath: str, name: str) -> str:
        element = self._get_action_element_by_xpath(name, xpath)
        self.logger.debug(f"'{name}' drop down is available to get text")
        dropdown = Select(element)
        return dropdown.first_selected_option.text

    def get_drop_down_value(self, xpath: str, name: str) -> str:
        element = self._get_action_element_by_xpath(name, xpath)
        self.logger.debug(f"'{name}' drop down is available to get value")
        dropdown = Select(element)
        return dropdown.first_selected_option.get_attribute("value")

    def is_visible(self, xpath: str) -> bool:
        assert isinstance(xpath, str)
        try:
            element = self._driver.find_element_by_xpath(xpath)
            is_displayed = element.is_displayed()
            self.logger.debug(f"'{xpath}' display status is {is_displayed}")
            return is_displayed
        except NoSuchElementException:
            self.logger.debug(f"'{xpath}' display status is False due to invalid path")
        except Exception as e:
            self.logger.error(f"'{xpath}' path not able to find display status is False due to {str(e)}", exc_info=e)
            self.logger.debug(f"'{xpath}' path not able to find display status is False due to {str(e)}")
        return False

    def is_enabled(self, xpath: str) -> bool:
        assert isinstance(xpath, str)
        try:
            element = self._driver.find_element_by_xpath(xpath)
            is_enabled = element.is_enabled()
            self.logger.debug(f"'{xpath}' enabled status is {is_enabled}")
            return is_enabled
        except NoSuchElementException:
            self.logger.debug(f"'{xpath}' is not able to find enabled status due to invalid path")
        except Exception as e:
            self.logger.error(f"'{xpath}' path not able to find enabled status due to {str(e)}", exc_info=e)
            self.logger.debug(f"'{xpath}' path not able to find enabled status due to {str(e)}")
        return False

    def is_clickable(self, xpath: str) -> bool:
        assert isinstance(xpath, str)
        try:
            element = self._driver.find_element_by_xpath(xpath)
            return element.is_displayed() and element.is_enabled()
        except NoSuchElementException:
            self.logger.debug(f"'{xpath}' not clickable due to invalid path")
        except Exception as e:
            self.logger.error(f"'{xpath}' is not clickable due to {str(e)}", exc_info=e)
            self.logger.debug(f"'{xpath}' is not clickable due to {str(e)}")
        return False

    def _get_action_element_by_xpath(self, name: str, xpath: str) -> WebElement:
        assert isinstance(xpath, str)
        assert isinstance(name, str)
        self.logger.debug(f"Waiting for '{name}' at '{xpath}'")
        wait = WebDriverWait(self._driver, 90)
        wait.until(expected_conditions.presence_of_element_located((By.XPATH, xpath)))
        element = self._driver.find_element_by_xpath(xpath)
        self._driver.execute_script('arguments[0].scrollIntoView(true);', element)
        wait.until(expected_conditions.visibility_of_element_located((By.XPATH, xpath)))
        wait.until(expected_conditions.element_to_be_clickable((By.XPATH, xpath)))
        return element

    def check_element_is_present(self, name: str, xpath: str) -> None:
        assert isinstance(xpath, str)
        assert isinstance(name, str)
        self.logger.debug(f"Verifying that '{name}' presence at '{xpath}' in the DOM")
        self.wait_till_exists(xpath, name)
        assert self.is_exists(xpath)

    def check_element_is_not_present(self, name: str, xpath: str) -> None:
        assert isinstance(xpath, str)
        assert isinstance(name, str)
        self.logger.debug(f"Verifying that '{name}' not presence at '{xpath}' in the DOM")
        self.wait_till_not_exists(xpath, name)
        assert not self.is_exists(xpath)

    def is_exists(self, xpath: str) -> bool:
        try:
            self._driver.find_element_by_xpath(xpath)
        except NoSuchElementException:
            self.logger.debug(f"{xpath} is not found in DOM")
            return False
        except Exception as e:
            self.logger.error(f"{xpath} is not found due to {str(e)}", exc_info=e)
            self.logger.debug(f"{xpath} is not found due to {str(e)}")
            return False
        return True

    def capture_screenshot_full(self, name: str) -> str:
        time_stamp = datetime.now().strftime('%Y-%m-%d_%H_%M_%S')
        img_relative_path = f'images\\{name}_{time_stamp}.png'
        img_path = Path.get_full_path(f'reports\\html\\{img_relative_path}')
        Path.create_directory(img_path)
        self.logger.debug(f"Screenshot saved at '{img_path}'")
        self._driver.save_screenshot(img_path)
        return img_relative_path

    def get_text(self, xpath: str, name: str) -> str:
        assert xpath is not None and len(xpath) > 0
        try:
            element = self._get_element_by_xpath(name, xpath)
            tag_name = element.tag_name.lower()
            value = self._get_element_text(element)
            self.logger.debug(f"'{name}' at '{xpath}' of tag is '{tag_name}' value is {repr(value)}")
            return value
        except Exception as e:
            self.logger.error(f"Unable to get '{name}' text by '{xpath}' due to {str(e)}", exc_info=e)
            self.logger.debug(f"Unable to get '{name}' text by '{xpath}' due to {str(e)}")
            return ''

    @staticmethod
    def _get_element_text(element: WebElement):
        tag_name = element.tag_name.lower()
        if tag_name == 'input' or tag_name == 'textarea':
            return element.get_attribute('value')
        elif tag_name == 'select':
            ddl = Select(element)
            return ddl.first_selected_option.text
        else:
            return element.get_attribute('innerText')

    def get_attribute(self, xpath: str, name: str, attr: str) -> str:
        assert xpath is not None and len(xpath) > 0
        try:
            element = self._get_element_by_xpath(name, xpath)
            attr_value = element.get_attribute(attr)
            self.logger.debug(f"'{name}' of '{attr}' attribute value is '{attr_value}' at '{xpath}'")
            return element.get_attribute(attr)
        except Exception as e:
            self.logger.error(f"Unable to get '{name}' element '{attr}' attribute at '{xpath}' due to {str(e)}",
                              exc_info=e)
            self.logger.debug(f"Unable to get '{name}' element '{attr}' attribute at '{xpath}' due to {str(e)}")
            return ''

    def _get_element_by_xpath(self, name: str, xpath: str) -> WebElement:
        assert isinstance(xpath, str)
        assert isinstance(name, str)
        self.logger.debug(f"Waiting for an '{name}' of '{xpath}'")
        wait = WebDriverWait(self._driver, 90)
        wait.until(expected_conditions.presence_of_element_located((By.XPATH, xpath)))
        element = self._driver.find_element_by_xpath(xpath)
        return element
