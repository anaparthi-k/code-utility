import time

import pyautogui


class Keyboard:

    @staticmethod
    def escape():
        """Wait for a second before pressing ESCAPE again waiting for a second """
        time.sleep(1)
        pyautogui.hotkey('esc')
        time.sleep(1)

    @staticmethod
    def enter():
        """Wait for a second before pressing ENTER again waiting for a second"""
        time.sleep(1)
        pyautogui.hotkey('enter')
        time.sleep(1)

    @staticmethod
    def tab():
        """Wait for a second before pressing ENTER again waiting for a second"""
        time.sleep(1)
        pyautogui.hotkey('tab')
        time.sleep(1)

    @staticmethod
    def alt_f4():
        """Wait for a second before pressing ENTER again waiting for a second"""
        time.sleep(1)
        pyautogui.hotkey('alt', 'f4')
        time.sleep(1)

    @staticmethod
    def write(value: str):
        pyautogui.write(value, interval=0.05)
