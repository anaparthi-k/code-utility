from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from models.pages.recurring_deliverables.child_task_section_model import ChildTaskSectionModel
from pages.page_base import PageBase


class ChildTaskSectionPage(PageBase):
    _child_task_id = "//app-add-update-child-tasks//*[text()='Child Task ID']/following-sibling::input"
    _task_name = "//app-add-update-child-tasks//*[text()='Task Name']/following-sibling::input"
    _recurrance_pattern = "//app-add-update-child-tasks//*[text()='Recurrance Pattern']/following-sibling::input"
    _owner = "//app-add-update-child-tasks//*[text()='Owner']/following-sibling::input"
    _widgets_count = "//app-add-update-child-tasks//*[text()='Widgets Count']/following-sibling::input"
    _time_to_complete_mins = "//app-add-update-child-tasks//*[text()='Time To Complete Mins']/following-sibling::input"
    _task_creation_date = "//app-add-update-child-tasks//*[text()='Task Creation Date']/following-sibling::*//input"
    _task_due_date = "//app-add-update-child-tasks//*[text()='Task Due Date']/following-sibling::*//input"
    _completion_date = "//app-add-update-child-tasks//*[text()='Completion Date']/following-sibling::*//input"
    _date = "//app-add-update-child-tasks//*[text()='Date']/following-sibling::*//input"
    _child_task_status = "//app-add-update-child-tasks//*[text()='Child Task Status']/following-sibling::select"
    _quality_check = "//app-add-update-child-tasks//*[text()='Quality Check']/following-sibling::select"
    _description = "//app-add-update-child-tasks//*[text()='Description']/following-sibling::textarea"
    _quality_notes = "//app-add-update-child-tasks//*[text()='Quality Notes']/following-sibling::textarea"
    _update = "//app-add-update-child-tasks//*[text()='Update']"
    _reset = "//app-add-update-child-tasks//*[text()='Reset']"
    _cancel_update = "//app-add-update-child-tasks//*[text()='Cancel Update']"
    _edit_button_of_row = "//app-add-update-child-tasks//*[text()='{0}']/../*[1]/*[1]"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def fill_data(self, form: ChildTaskSectionModel):
        self.enter_child_task_id(form.child_task_id)
        self.enter_task_name(form.task_name)
        self.enter_recurrance_pattern(form.recurrance_pattern)
        self.enter_owner(form.owner)
        self.enter_task_creation_date(form.task_creation_date)
        self.enter_task_due_date(form.task_due_date)
        self.enter_completion_date(form.completion_date)
        self.enter_widgets_count(form.widgets_count)
        self.enter_time_to_complete_mins(form.time_to_complete_mins)
        self.enter_description(form.description)
        self.enter_date(form.date)
        self.enter_quality_notes(form.quality_notes)
        self.select_child_task_status(form.child_task_status)
        self.select_quality_check(form.quality_check)

    def enter_child_task_id(self, value):
        self._driver.enter(self._child_task_id, "Child Task ID", value, is_clear=True)

    def enter_task_name(self, value):
        self._driver.enter(self._task_name, "Task Name", value, is_clear=True)

    def enter_recurrance_pattern(self, value):
        self._driver.enter(self._recurrance_pattern, "Recurrance Pattern", value, is_clear=True)

    def enter_owner(self, value):
        self._driver.enter(self._owner, "Owner", value, is_clear=True)

    def enter_task_creation_date(self, value):
        self._driver.enter(self._task_creation_date, "Task Creation Date", value, is_clear=True)

    def enter_task_due_date(self, value):
        self._driver.enter(self._task_due_date, "Task Due Date", value, is_clear=True)

    def enter_completion_date(self, value):
        self._driver.enter(self._completion_date, "Completion Date", value, is_clear=True)

    def enter_widgets_count(self, value):
        self._driver.enter(self._widgets_count, "Widgets Count", value, is_clear=True)

    def enter_time_to_complete_mins(self, value):
        self._driver.enter(self._time_to_complete_mins, "Time To Complete Mins", value, is_clear=True)

    def enter_description(self, value):
        self._driver.enter(self._description, "Description", value, is_clear=True)

    def enter_date(self, value):
        self._driver.enter(self._date, "Date", value, is_clear=True)

    def enter_quality_notes(self, value):
        self._driver.enter(self._quality_notes, "Quality Notes", value, is_clear=True)

    def select_child_task_status(self, value):
        self._driver.select_by_text(self._child_task_status, "Child Task Status", value)

    def select_quality_check(self, value):
        self._driver.select_by_text(self._quality_check, "Quality Check", value)

    def is_quality_check_enabled(self):
        return self._driver.is_enabled(self._quality_check)

    def is_date_enabled(self):
        return self._driver.is_enabled(self._quality_check)

    def click_on_update(self):
        self._driver.click(self._update, "Update")
        self._driver.wait_till_spinner_off()

    def click_on_edit_button(self, value: str):
        self._driver.click(self._edit_button_of_row.format(value), f"Edit of {value}")

    pass
