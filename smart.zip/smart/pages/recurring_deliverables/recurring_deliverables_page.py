from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from models.pages.recurring_deliverables.recurring_deliverables_model import RecurringDeliverablesModel
from pages.page_base import PageBase


class RecurringDeliverablesPage(PageBase):
    _header_title = "//*[@*='sctn-hdr']"

    _task_status = "//*[text()='Task Status ']/following-sibling::select"
    _category = "//*[text()='Category ']/following-sibling::select"
    _sub_category = "//*[text()='Sub Category ']/following-sibling::select"
    _task_name = "//*[text()='Task Name']/following-sibling::input"
    _delivery_method = "//*[text()='Delivery Method']/following-sibling::input"
    _delivery_detail = "//*[text()='Delivery Detail']/following-sibling::input"
    _owner = "//*[text()='Owner']"
    _owner_text = "//*[text()='Owner']/following-sibling::*//input"
    _description = "//*[text()='Description']/following-sibling::textarea"
    _backup = "//*[text()='Backup']"
    _supervisor = "//*[text()='Supervisor']"
    _supervisor_text = "//*[text()='Supervisor ']/following-sibling::*//input"
    _master_task_id = "//*[text()='Master Task ID']/following-sibling::input"
    _every = "//*[text()='Every ']/following-sibling::input"
    _recur_every = "//*[text()='Recur Every ']/following-sibling::input"
    _monday = "//*[text()='Monday']/following-sibling::input"
    _tuesday = "//*[text()='Tuesday']/following-sibling::input"
    _wednesday = "//*[text()='Wednesday']/following-sibling::input"
    _thursday = "//*[text()='Thursday']/following-sibling::input"
    _day = "//*[text()='Day ']/following-sibling::input"
    _of_every = "//*[text()=' of every ']/following-sibling::input"
    _start = "//*[text()='Start ']/following-sibling::input"
    _end_after = "//*[text()='End After ']/following-sibling::input"
    _advance_notification_days = "//*[text()='Advance Notification (Days)']/following-sibling::input"
    _time_to_complete_minutes = "//*[text()='Time to Complete (Mins)']/following-sibling::input"
    _save = "//*[text()='Save']"
    _reset = "//*[text()='Reset']"
    _cancel = "//*[text()='Cancel']"
    _created_date = "//*[text()='Created Date ']/following-sibling::*//input"
    _created_by = "//*[text()='Created By ']/following-sibling::*//input"
    _end_by = "//*[text()='End By ']/following-sibling::*//input"
    _backup_start_date = "//*[text()='Backup Start Date']/following-sibling::*//input"
    _backup_end_date = "//*[text()='Backup End Date']/following-sibling::*//input"
    _form_container = "//app-general-details"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def get_data(self):
        return self._converter.fields_to_tuple(self._form_container)

    def save_create_form(self, form: RecurringDeliverablesModel):
        self.enter_form_data(form)
        self.click_on_save()

    def enter_form_data(self, form: RecurringDeliverablesModel):
        self.select_task_status(form.task_status)
        self.select_category(form.category)
        self.select_sub_category(form.sub_category)
        self.enter_task_name(form.task_name)
        self.enter_delivery_method(form.delivery_method)
        self.enter_delivery_detail(form.delivery_detail)
        self.enter_owner(form.owner)
        self.enter_description(form.description)
        self.enter_advance_notification_days(form.advance_notification_days)
        self.enter_time_to_complete_minutes(form.time_to_complete_minutes)
        self.enter_backup(form.backup)
        self.enter_backup_start_date(form.backup_start_date)
        self.enter_backup_end_date(form.backup_end_date)

    def enter_owner(self, value):
        self._enter_auto_populate(self._owner, 'Owner', value)

    def enter_backup(self, value):
        self._enter_auto_populate(self._backup, 'Backup', value)

    def enter_description(self, value):
        self._driver.enter(self._description, "Description", value, is_clear=True)

    def enter_supervisor(self, value):
        self._enter_auto_populate(self._supervisor, 'Supervisor', value)

    def enter_master_task_id(self, value):
        self._driver.enter(self._master_task_id, "Master Task ID", value, is_clear=True)

    def enter_task_name(self, value):
        self._driver.enter(self._task_name, "Task Name", value, is_clear=True)

    def enter_delivery_method(self, value):
        self._driver.enter(self._delivery_method, "Delivery Method", value, is_clear=True)

    def enter_delivery_detail(self, value):
        self._driver.enter(self._delivery_detail, "Delivery Detail", value, is_clear=True)

    def enter_every(self, value):
        self._driver.enter(self._every, "Every ", value, is_clear=True)

    def enter_recur_every(self, value):
        self._driver.enter(self._recur_every, "Recur Every ", value, is_clear=True)

    def enter_monday(self, value):
        self._driver.enter(self._monday, "Monday", value, is_clear=True)

    def enter_tuesday(self, value):
        self._driver.enter(self._tuesday, "Tuesday", value, is_clear=True)

    def enter_wednesday(self, value):
        self._driver.enter(self._wednesday, "Wednesday", value, is_clear=True)

    def enter_thursday(self, value):
        self._driver.enter(self._thursday, "Thursday", value, is_clear=True)

    def enter_day(self, value):
        self._driver.enter(self._day, "Day ", value, is_clear=True)

    def enter_of_every(self, value):
        self._driver.enter(self._of_every, " of every ", value, is_clear=True)

    def enter_start(self, value):
        self._driver.enter(self._start, "Start ", value, is_clear=True)

    def enter_end_after(self, value):
        self._driver.enter(self._end_after, "End After ", value, is_clear=True)

    def enter_advance_notification_days(self, value):
        self._driver.enter(self._advance_notification_days, "Advance Notification Days", value, is_clear=True)

    def enter_time_to_complete_minutes(self, value):
        self._driver.enter(self._time_to_complete_minutes, "Time to Complete Mins", value, is_clear=True)

    def enter_created_date(self, value):
        self._driver.enter(self._created_date, "Created Date ", value, is_clear=True)

    def enter_end_by(self, value):
        self._driver.enter(self._end_by, "End By ", value, is_clear=True)

    def enter_backup_start_date(self, value):
        self._driver.enter(self._backup_start_date, "Backup Start Date", value, is_clear=True)

    def enter_backup_end_date(self, value):
        self._driver.enter(self._backup_end_date, "Backup End Date", value, is_clear=True)

    def select_task_status(self, value):
        self._driver.select_by_text(self._task_status, "Task Status ", value)

    def select_category(self, value):
        self._driver.select_by_text(self._category, "Category ", value)

    def select_sub_category(self, value):
        self._driver.select_by_text(self._sub_category, "Sub Category ", value)

    def get_header_text(self) -> str:
        return self._driver.get_text(self._header_title, "Header Title")

    def click_on_save(self):
        self._driver.click(self._save, "Save")
        self._driver.wait_till_spinner_off()

    def click_on_reset(self):
        self._driver.click(self._reset, "Reset")

    def click_on_cancel(self):
        self._driver.click(self._cancel, "Cancel")

    def get_all_filed_text(self):
        return (
            self.get_master_task_id_text(),
            self.get_created_date_text(),
            self.get_created_by_text(),
            self.get_task_status_text(),
            self.get_category_text(),
            self.get_sub_category_text(),
            self.get_supervisor_text(),
            self.get_task_name_text(),
            self.get_delivery_method_text(),
            self.get_delivery_detail_text(),
            self.get_owner_text(),
            self.get_description_text(),
            self.get_advance_notification_days_text(),
            self.get_time_to_complete_minutes_text(),
            self.get_backup_text(),
            self.get_backup_start_date_text(),
            self.get_backup_end_date_text()
        )

    def get_created_date_text(self) -> str:
        return self._driver.get_text(self._created_date, "Created Date")

    def get_created_by_text(self) -> str:
        return self._driver.get_text(self._created_by, "Created By")

    def get_task_status_text(self) -> str:
        return self._driver.get_text(self._task_status, "Task Status")

    def get_category_text(self) -> str:
        return self._driver.get_text(self._category, "Category")

    def get_sub_category_text(self) -> str:
        return self._driver.get_text(self._sub_category, "Sub Category")

    def get_supervisor_text(self) -> str:
        return self._driver.get_text(self._supervisor_text, "Supervisor")

    def get_master_task_id_text(self) -> str:
        return self._driver.get_text(self._master_task_id, "Master Task ID")

    def get_task_name_text(self) -> str:
        return self._driver.get_text(self._task_name, "Task Name")

    def get_delivery_method_text(self) -> str:
        return self._driver.get_text(self._delivery_method, "Delivery Method")

    def get_delivery_detail_text(self) -> str:
        return self._driver.get_text(self._delivery_detail, "Delivery Detail")

    def get_owner_text(self) -> str:
        return self._driver.get_text(self._owner_text, "Owner")

    def get_description_text(self) -> str:
        return self._driver.get_text(self._description, "Description")

    def get_advance_notification_days_text(self) -> str:
        return self._driver.get_text(self._advance_notification_days, "Advance Notification Days")

    def get_time_to_complete_minutes_text(self) -> str:
        return self._driver.get_text(self._time_to_complete_minutes, "Time to Complete Mins")

    def get_backup_text(self) -> str:
        return self._driver.get_text(self._backup, "Backup")

    def get_backup_start_date_text(self) -> str:
        return self._driver.get_text(self._backup_start_date, "Backup Start Date")

    def get_backup_end_date_text(self) -> str:
        return self._driver.get_text(self._backup_end_date, "Backup End Date")
