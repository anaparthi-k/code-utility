import logging
from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy


class PageBase:
    _driver: DriverProxy
    _converter: DriverElementProxy
    logger: logging.Logger = None

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        self._driver = driver
        self._converter = converter

    def _enter_auto_populate(self, label_xpath, name: str, value: str):
        assert isinstance(label_xpath, str)
        assert isinstance(name, str)

        if value is None:
            return

        suggestion = value
        if value.__contains__(','):
            name_parts = str(value).split(',')
            first_name = name_parts[0]
            last_name = name_parts[1]
            if len(first_name) > len(last_name):
                suggestion = first_name
            else:
                suggestion = last_name
            suggestion = suggestion.strip()

        field = f"{label_xpath}/following-sibling::*//input"
        field_clear = f"{label_xpath}/following-sibling::*//*[text()='close']"
        field_suggestion = label_xpath + "/following-sibling::*//*[contains(text(),'{0}')]"

        if self._driver.is_exists(field_clear):
            self._driver.click(field_clear, f'{name} text clear')
        self._driver.enter(field, name, suggestion, is_clear=False)
        self._driver.wait_till_spinner_off()
        self._driver.click(field_suggestion.format(suggestion), f'{name} suggestion {suggestion}')
