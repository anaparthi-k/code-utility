from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.page_base import PageBase
from models.pages.supervisor_management.supervisor_management_model import SupervisorManagementSearchModel, \
    SupervisorManagementAddModel
from typing import List


class SupervisorManagementSearchForm(PageBase):
    _user_name = "//*[text()='User Name']/following-sibling::*//input"
    _user_name_label = "//*[text()='User Name']"
    _role = "//*[text()='Role']/following-sibling::select"
    _from_date = "//*[text()='From Date']/following-sibling::*//input"
    _to_date = "//*[text()='To Date']/following-sibling::*//input"
    _search_button = "//*[text()='Search']"
    _add_button = "//*[text()='Add']"
    _reset_button = "//*[text()='Reset']"
    _update_button = "//*[text()='Update']"
    _edit_button_of_row = "//*[@title='Edit Supervisor'][1]"
    _header_title_label = "//*[@class='sctn-hdr']"
    _table_no_records = "//app-manage-supervisor//*[text()='No Records Found']"
    _search_form_container = "//app-manage-supervisor"
    _header_title = "//*[@class='sctn-hdr']"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def perform_search(self, form: SupervisorManagementSearchModel):
        self.enter_form(form)
        self.click_on_search()

    def enter_form(self, form: SupervisorManagementSearchModel):
        self.enter_from_date(form.from_date)
        self._enter_auto_populate(self._user_name_label, 'User Name', form.user_name)
        self.select_role(form.user_role)        
        self.enter_to_date(form.to_date)

    def select_role(self, value: str):
        self._driver.select_by_text(self._role, 'Role', value)

    def enter_from_date(self, value: str):
        self._driver.enter(self._from_date, 'From Date', value, is_clear=True)

    def enter_to_date(self, value: str):
        self._driver.enter(self._to_date, 'To Date', value, is_clear=True)

    def click_on_search(self):
        self._driver.click(self._search_button, 'Search')
        self._driver.wait_till_spinner_off()

    def click_on_add_button(self):
        self._driver.click(self._add_button, "Add")

    def click_on_reset_button(self):
        self._driver.click(self._reset_button, "Reset")

    def click_on_update_button(self):
        self._driver.click(self._update_button, "Update")

    def click_on_edit_button(self):
        self._driver.click(self._edit_button_of_row, "Edit Supervisor")

    def get_header_title(self):
        return self._driver.get_text(self._header_title_label, 'header title')

    def is_grid_has_records(self) -> bool:
        return self._driver.is_exists(self._table_no_records)

    def get_data(self) -> List[List[str]]:
        return self._converter.fields_to_tuple(self._search_form_container)

    def get_header_text(self) -> str:
        return self._driver.get_text(self._header_title, "Header Title")


class SupervisorManagementAddForm(PageBase):
    _user_name = "//*[text()='User Name']/following-sibling::*//input"
    _user_name_label = "//*[text()='User Name']"
    _supervisor = "//*[text()='Supervisor']/following-sibling::*//input"
    _supervisor_label = "//*[text()='Supervisor']"
    _start_date = "//*[text()='Start Date']/following-sibling::*//input"
    _end_date = "//*[text()='End Date']/following-sibling::*//input"
    _save_button = "//*[text()='Save']"
    _cancel_button = "//*[text()='Cancel']"
    _reset_button = "//*[text()='Reset']"
    _yes_button = "//*[text()='Yes']"
    _header_title_label = "//*[@class='sctn-hdr']"
    _add_supervisor_form_container = "//app-add-edit-supervisor"
    _save_button_ok = "//*[text()='OK']"
    _header_title = "//*[@class='sctn-hdr']"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def add_supervisor(self, form: SupervisorManagementAddModel):
        self.enter_form(form)
        self.click_on_save()
        pass

    def enter_form(self, form: SupervisorManagementAddModel):
        self._enter_auto_populate(self._user_name_label, 'User Name', form.user_name)
        self._enter_auto_populate(self._supervisor_label, 'Supervisor', form.supervisor)
        self.enter_start_date(form.start_date)
        self.enter_end_date(form.end_date)
        pass

    def enter_start_date(self, value: str):
        self._driver.enter(self._start_date, "Start Date", value, is_clear=True)

    def enter_end_date(self, value: str):
        self._driver.enter(self._end_date, "End Date", value, is_clear=True)

    def enter_edit_details(self, value: str):
        self._driver.enter(self._start_date, "Start Date", value, is_clear=True)

    def click_on_save(self):
        self._driver.click(self._save_button, "Save")
        self._driver.wait_till_spinner_off()

    def click_on_cancel_button(self):
        self._driver.click(self._cancel_button, "Cancel")
        self.click_on_yes_button()
        self._driver.wait_till_spinner_off()

    def click_on_yes_button(self):
        self._driver.click(self._yes_button, "Yes")

    def click_on_save_ok_button(self):
        self._driver.click(self._save_button_ok, "OK")

    def click_on_reset_button(self):
        self._driver.click(self._reset_button, "Reset")

    def get_header_title(self):
        return self._driver.get_text(self._header_title_label, 'header title')

    def get_data(self):
        return self._converter.fields_to_tuple(self._add_supervisor_form_container)

    def get_header_text(self) -> str:
        return self._driver.get_text(self._header_title, "Header Title")
