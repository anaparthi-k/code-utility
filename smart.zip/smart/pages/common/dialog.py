from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.page_base import PageBase


class Dialog(PageBase):
    _yes_button = "//*[text()='Yes']"
    _no_button = "//*[text()='No']"
    _body = "//*[@id='swal2-title']"
    _alert_body = "//*[@id='swal2-title']"
    _ok_button = "//*[text()='OK']"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def get_text(self) -> str:
        return self._driver.get_text(self._body, "Dialog Body")

    def click_yes_button(self):
        self._driver.click(self._yes_button, "Dialog Yes")
        self._driver.wait_till_spinner_off()

    def click_no_button(self):
        self._driver.click(self._no_button, "Dialog No")

    def click_ok_button(self):
        self._driver.click(self._ok_button, "Alert Dialog OK")
