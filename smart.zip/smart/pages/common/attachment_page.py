import time
from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from core.keyboard import Keyboard
from pages.page_base import PageBase
from utils.path import Path


class AttachmentPage(PageBase):
    _more_links = "//*[text()=' More Links... ']"
    _attachments = "//*[text()='Attachments']"
    _add_attachment = "//*[text()=' Add Attachment ']"
    _browse = "//*[text()=' Browse ']"
    _remove_document = "//*[@title='Remove Document']"
    _description = "//*[text()='Description ']/following-sibling::textarea"
    _upload = "//*[text()=' Upload ']"
    _delete_document = "//*[text()='{}']/../*[last()]/*[1]"
    _download_document = "//*[text()='{}']/../*[last()]/*[2]"
    _close = "//*[@*='cross']"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def click_on_more_links(self):
        self._driver.click(self._more_links, "More Links")

    def click_on_attachments(self):
        self._driver.click(self._attachments, "Attachments")

    def click_on_remove_document(self):
        self._driver.click(self._remove_document, "Remove Document")

    def click_on_add_attachment(self):
        self._driver.click(self._add_attachment, "Add Attachments")

    def click_on_upload(self):
        self._driver.click(self._upload, "Upload")

    def click_on_close(self):
        self._driver.click(self._close, "Close")

    def click_on_delete_document(self, value: str):
        self._driver.click(self._delete_document.format(value), f"Delete Document of {value}")

    def click_on_download_document(self, value: str):
        self._driver.click(self._download_document.format(value), f"Download Document of {value}")

    def browse_file(self, file_path):
        self._driver.click(self._browse, "Browse")
        self._enter_file_path_in_dialog(file_path)

    def _enter_file_path_in_dialog(self, path: str):
        if path is not None and len(path) > 0:
            Keyboard.escape()
            pass
        time.sleep(2)
        full_path = Path.get_full_path(path)
        self.logger.debug("Full path of file is {0}".format(full_path))
        Keyboard.write(full_path)
        Keyboard.enter()
        time.sleep(1)

    def enter_description(self, value: str):
        self._driver.enter(self._description, 'description', value, is_clear=False)
