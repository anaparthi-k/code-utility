from abc import abstractmethod
from typing import Tuple
from pages.page_base import PageBase


class FormContainer(PageBase):

    @abstractmethod
    def get_data(self) -> Tuple[str]:
        pass

    @abstractmethod
    def click_on_reset_button(self) -> None:
        pass
