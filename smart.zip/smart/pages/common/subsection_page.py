from abc import abstractmethod
from typing import Tuple, List
from pages.common.pagination import Pagination
from pages.page_base import PageBase


class SubsectionPage(PageBase):

    @abstractmethod
    def get_form_data(self) -> Tuple[str]:
        pass

    @abstractmethod
    def get_table_data(self) -> List[List[str]]:
        pass

    @abstractmethod
    def create_pagination(self) -> Pagination:
        pass

    @abstractmethod
    def fill_form(self, form: any) -> None:
        pass

    @abstractmethod
    def click_on_reset_button(self) -> None:
        pass

    @abstractmethod
    def click_on_save_button(self) -> None:
        pass

    @abstractmethod
    def click_on_cancel_button(self) -> None:
        pass

    @abstractmethod
    def click_on_search_button(self) -> None:
        pass

    @abstractmethod
    def click_on_form_expand_button(self) -> None:
        pass

    @abstractmethod
    def is_form_section_expanded(self) -> bool:
        pass

    @abstractmethod
    def is_table_section_expanded(self) -> bool:
        pass

    @abstractmethod
    def click_on_table_expand_button(self) -> None:
        pass

    @abstractmethod
    def click_on_table_edit_button(self, value: str) -> None:
        pass

    @abstractmethod
    def click_on_table_delete_button(self, value: str) -> None:
        pass
