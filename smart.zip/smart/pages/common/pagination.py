from typing import List
from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.page_base import PageBase


class Pagination(PageBase):
    _next_button = "//*[text()=' Next ']"
    _page_link = "//*[text()='{0}']"
    _last_page = "//pagination-template/*/*[last()-1]/*/*[last()]"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy, container_path: str):
        super().__init__(driver, converter)
        self._driver = driver
        self._container_path = container_path

    def get_data(self) -> List[List[str]]:
        return self._converter.table_to_array(self._container_path)

    def click_on_next(self):
        self._driver.click(self._container_path + self._next_button, "Pagination Next")

    def click_on_page(self, page: int):
        self._driver.click(self._container_path + self._page_link.format(page), f"Page of {page}")

    def get_last_page_number(self):
        is_exists = self._driver.is_exists(self._container_path + self._last_page)

        if is_exists:
            last_page = self._driver.get_text(self._container_path + self._last_page, f"Last page number in pagination")
            return int(last_page)
        else:
            return 1
