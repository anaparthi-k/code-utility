from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.page_base import PageBase


class Menu(PageBase):

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    _menu_bar = "//*[contains(@class,'menu-bar disableDiv')]"
    _user_name_label = "//*[@title='Log out']/../preceding-sibling::*[1]"
    _admin_menu = "//*[text()=' Admin ']"
    _scorecard_menu = "//*[text()=' Scorecard ']"
    _scorecard_generation = "//*[text()=' Scorecard Generation ']"
    _scorecard_history = "//*[text()=' Scorecard History ']"
    _group_mapping = "//*[text()=' Group Mapping ']"
    _frequency = "//*[text()=' Frequency Configuration ']"
    _scorecard_update = "//*[text()=' Scorecard Update ']"
    _notifications_configuration = "//*[text()=' Notifications Configuration ']"
    _case_manage = "//*[text()=' Case Management ']"
    _sam_request = "//*[text()=' Create SAM Request ']"
    _crt_request = "//*[text()=' Create CRT Request ']"
    _activity_manage = "//*[text()=' Activity Management ']"
    _sam_activity = "//*[text()=' Create SAM Activity ']"
    _crt_activity = "//*[text()=' Create CRT Projects ']"
    _non_production_time_tracker = "//*[text()=' Non Production Time Tracker ']"
    _search_menu = "//*[text()=' Search ']"
    _search_requests_sub_menu = "//*[text()=' Requests ']"
    _search_activities_sub_menu = "// *[text() = ' Activities ']"
    _search_deliverables_sub_menu = "// *[text() = ' Deliverables ']"
    _search_capabilities_sub_menu = "// *[text() = ' Capabilities ']"
    _search_value_tracker_requests_sub_menu = "// *[text() = ' Value Tracker Requests ']"
    _supervisor_management = "//*[text()=' Supervisor Management ']"
    _smart_configurations = "//*[text()=' SMART Configurations ']"
    _recurring_deliverables_menu = "//*[text()=' Recurring Deliverables ']"
    _create_recurring_deliverables_sub_menu = "//*[text()=' Create Recurring Deliverables ']"
    _manage_user = "//*[text()=' Manage User ']"

    def open_scorecard_generation(self):
        self._open_submenu_page_with_spinner(self._scorecard_menu,
                                             "Scorecard Menu",
                                             self._scorecard_generation,
                                             "Scorecard Generation")

    def open_scorecard_history(self):
        self._open_submenu_page_with_spinner(self._scorecard_menu,
                                             "Scorecard Menu",
                                             self._scorecard_history,
                                             "Scorecard History")

    def open_group_mapping(self):
        self._open_submenu_page_with_spinner(self._admin_menu,
                                             "Admin Menu",
                                             self._group_mapping,
                                             "Group Mapping")

    def open_frequency_configuration(self):
        self._open_submenu_page_with_spinner(self._admin_menu,
                                             "Admin Menu",
                                             self._frequency,
                                             "Frequency Configuration")

    def open_manage_user(self):
        self._open_submenu_page_with_spinner(self._admin_menu,
                                             "Admin Menu",
                                             self._manage_user,
                                             "Manage User")

    def open_scorecard_update(self):
        self._open_submenu_page_with_spinner(self._admin_menu,
                                             "Admin Menu",
                                             self._scorecard_update,
                                             "Scorecard Update")

    def open_notifications_configuration(self):
        self._open_submenu_page_with_spinner(self._admin_menu,
                                             "Admin Menu",
                                             self._notifications_configuration,
                                             " Notifications Configuration ")

    def open_sam_request(self):
        self._open_submenu_page_with_spinner(self._case_manage,
                                             "Case Management",
                                             self._sam_request,
                                             "Create SAM Request")

    def open_crt_request(self):
        self._open_submenu_page_with_spinner(self._case_manage,
                                             "Case Management",
                                             self._crt_request,
                                             "Create CRT Request")

    def open_sam_activity_management(self):
        self._open_submenu_page_with_spinner(self._activity_manage,
                                             "Activity Management",
                                             self._sam_activity,
                                             "Create SAM Activity")

    def open_crt_activity_management(self):
        self._open_submenu_page_with_spinner(self._activity_manage,
                                             "Activity Management",
                                             self._crt_activity,
                                             "Create CRT Activity")

    def open_search_requests(self):
        self._open_submenu_page_with_spinner(self._search_menu,
                                             "search",
                                             self._search_requests_sub_menu,
                                             "Search Requests")

    def open_search_activities(self):
        self._open_submenu_page_with_spinner(self._search_menu,
                                             "Search",
                                             self._search_activities_sub_menu,
                                             "Search activity")

    def open_search_deliverables(self):
        self._open_submenu_page_with_spinner(self._search_menu,
                                             "Search",
                                             self._search_deliverables_sub_menu,
                                             "Search Deliverables")
    
    def open_search_capabilities(self):
        self._open_submenu_page_with_spinner(self._search_menu,
                                             "Search",
                                             self._search_capabilities_sub_menu,
                                             "Search Capabilities")

    def open_search_value_tracker_requests(self):
        self._open_submenu_page_with_spinner(self._search_menu,
                                             "Search",
                                             self._search_value_tracker_requests_sub_menu,
                                             "Search Value Tracker Requests")

    def open_non_production_time_tracker(self):
        self._open_menu_item(self._non_production_time_tracker, "Non Production Time Tracker")

    def open_supervisor_management(self):
        self._open_menu_item(self._supervisor_management, "Supervisor Management")

    def open_create_recurring_deliverables(self):
        self._open_submenu_page_with_spinner(self._recurring_deliverables_menu,
                                             "Recurring Deliverables",
                                             self._create_recurring_deliverables_sub_menu,
                                             "Create Recurring Deliverables")

    def open_smart_configurations(self):
        self._open_submenu_page_with_spinner(self._admin_menu,
                                             "Admin Menu",
                                             self._smart_configurations,
                                             " SMART Configurations")

    def _open_menu_item(self, option_xpath: str, option_name: str):
        self._open_menu()
        self._driver.click(option_xpath, option_name)
        self._driver.wait_till_spinner_off()

    def _open_submenu_page_with_spinner(self,
                                        option_xpath: str,
                                        option_name: str,
                                        sub_option_xpath: str,
                                        sub_option_name: str):
        self._open_submenu_page(option_xpath, option_name, sub_option_xpath, sub_option_name)
        self._driver.wait_till_spinner_off()

    def _open_submenu_page(self,
                           option_xpath: str,
                           option_name: str,
                           sub_option_xpath: str,
                           sub_option_name: str):
        assert option_xpath is not None and len(option_xpath) > 0
        assert option_name is not None and len(option_name) > 0
        assert sub_option_xpath is not None and len(sub_option_xpath) > 0
        assert sub_option_name is not None and len(sub_option_name) > 0

        self._open_menu()
        is_expanded = self._driver.get_attribute(option_xpath, option_name, 'aria-expanded') \
                          .lower() == 'true'
        self.logger \
            .debug(f"Menu is {is_expanded and 'already ' or ''}expanded so not clicking on {option_name}")
        if not is_expanded:
            self._driver.click(option_xpath, option_name)
        self._driver.click(sub_option_xpath, sub_option_name)

    def _open_menu(self):
        self._driver.wait_till_spinner_off()
        self._driver.click(self._menu_bar, "Menu Bar")

    def display_name(self) -> str:
        return self._driver.get_text(self._user_name_label, 'User Name')
