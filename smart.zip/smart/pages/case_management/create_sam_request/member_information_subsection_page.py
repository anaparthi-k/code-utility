from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.page_base import PageBase
from models.pages.case_management.create_sam_request.member_information_subsection_model import MemberInformationSubsectionModel


class MemberInformationSubsectionPage(PageBase):
 
    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    pass
