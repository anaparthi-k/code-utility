from typing import Tuple, List
from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from models.pages.case_management.create_sam_request.follow_up_needed_subsection_model \
     import FollowUpNeededSubsectionModel
from pages.common.pagination import Pagination
from pages.common.subsection_page import SubsectionPage


class FollowUpNeededSubsectionPage(SubsectionPage):
    _follow_up_date = "//app-add-update-follow-up-needed//*[text()='Follow Up Date']/..//input"
    _follow_up_status = "//app-add-update-follow-up-needed//*[text()='Follow Up Status']/..//select"
    _follow_up_owner = "//app-add-update-follow-up-needed//*[text()='Follow Up Owner']"
    _follow_up_details = "//app-add-update-follow-up-needed//*[text()='Follow Up Details']/..//textarea"
    _follow_up_resolution = "//app-add-update-follow-up-needed//*[text()='Follow Up Resolution']/..//textarea"
    _form_container = "//app-add-update-follow-up-needed"
    _grid_container = "//app-follow-up-needed-details"
    _search = "//app-add-update-follow-up-needed//*[text()='']"
    _save = "//app-add-update-follow-up-needed//*[text()='Add Follow Up']"
    _reset = "//app-add-update-follow-up-needed//*[text()='Reset']"
    _cancel = "//app-add-update-follow-up-needed//*[text()='Cancel']"
    _form_arrow = "//app-add-update-follow-up-needed//*[@data-toggle='collapse']"
    _table_arrow = "//app-follow-up-needed-details//*[@data-toggle='collapse']"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver,converter)

    def get_form_data(self) -> Tuple[str]:
        return self._converter.fields_to_tuple(self._form_container)

    def get_table_data(self) -> List[List[str]]:
        return self._converter.table_to_array(self._grid_container)

    def create_pagination(self) -> Pagination:
        return Pagination(self._driver, self._converter, self._grid_container)

    def fill_form(self, form: FollowUpNeededSubsectionModel) -> None:
        assert isinstance(form, FollowUpNeededSubsectionModel)
        self.enter_follow_up_date(form.follow_up_date)
        self.enter_follow_up_owner(form.follow_up_owner)
        self.enter_follow_up_details(form.follow_up_details)
        self.enter_follow_up_resolution(form.follow_up_resolution)
        self.select_follow_up_status(form.follow_up_status)

    def enter_follow_up_date(self, value):
        self._driver.enter(self._follow_up_date, "Follow Up Date", value, is_clear=True)

    def enter_follow_up_owner(self, value):
        self._enter_auto_populate(self._follow_up_owner, "Follow Up Owner", value)

    def enter_follow_up_details(self, value):
        self._driver.enter(self._follow_up_details, "Follow Up Details", value, is_clear=True)

    def enter_follow_up_resolution(self, value):
        self._driver.enter(self._follow_up_resolution, "Follow Up Resolution", value, is_clear=True)

    def select_follow_up_status(self, value):
        self._driver.select_by_text(self._follow_up_status, "Follow Up Status", value)

    def click_on_reset_button(self) -> None:
        self._driver.click(self._reset, "Reset")

    def click_on_save_button(self) -> None:
        self._driver.click(self._save, "Add Follow Up")

    def click_on_cancel_button(self) -> None:
        self._driver.click(self._cancel, "Cancel")

    def click_on_search_button(self) -> None:
        self._driver.click(self._search, "")

    def click_on_form_expand_button(self) -> None:
        self._driver.click(self._form_arrow, "Form toggle")

    def is_form_section_expanded(self) -> bool:
        return self._driver.get_attribute(self._form_arrow, "Form toggle", 'aria-expanded') == 'true'

    def is_table_section_expanded(self) -> bool:
        return self._driver.get_attribute(self._table_arrow, "Table toggle", 'aria-expanded') == 'true'

    def click_on_table_expand_button(self) -> None:
        self._driver.click(self._table_arrow, "Table toggle")
