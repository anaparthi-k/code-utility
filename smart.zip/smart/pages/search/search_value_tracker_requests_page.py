from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.page_base import PageBase
from pages.common.pagination import Pagination
from models.pages.search.search_value_tracker_requests_model import SearchValueTrackerRequestsModel


class SearchValueTrackerRequestsPage(PageBase):
    _request_id = "//*[text()='Request ID']/following-sibling::input"
    _bp_tracking_id = "//*[text()='BP Tracking ID']/following-sibling::input"
    _follow_up_id = "//*[text()='Follow Up ID']/following-sibling::input"
    _owner = "//*[text()='Owner']"
    _owner_clear = "//*[text()='Owner']/following-sibling::*//*[text()='close']"
    _owner_name_suggestion = "//*[text()='Owner']/following-sibling::*//*[contains(text(),'{0}')]"
    _owner_team = "//*[text()='Owner Team']/following-sibling::select"
    _request_status = "//*[text()='Request Status']/following-sibling::select"
    _requested_by_area = "//*[text()='Requested By Area']/following-sibling::input"
    _group_name = "//*[text()='Group Name']/following-sibling::input"
    _from_start_date = "//*[text()='From Start Date']/following-sibling::*//input"
    _to_start_date = "//*[text()='To Start Date']/following-sibling::*//input"
    _from_completion_date = "//*[text()='From Completion Date']/following-sibling::*//input"
    _to_completion_date = "//*[text()='To Completion Date']/following-sibling::*//input"
    _from_bp_routed_date = "//*[text()='From BP Routed Date']/following-sibling::*//input"
    _to_bp_routed_date = "//*[text()='To BP Routed Date']/following-sibling::*//input"
    _from_follow_up_date = "//*[text()='From Follow Up Date']/following-sibling::*//input"
    _to_follow_up_date = "//*[text()='To Follow Up Date']/following-sibling::*//input"
    _business_partner = "//*[text()='Business Partner']/following-sibling::select"
    _business_partner_routed_status = "//*[text()='Business Partner Routed Status']/following-sibling::select"
    _additional_tracking_category = "//*[text()='Additional Tracking Category']/following-sibling::select"
    _search_value_tracker_requests_button = "//button[text()='Search  Value Tracker Requests']"
    _reset_button = "//*[text()='Reset']"
    _cancel_button = "//*[text()='Cancel']"
    _pagination_container = "//app-request-search-details"
    _search_form = "//app-request-search-input"


    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def value_tracker_requests_search(self, form: SearchValueTrackerRequestsModel):
        self.enter_request_id(form.request_id)
        self.enter_bp_tracking_id(form.bp_tracking_id)
        self.enter_follow_up_id(form.follow_up_id)
        self.enter_owner(form.owner)
        self.select_owner_team(form.owner_team)
        self.select_request_status(form.request_status)
        self.enter_requested_by_area(form.requested_by_area)
        self.enter_group_name(form.group_name)
        self.enter_from_start_date(form.from_start_date)
        self.enter_to_start_date(form.to_start_date)
        self.enter_from_completion_date(form.from_completion_date)
        self.enter_to_completion_date(form.to_completion_date)
        self.enter_from_bp_routed_date(form.from_bp_routed_date)
        self.enter_to_bp_routed_date(form.to_bp_routed_date)
        self.enter_from_follow_up_date(form.from_follow_up_date)
        self.enter_to_follow_up_date(form.to_follow_up_date)
        self.select_business_partner(form.business_partner)
        self.select_business_partner_routed_status(form.business_partner_routed_status)
        self.select_additional_tracking_category(form.additional_tracking_category)

    def enter_request_id(self, value):
        self._driver.enter(self._request_id, "Request ID", value, is_clear=True)

    def enter_bp_tracking_id(self, value):
        self._driver.enter(self._bp_tracking_id, "BP Tracking ID", value, is_clear=True)

    def enter_follow_up_id(self, value):
        self._driver.enter(self._follow_up_id, "Follow Up ID", value, is_clear=True)

    def enter_owner(self, value):
        self._enter_auto_populate(self._owner, 'Owner', value)

    def select_owner_team(self, value):
        self._driver.select_by_text(self._owner_team, "Owner Team", value)

    def select_request_status(self, value):
        self._driver.select_by_text(self._request_status, "Request Status", value)

    def enter_requested_by_area(self, value):
        self._driver.enter(self._requested_by_area, "Requested By Area", value, is_clear=True)

    def enter_group_name(self, value):
        self._driver.enter(self._group_name, "Group Name", value, is_clear=True)

    def enter_from_start_date(self, value):
        self._driver.enter(self._from_start_date, "From Start Date", value, is_clear=True)

    def enter_to_start_date(self, value):
        self._driver.enter(self._to_start_date, "To Start Date", value, is_clear=True)

    def enter_from_completion_date(self, value):
        self._driver.enter(self._from_completion_date, "From Completion Date", value, is_clear=True)

    def enter_to_completion_date(self, value):
        self._driver.enter(self._to_completion_date, "To Completion Date", value, is_clear=True)

    def enter_from_bp_routed_date(self, value):
        self._driver.enter(self._from_bp_routed_date, "From BP Routed Date", value, is_clear=True)

    def enter_to_bp_routed_date(self, value):
        self._driver.enter(self._to_bp_routed_date, "From BP Routed Date", value, is_clear=True)

    def enter_from_follow_up_date(self, value):
        self._driver.enter(self._from_follow_up_date, "From Follow Up Date", value, is_clear=True)

    def enter_to_follow_up_date(self, value):
        self._driver.enter(self._to_follow_up_date, "From Follow Up Date", value, is_clear=True)

    def select_business_partner(self, value):
        self._driver.select_by_text(self._business_partner, "Business Partner", value)

    def select_business_partner_routed_status(self, value):
        self._driver.select_by_text(self._business_partner_routed_status, "Business Partner Routed Status", value)

    def select_additional_tracking_category(self, value):
        self._driver.select_by_text(self._additional_tracking_category, "Additional Tracking Category", value)

    def click_on_search_value_tracker_requests(self):
        self._driver.click(self._search_value_tracker_requests_button, "Search Button")

    def click_on_reset(self):
        self._driver.click(self._reset_button, "Reset Button")

    


    def click_on_search_value_tracker_requests_with_wait(self):
        self.click_on_search_value_tracker_requests()
        self._driver.wait_till_spinner_off()

    def create_pagination(self):
        return Pagination(self._driver, self._converter, self._pagination_container)

    def get_data(self):
        return self._converter.fields_to_tuple(self._search_form)
