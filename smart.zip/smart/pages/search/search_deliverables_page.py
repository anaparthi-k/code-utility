from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.page_base import PageBase


class SearchDeliverablesPage(PageBase):
    _search_task = "//button[text()='Search Tasks']"
    _master_task_id = "//*[text()='Master Task ID']/following-sibling::input"
    _child_task_id = "//*[text()='Child Task ID']/following-sibling::input"
    _edit_button_of_row = "//app-mrd-search-details//*[text()='{0}']/../*[1]/*[1]"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def enter_master_task_id(self, value):
        self._driver.enter(self._master_task_id, "Master Task ID", value, is_clear=True)

    def enter_child_task_id(self, value):
        self._driver.enter(self._child_task_id, "Child Task ID", value, is_clear=True)

    def click_on_search_tasks(self):
        self._driver.click(self._search_task, "Search Tasks")
        self._driver.wait_till_spinner_off()

    def click_on_edit_button(self, value: str):
        self._driver.click(self._edit_button_of_row.format(value), f"Edit of {value}")
        self._driver.wait_till_spinner_off()

