from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.page_base import PageBase
from pages.common.pagination import Pagination
from models.pages.search.search_capabilities_model import SearchCapabilitiesModel


class SearchCapabilitiesPage(PageBase):
    _request_id = "//*[text()='Request ID']/following-sibling::input"
    _title = "//*[text()='Title']/following-sibling::input"
    _category = "//*[text()='Category']/following-sibling::select"
    _sub_category = "//*[text()='Sub Category']/following-sibling::select"
    _impacted_teams = "//*[text()='Impacted Teams']"
    _impacted_teams_down_arrow = "//*[@class='dropdown-multiselect__caret']"
    _impacted_teams_list_value = "//*[text()='Impacted Teams']/following-sibling::*//div/ul[2]/li[1]"
    _submitter = "//*[text()='Submitter']"
    _submitter_clear = "//*[text()='Submitter']/following-sibling::*//*[text()='close']"
    _submitter_name_suggestion = "//*[text()='Submitter']/following-sibling::*//*[contains(text(),'{0}')]"
    _from_submitted_date = "//*[text()='From Submitted Date']/following-sibling::*//input"
    _to_submitted_date = "//*[text()='To Submitted Date']/following-sibling::*//input"
    _owner = "//*[text()='Owner']"
    _owner_clear = "//*[text()='Owner']/following-sibling::*//*[text()='close']"
    _owner_name_suggestion = "//*[text()='Owner']/following-sibling::*//*[contains(text(),'{0}')]"
    _status = "//*[text()='Status']/following-sibling::select" 
    _from_completion_date = "//*[text()='From Completion Date']/following-sibling::*//input"
    _to_completion_date = "//*[text()='To Completion Date']/following-sibling::*//input"
    _search_capabilities_requests_button = "//button[text()='Search  Capability Requests']"
    _reset_button = "//*[text()='Reset']"
    _cancel_button = "//*[text()='Cancel']"
    _pagination_container = "//app-request-search-details"
    _search_form = "//app-request-search-input"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def capabilities_search(self, form: SearchCapabilitiesModel):
        self.enter_request_id(form.request_id)
        self.enter_title(form.title)
        self.select_category(form.category)
        self.select_sub_category(form.sub_category)
        self.select_impacted_teams(form.impacted_teams)
        self.enter_submitter(form.submitter)
        self.enter_from_submitted_date(form.from_submitted_date)
        self.enter_to_submitted_date(form.to_submitted_date)
        self.enter_owner(form.owner)
        self.select_status(form.status)
        self.enter_from_completion_date(form.from_completion_date)
        self.enter_to_completion_date(form.to_completion_date)
        self.click_on_search_capability_requests()

    def enter_request_id(self, value):
        self._driver.enter(self._request_id, "Request ID", value, is_clear=True)

    def enter_title(self, value):
        self._driver.enter(self._title, "Title", value, is_clear=True)

    def select_category(self, value):
        self._driver.select_by_text(self._category, "Category", value)

    def select_sub_category(self, value):
        self._driver.select_by_text(self._sub_category, "Sub Category", value)

    def select_impacted_teams(self, value):
        self._driver.click(self._impacted_teams_down_arrow, "Click Down Arrow")
        self._driver.click(self._impacted_teams_list_value, "Impacted Teams List Item")

    def enter_submitter(self, value: str):
        self._enter_auto_populate(self._submitter, 'Submitter', value)

    def enter_from_submitted_date(self, value):
        self._driver.enter(self._from_submitted_date, "From Submitted Date", value, is_clear=True)

    def enter_to_submitted_date(self, value):
        self._driver.enter(self._to_submitted_date, "To Submitted Date", value, is_clear=True)

    def enter_owner(self, value: str):
        self._enter_auto_populate(self._owner, 'Owner', value)

    def select_status(self, value):
        self._driver.select_by_text(self._status, "Status", value)

    def enter_from_completion_date(self, value):
        self._driver.enter(self._from_completion_date, "From completion Date", value, is_clear=True)

    def enter_to_completion_date(self, value):
        self._driver.enter(self._to_completion_date, "To completion Date", value, is_clear=True)

    def click_on_search_capability_requests(self):
        self._driver.click(self._search_capabilities_requests_button, "Search Button")

    def click_on_reset(self):
        self._driver.click(self._reset_button, "Reset Button")

    


    def click_on_search_capability_requests_with_wait(self):
        self.click_on_search_capability_requests()
        self._driver.wait_till_spinner_off()

    def create_pagination(self):
        return Pagination(self._driver, self._converter, self._pagination_container)

    def get_data(self):
        return self._converter.fields_to_tuple(self._search_form)
