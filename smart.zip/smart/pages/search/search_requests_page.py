from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.common.pagination import Pagination
from pages.page_base import PageBase
from models.pages.search.search_requests_model import *


class SearchRequestsPage(PageBase):
    _request_id = "//*[text()='Request ID']/following-sibling::input"
    _bp_tracking_id = "//*[text()='BP Tracking ID']/following-sibling::input"
    _call_tracking_id = "//*[text()='Call Tracking ID']/following-sibling::input"
    _follow_up_id = "//*[text()='Follow Up ID']/following-sibling::input"
    _member_id = "//*[text()='Member ID']/following-sibling::input"
    _member_first_name = "//*[text()='Member First Name']/following-sibling::input"
    _member_last_name = "//*[text()='Member Last Name']/following-sibling::input"
    _group_name = "//*[text()='Group Name']/following-sibling::input"
    _from_created_date = "//*[text()='From Created Date']/following-sibling::*//input"
    _to_created_date = "//*[text()='To Created Date']/following-sibling::*//input"
    _from_uhg_received_date = "//*[text()='From UHG Received Date']/following-sibling::*//input"
    _to_uhg_received_date = "//*[text()='To UHG Received Date']/following-sibling::*//input"
    _from_resolution_date = "//*[text()='From Resolution Date']/following-sibling::*//input"
    _to_resolution_date = "//*[text()='To Resolution Date']/following-sibling::*//input"
    _from_bp_routed_date = "//*[text()='From BP Routed Date']/following-sibling::*//input"
    _to_bp_routed_date = "//*[text()='To BP Routed Date']/following-sibling::*//input"
    _from_call_tracking_date = "//*[text()='From Call Tracking Date']/following-sibling::*//input"
    _to_call_tracking_date = "//*[text()='To Call Tracking Date']/following-sibling::*//input"
    _from_follow_up_date = "//*[text()='From Follow Up Date']/following-sibling::*//input"
    _to_follow_up_date = "//*[text()='To Follow Up Date']/following-sibling::*//input"
    _search_type = "//*[text()='Search Type']/following-sibling::select"
    _submitter = "//*[text()='Submitter']/following-sibling::select"
    _request_status = "//*[text()='Request Status']/following-sibling::select"
    _business_partner = "//*[text()='Business Partner']/following-sibling::select"
    _business_partner_routed_status = "//*[text()='Business Partner Routed Status']/following-sibling::select"
    _inbound_outbound = "//*[text()='Inbound/Outbound']/following-sibling::select"
    _additional_tracking_category = "//*[text()='Additional Tracking Category']/following-sibling::select"
    _search_requests = "//button[text()='Search  Requests']"
    _reset = "//*[text()='Reset']"
    _cancel = "//*[text()='Cancel']"
    _pagination_container = "//app-request-search-details"
    _owner = "//*[text()='Owner']"
    _search_form = "//app-request-search-input"
    _root_cause_category = "//*[text()='Root Cause Category']/following-sibling::select"
    _root_cause_sub_category = "//*[text()='Root Cause Sub Category']/following-sibling::select"
    _gps_employer_id = "//*[text()='GPS Employer ID']/following-sibling::input"
 
    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def sam_search(self, form: SamSearchRequestsModel):
        self.select_search_type(form.search_type)
        self.enter_request_id(form.request_id)
        self.enter_bp_tracking_id(form.bp_tracking_id)
        self.enter_call_tracking_id(form.call_tracking_id)
        self.enter_follow_up_id(form.follow_up_id)
        self.enter_member_id(form.member_id)
        self.enter_member_first_name(form.member_first_name)
        self.enter_member_last_name(form.member_last_name)
        self.enter_group_name(form.group_name)
        self.enter_from_created_date(form.from_created_date)
        self.enter_to_created_date(form.to_created_date)
        self.enter_from_uhg_received_date(form.from_uhg_received_date)
        self.enter_to_uhg_received_date(form.to_uhg_received_date)
        self.enter_from_resolution_date(form.from_resolution_date)
        self.enter_to_resolution_date(form.to_resolution_date)
        self.enter_from_bp_routed_date(form.from_bp_routed_date)
        self.enter_to_bp_routed_date(form.to_bp_routed_date)
        self.enter_from_call_tracking_date(form.from_call_tracking_date)
        self.enter_to_call_tracking_date(form.to_call_tracking_date)
        self.enter_from_follow_up_date(form.from_follow_up_date)
        self.enter_to_follow_up_date(form.to_follow_up_date)
        self.select_submitter(form.submitter)
        self.select_request_status(form.request_status)
        self.select_business_partner(form.business_partner)
        self.select_business_partner_routed_status(form.business_partner_routed_status)
        self.select_inbound_outbound(form.inbound_outbound)
        self.select_additional_tracking_category(form.additional_tracking_category)

    def crt_search(self, form: CrtSearchRequestsModel):
        self.enter_request_id(form.request_id)
        self.enter_bp_tracking_id(form.bp_tracking_id)
        self.enter_follow_up_id(form.follow_up_id)
        self.enter_group_name(form.group_name)
        self.enter_from_created_date(form.from_created_date)
        self.enter_to_created_date(form.to_created_date)
        self.enter_from_uhg_received_date(form.from_uhg_received_date)
        self.enter_to_uhg_received_date(form.to_uhg_received_date)
        self.enter_from_resolution_date(form.from_resolution_date)
        self.enter_to_resolution_date(form.to_resolution_date)
        self.enter_from_bp_routed_date(form.from_bp_routed_date)
        self.enter_to_bp_routed_date(form.to_bp_routed_date)
        self.enter_from_follow_up_date(form.from_follow_up_date)
        self.enter_to_follow_up_date(form.to_follow_up_date)
        self.enter_gps_employer_id(form.gps_employer_id)
        self.select_search_type(form.search_type)
        self.select_submitter(form.submitter)
        self.select_request_status(form.request_status)
        self.select_business_partner(form.business_partner)
        self.select_business_partner_routed_status(form.business_partner_routed_status)
        self.select_root_cause_category(form.root_cause_category)
        self.select_root_cause_sub_category(form.root_cause_sub_category)

    def enter_request_id(self, value):
        self._driver.enter(self._request_id, "Request ID", value, is_clear=True)

    def enter_owner(self, value: str):
        self._enter_auto_populate(self._owner, 'owner', value)

    def enter_bp_tracking_id(self, value):
        self._driver.enter(self._bp_tracking_id, "BP Tracking ID", value, is_clear=True)

    def enter_call_tracking_id(self, value):
        self._driver.enter(self._call_tracking_id, "Call Tracking ID", value, is_clear=True)

    def enter_gps_employer_id(self, value):
        self._driver.enter(self._gps_employer_id, "GPS Employer ID", value, is_clear=True)

    def enter_follow_up_id(self, value):
        self._driver.enter(self._follow_up_id, "Follow Up ID", value, is_clear=True)

    def enter_member_id(self, value):
        self._driver.enter(self._member_id, "Member ID", value, is_clear=True)

    def enter_member_first_name(self, value):
        self._driver.enter(self._member_first_name, "Member First Name", value, is_clear=True)

    def enter_member_last_name(self, value):
        self._driver.enter(self._member_last_name, "Member Last Name", value, is_clear=True)

    def enter_group_name(self, value):
        self._driver.enter(self._group_name, "Group Name", value, is_clear=True)

    def enter_from_created_date(self, value):
        self._driver.enter(self._from_created_date, "From Created Date", value, is_clear=True)

    def enter_to_created_date(self, value):
        self._driver.enter(self._to_created_date, "To Created Date", value, is_clear=True)

    def enter_from_uhg_received_date(self, value):
        self._driver.enter(self._from_uhg_received_date, "From UHG Received Date", value, is_clear=True)

    def enter_to_uhg_received_date(self, value):
        self._driver.enter(self._to_uhg_received_date, "To UHG Received Date", value, is_clear=True)

    def enter_from_resolution_date(self, value):
        self._driver.enter(self._from_resolution_date, "From Resolution Date", value, is_clear=True)

    def enter_to_resolution_date(self, value):
        self._driver.enter(self._to_resolution_date, "To Resolution Date", value, is_clear=True)

    def enter_from_bp_routed_date(self, value):
        self._driver.enter(self._from_bp_routed_date, "From BP Routed Date", value, is_clear=True)

    def enter_to_bp_routed_date(self, value):
        self._driver.enter(self._to_bp_routed_date, "To BP Routed Date", value, is_clear=True)

    def enter_from_call_tracking_date(self, value):
        self._driver.enter(self._from_call_tracking_date, "From Call Tracking Date", value, is_clear=True)

    def enter_to_call_tracking_date(self, value):
        self._driver.enter(self._to_call_tracking_date, "To Call Tracking Date", value, is_clear=True)

    def enter_from_follow_up_date(self, value):
        self._driver.enter(self._from_follow_up_date, "From Follow Up Date", value, is_clear=True)

    def enter_to_follow_up_date(self, value):
        self._driver.enter(self._to_follow_up_date, "To Follow Up Date", value, is_clear=True)

    def select_search_type(self, value):
        self._driver.select_by_text(self._search_type, "Search Type", value)

    def select_submitter(self, value):
        self._driver.select_by_text(self._submitter, "Submitter", value)

    def select_root_cause_category(self, value):
        self._driver.select_by_text(self._root_cause_category, "Root Cause Category", value)

    def select_root_cause_sub_category(self, value):
        self._driver.select_by_text(self._root_cause_sub_category, "Root Cause Sub Category", value)

    def select_request_status(self, value):
        self._driver.select_by_text(self._request_status, "Request Status", value)

    def select_business_partner(self, value):
        self._driver.select_by_text(self._business_partner, "Business Partner", value)

    def select_business_partner_routed_status(self, value):
        self._driver.select_by_text(self._business_partner_routed_status, "Business Partner Routed Status", value)

    def select_inbound_outbound(self, value):
        self._driver.select_by_text(self._inbound_outbound, "InboundOutbound", value)

    def select_additional_tracking_category(self, value):
        self._driver.select_by_text(self._additional_tracking_category, "Additional Tracking Category", value)

    def click_on_search_requests_with_wait(self):
        self.click_on_search_requests()
        self._driver.wait_till_spinner_off()

    def click_on_search_requests(self):
        self._driver.click(self._search_requests, "Search Requests")

    def click_on_reset(self):
        self._driver.click(self._reset, "Reset")

    def click_on_cancel(self):
        self._driver.click(self._cancel, "Cancel")

    def create_pagination(self):
        return Pagination(self._driver, self._converter, self._pagination_container)

    def get_data(self):
        return self._converter.fields_to_tuple(self._search_form)

    def is_visible_call_tracking_id(self):
        return self._driver.is_visible(self._call_tracking_id)

    def is_visible_member_id(self):
        return self._driver.is_visible(self._member_id)

    def is_visible_member_first_name(self):
        return self._driver.is_visible(self._member_first_name)

    def is_visible_member_last_name(self):
        return self._driver.is_visible(self._member_last_name)

    def is_visible_group_name(self):
        return self._driver.is_visible(self._group_name)
