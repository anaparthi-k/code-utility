from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.page_base import PageBase
from models.pages.capability_request.create_capability_request_model import CreateCapabilityRequestModel


class CreateCapabilityRequestPage(PageBase):
 
    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    pass
