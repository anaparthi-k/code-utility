from typing import List

from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from models.pages.scorecard.scorecard_generation_model import ScorecardGenerationModel
from pages.page_base import PageBase


class ScorecardGenerationPage(PageBase):
    _year = "//*[text()='Select Year']/following-sibling::select"
    _quarter = "//*[text()='Select Month / Quarter ']/following-sibling::select"
    _client = "//*[text()='Select Client']"
    _generate_ppt = "//*[contains(text(),'Generate PPT')]"
    _generate_csv = "//*[contains(text(),'Generate CSV')]"
    _header_title = "//*[@class='sctn-hdr']"
    _all_item = "//*[text()='Select Client(s)']/following-sibling::div//ul[2]//li"
    _details = "//*[text()='Details']"
    _client_list_down_arrow = "//*[text()='Select Client(s)']/following-sibling::*/*"
    _client_list_text_box = "//*[text()='Select Client(s)']/following-sibling::*//input"
    _client_name_list_item = '//*[text()="Select Client(s)"]/following-sibling::*//*[contains(text(),"{0}")]'
    ppt_download_count = 0

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def generate_csv(self, form: ScorecardGenerationModel):
        self.enter_form(form)
        self.click_on_generate_csv()
        pass

    def enter_form(self, form: ScorecardGenerationModel):
        self._driver.select_by_text(self._year, "Year", form.year)
        self._driver.select_by_text(self._quarter, "Select Month / Quarter ", form.quarter)

    def _enter_form_client(self, form: ScorecardGenerationModel):
        self.select_multiple_clients(form.clients)
        pass

    def generate_single_ppt(self, form: ScorecardGenerationModel):
        self.enter_form(form)
        self._enter_form_client(form)
        self.click_on_generate_ppt()
        pass

    def generate_multiple_ppt(self, form: ScorecardGenerationModel):
        self.enter_form(form)
        self.select_multiple_clients(form.clients)
        self.click_on_generate_ppt()
        pass

    def select_multiple_clients(self, clients: List[str]):
        assert clients is not None and len(clients) > 0
        self.ppt_download_count = 0
        for client in clients:
            self._driver.click(self._client_list_down_arrow, "Client Down arrow")
            self._driver.enter(self._client_list_text_box, "Client Search", client, is_clear=True)
            self._driver.click(self._client_name_list_item.format(client), "Client Name Item")
            self.ppt_download_count += 1

    def generate_all_ppt(self, form: ScorecardGenerationModel):
        self.enter_form(form)
        self.ppt_download_count = 0
        all_items = self._converter.elements_text_to_array(self._all_item)
        for item_name in all_items:
            self._driver.click(self._client_list_down_arrow, "Client Down arrow")
            self._driver.enter(self._client_list_text_box, "Client Search", item_name, is_clear=True)
            self._driver.click(self._client_name_list_item.format(item_name), "Client Name Item")
            self.ppt_download_count += 1
        self.click_on_generate_ppt()

    def click_on_generate_csv(self):
        self._driver.click(self._generate_csv, "Generate CSV")
        self._driver.wait_till_spinner_off()

    def click_on_generate_ppt(self):
        self._driver.click(self._generate_ppt, 'Generate PPT')
        self._driver.wait_till_spinner_off()

    def click_on_details(self):
        self._driver.click(self._details, "Details")

    def get_header_title(self):
        return self._driver.get_text(self._header_title, 'header title')
