from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from models.pages.scorecard.scorecard_history_model import ScorecardHistoryModel
from pages.page_base import PageBase


class ScorecardHistoryPage(PageBase):
    _from_date = "//*[text()='Date From']/following-sibling::*//input"
    _to_date = "//*[text()='Date To']/following-sibling::*//input"
    _customer_name = "//*[text()='Customer Name']/following-sibling::*//input"
    _customer_name_label = "//*[text()='Customer Name']"
    _view_history_button = "//*[@value='View History']"
    _reset_button = "//*[@value='Reset']"
    _action_download_button = "//*[@title='Download']"
    _header_title_label = '//*[@class="sctn-hdr"]'
    _search_form_container = '//app-osc-reports-history'
    _customer_clear = "//*[text()='Customer Name']/following-sibling::*//*[text()='close']"
    _customer_list_path = "//*[text()='Customer Name']/following-sibling::*//*[contains(text(),'{0}')]"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def view_history(self, form: ScorecardHistoryModel):
        self._enter_form(form)
        self.click_on_view_history()
        pass

    def _enter_form(self, form: ScorecardHistoryModel):
        self.enter_from_date(form.from_date)
        self.enter_to_date(form.to_date)
        self._enter_auto_populate(self._customer_name_label, 'Customer Name', form.customer_name)
        pass

    def enter_from_date(self, value):
        self._driver.enter(self._from_date, "Date From", value, is_clear=True)

    def enter_to_date(self, value):
        self._driver.enter(self._to_date, "Date To", value, is_clear=True)

    def click_on_view_history(self):
        self._driver.click(self._view_history_button, "View History")
        self._driver.wait_till_spinner_off()

    def click_on_reset(self):
        self._driver.click(self._reset_button, "Reset")
        self._driver.wait_till_spinner_off()

    def click_on_action_download(self):
        self._driver.click(self._action_download_button, "Download")
        self._driver.wait_till_spinner_off()

    def get_header_title(self):
        return self._driver.get_text(self._header_title_label, 'header title')

    def get_data(self):
        return self._converter.fields_to_tuple(self._search_form_container)
