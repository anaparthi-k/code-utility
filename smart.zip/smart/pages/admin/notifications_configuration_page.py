from typing import List
from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from models.pages.admin.notifications_configuration_model import NotificationsConfigurationSearchModel, \
    NotificationsConfigurationAddModel
from pages.page_base import PageBase


class NotificationsConfigurationSearchPage(PageBase):
    _metric_name = "//*[text()='Metric']/following-sibling::select"
    _key_name = "//*[text()='Key']/following-sibling::select"
    _customer_label = "//*[text()='Customer']"
    # _customer = "//*[text()='Customer']/following-sibling::*//input"
    # _customer_suggestion = "//*[text()='Customer']/following-sibling::*//*[contains(text(),'{0}')]"
    # _customer_clear = "//*[text()='Customer']/following-sibling::*//*[text()='close']"
    _search = "//*[text()='Search']"
    _add_notification = "//*[text()='Add Notifications']"
    _reset = "//*[text()='Reset']"
    _cancel = "//*[text()='Cancel']"
    _yes = "//*[text()='Yes']"
    _delete = "//*[text()='Delete']"
    # _home_page = "//*[text()='Attention Needed']"
    _search_label_xpath = "//*[text()='Notifications-Configuration | Search']"
    _search_form_container = "//app-search-notification"
    _header_title = "//*[@class='sctn-hdr']"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def perform_search(self, form: NotificationsConfigurationSearchModel):
        self._driver.select_by_text(self._metric_name, 'Metric', form.metric_name)
        self._driver.select_by_text(self._key_name, 'Key Name', form.key_name)
        self._enter_auto_populate(self._customer_label, 'Customer', form.customer)
        self.click_on_search()

    def click_on_search(self):
        self._driver.click(self._search, 'Search')
        self._driver.wait_till_spinner_off()

    def click_on_add(self):
        self._driver.click(self._add_notification, 'Add Notifications')

    def click_on_reset_button(self):
        self._driver.click(self._reset, "Reset")

    def click_on_delete_button(self):
        self._driver.click(self._delete, "Delete")

    def click_on_yes(self):
        self._driver.click(self._yes, 'Yes')

    def click_on_cancel(self):
        self._driver.click(self._cancel, 'Cancel')
        self.click_on_yes()
        self._driver.wait_till_spinner_off()

    def get_header_text(self) -> str:
        return self._driver.get_text(self._header_title, "Header Title")

    def get_data(self) -> List[List[str]]:
        return self._converter.fields_to_tuple(self._search_form_container)

    def get_header_title(self):
        return self._driver.get_text(self._header_title, 'header title')


class NotificationsConfigurationAddPage(PageBase):
    _metric_name = "//*[text()='Metric']/following-sibling::select"
    _key_name = "//*[text()='Key']/following-sibling::select"
    _customer_name = "//*[text()='Customer Name']/following-sibling::select"
    _upper_threshold = "//*[text()='Upper Threshold']/following-sibling::input"
    _lower_threshold = "//*[text()='Lower Threshold']/following-sibling::input"
    _value_by = "//*[text()='Value By']/following-sibling::select"
    _search_add_notification = "//*[text()='Add Notifications']"
    _add_button = "//*[@value='Add Notifications']"
    _reset_button = "//*[@value='Reset']"
    _cancel_button = "//*[@value='Cancel']"
    _yes_button = "//*[text()='Yes']"
    # _no_button = "//*[text()='No']"
    _add_label_xpath = "//*[text()='Notifications Configuration | Add Notifications']"
    _add_form_container = "//app-add-notification"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def perform_add_notification(self, form: NotificationsConfigurationAddModel):
        self.click_on_search_add_notifications()
        self.enter_form(form)
        self.click_on_add_button()

    def enter_form(self, form: NotificationsConfigurationAddModel):
        self._driver.select_by_text(self._customer_name, 'Customer Name', form.customer_name)
        self._driver.select_by_text(self._metric_name, 'Metric', form.metric_name)
        self._driver.select_by_text(self._key_name, 'Key Name', form.key_name)
        self._driver.enter(self._upper_threshold, 'Upper Threshold', form.upper_threshold, is_clear=False)
        self._driver.enter(self._lower_threshold, 'Lower Threshold', form.lower_threshold, is_clear=False)
        self._driver.select_by_text(self._value_by, 'Value by', form.value_by)
        pass

    def click_on_search_add_notifications(self):
        self._driver.click(self._search_add_notification, 'Search Add Notification')

    def click_on_add_button(self):
        self._driver.click(self._add_button, 'Add Notifications')

    def click_on_reset_button(self):
        self._driver.click(self._reset_button, 'Reset')

    def click_on_cancel_button(self):
        self._driver.click(self._cancel_button, 'Cancel')
        self.click_on_yes_button()
        self._driver.wait_till_spinner_off()

    def click_on_yes_button(self):
        self._driver.click(self._yes_button, 'Yes')

    def get_header_text(self) -> str:
        return self._driver.get_text(self._add_label_xpath, "Header Title")

    def get_data(self):
        return self._converter.fields_to_tuple(self._add_form_container)
