import time
from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from core.keyboard import Keyboard
from models.pages.admin.scorecard_update_model import ScorecardUpdateModel
from pages.common.form_container import FormContainer
from pages.page_base import PageBase
from utils.path import Path


class ScorecardUpdatePage(FormContainer, PageBase):
    _year = "//*[text()='Year']/following-sibling::select"
    _quarter = "//*[text()='Quarter']/following-sibling::select"
    _customer = "//*[text()='Customer']/following-sibling::*//input"
    _upload_scorecard_button = "//*[text()=' Upload Scorecard ']"
    _upload_scorecard_file_uploader = "//*[text()=' Upload Scorecard ']/following-sibling::input"
    _reset_button = "//*[@value='Reset']"
    _description = "//*[text()='Description ']/following-sibling::textarea"
    _upload_button = "//*[@value='Upload']"
    _table_container = "//*[@class='wdgt-sctn']"
    _form_container = "//app-update-score-card"
    _delete_button = "//*[text()='Selected Files']/following-sibling::*//*[@title='Remove Document']"
    _header_title_label = '//*[@class="sctn-hdr"]'

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        FormContainer.__init__(self, driver, converter)
        PageBase.__init__(self, driver, converter)

    def search(self, form: ScorecardUpdateModel):
        self.fill_search_fields(form)
        self.click_on_upload_scorecard()

    def upload(self, form: ScorecardUpdateModel):
        self.fill_upload(form)
        self.click_on_upload()

    def fill_upload(self, form: ScorecardUpdateModel):
        self.fill_search_fields(form)
        self.click_on_upload_scorecard()
        self.enter_file_path_in_dialog(form.file_path)
        self.enter_description(form.description)

    def fill_search_fields(self, form):
        self.select_year(form.year)
        self.select_quarter(form.quarter)
        self.enter_customer(form.customer)

    def enter_file_path_in_dialog(self, path: str):
        if path is not None and len(path) > 0:
            pass
        time.sleep(2)
        full_path = Path.get_full_path(path)
        self.logger.debug("Full path of file is {0}".format(full_path))
        Keyboard.write(full_path)
        Keyboard.enter()
        time.sleep(1)
        pass

    def select_year(self, year: str):
        self._driver.select_by_text(self._year, "Year", year)

    def select_quarter(self, value: str):
        self._driver.select_by_text(self._quarter, "Quarter", value)

    def click_on_upload_scorecard(self):
        self._driver.click(self._upload_scorecard_button, "Upload Scorecard")
        self._driver.wait_till_spinner_off()

    def click_on_upload(self):
        self._driver.click(self._upload_button, "Upload")
        self._driver.wait_till_spinner_off()

    def click_on_reset_button(self):
        self._driver.click(self._reset_button, "Reset")

    def click_on_delete(self):
        self._driver.click(self._delete_button, "Delete")

    def enter_customer(self, value: str):
        self._driver.enter(self._customer, "Customer", value, is_clear=False)
        customer_list_path = "//*[text()='Customer']/following-sibling::*//*[contains(text(),'%s')]" % value
        self._driver.click(customer_list_path, "Customer List")

    def enter_description(self, value: str):
        self._driver.enter(self._description, 'description', value, is_clear=False)

    def is_description_exists(self):
        return self._driver.is_exists(self._description)

    def get_data(self):
        return self._converter.fields_to_tuple(self._form_container)

    def get_header_title(self):
        return self._driver.get_text(self._header_title_label, 'header title')
