from typing import List
from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.page_base import PageBase
from models.pages.admin.manage_user_model import ManageUserSearchModel, \
    ManageUserAddModel


class ManageUserSearchForm(PageBase):
    _ms_id = "//*[text()='MS ID']/following-sibling::input"
    _first_name = "//*[text()='First Name']/following-sibling::input"
    _last_name = "//*[text()='Last Name']/following-sibling::input"
    _status = "//*[text()='Status']/following-sibling::select"
    _search_button = "//*[text()='Search']"
    _add_user_button = "//*[text()='Add User']"
    _reset_button = "//*[text()='Reset']"
    _search_form_container = "//app-manage-user"
    _header_title = "//*[@class='sctn-hdr']"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def perform_search(self, form: ManageUserSearchModel):
        self.enter_form(form)
        self.click_on_search()

    def enter_form(self, form: ManageUserSearchModel):
        self.enter_ms_id(form.ms_id)
        self.enter_first_name(form.first_name)
        self.enter_last_name(form.last_name)
        self.select_status(form.status)

    def enter_ms_id(self, value: str):
        self._driver.enter(self._ms_id, 'MS ID', value, is_clear=True)

    def enter_first_name(self, value: str):
        self._driver.enter(self._first_name, 'First Name', value, is_clear=True)

    def enter_last_name(self, value: str):
        self._driver.enter(self._last_name, 'Last Name', value, is_clear=True)

    def select_status(self, value: str):
        self._driver.select_by_text(self._status, 'Status', value)

    def click_on_search(self):
        self._driver.click(self._search_button, 'Search')
        self._driver.wait_till_spinner_off()

    def click_on_add_user_button(self):
        self._driver.click(self._add_user_button, "Add User")

    def click_on_reset_button(self):
        self._driver.click(self._reset_button, "Reset")

    def get_data(self) -> List[List[str]]:
        return self._converter.fields_to_tuple(self._search_form_container)

    def get_header_text(self) -> str:
        return self._driver.get_text(self._header_title, "Header Title")


class ManageUserAddForm(PageBase):
    _ms_id = "//*[text()='MS ID']/following-sibling::input"
    _first_name = "//*[text()='First Name']/following-sibling::input"
    _last_name = "//*[text()='Last Name']/following-sibling::input"
    _email_id = "//*[text()='Email ID']/following-sibling::input"
    _status = "//*[text()='Status']/following-sibling::select"
    _supervisor_ms_id = ""
    _add_user_button = "//*[text()='Add User']"
    _reset_button = "//*[text()='Reset']"
    _cancel_button = "//*[text()='Cancel']"
    _header_title = "//*[@class='sctn-hdr']"
    _yes_button = "//*[text()='Yes']"
    _add_user_form_container = "//app-add-edit-user"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def add_user(self, form: ManageUserAddModel):
        self.enter_form(form)
        self.click_on_add_user_button()
        pass

    def enter_form(self, form: ManageUserAddModel):
        self.enter_ms_id(form.ms_id)
        self.enter_first_name(form.first_name)
        self.enter_last_name(form.last_name)
        self.enter_email_id(form.email_id)
        self.select_status(form.status)
        pass

    def enter_ms_id(self, value: str):
        self._driver.enter(self._ms_id, 'MS ID', value, is_clear=True)

    def enter_first_name(self, value: str):
        self._driver.enter(self._first_name, 'First Name', value, is_clear=True)

    def enter_last_name(self, value: str):
        self._driver.enter(self._last_name, 'Last Name', value, is_clear=True)

    def enter_email_id(self, value: str):
        self._driver.enter(self._email_id, 'Email ID', value, is_clear=True)

    def select_status(self, value: str):
        self._driver.select_by_text(self._status, 'Status', value)

    def click_on_add_user_button(self):
        self._driver.click(self._add_user_button, "Add User")

    def click_on_cancel_button(self):
        self._driver.click(self._cancel_button, "Cancel")

    def click_on_reset_button(self):
        self._driver.click(self._reset_button, "Reset")

    def click_on_yes_button(self):
        self._driver.click(self._yes_button, "Yes")

    def get_data(self):
        self._driver.wait_till_exists(self._add_user_form_container,'Add or edit User Form')
        return self._converter.fields_to_tuple(self._add_user_form_container)

    def get_header_text(self) -> str:
        return self._driver.get_text(self._header_title, "Header Title")
