from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from models.pages.admin.group_mapping_model import GroupMappingModel
from pages.page_base import PageBase


class GroupMappingPage(PageBase):
    _customer_name = "//*[text()='Customer Name']/following-sibling::select"
    _metrics = "//*[text()='Metrics']/following-sibling::select"
    _group_name_column_header = "//*[text()='Group Name Column Header']/following-sibling::input"
    _name_to_replace = "//*[text()='Name To Replace']/following-sibling::input"
    _new_name = "//*[text()='New Name']/following-sibling::input"
    _search_button = "//input[@value='Search']"
    _map_to_group_name = "//input[@value='Map To Group Name']"
    _reset_button = "//input[@value='Reset']"
    _edit_button = "//tbody/tr[1]/td[1]/a[1]/em[1]"
    _update_button = "//input[@value='Update']"
    _delete_button = "//tbody/tr[1]/td[1]/a[2]/em[1]"
    _delete_button_of_row = "//tbody/tr[1]"
    _add_form_group = "//app-text-replace"
    _header_title_label = '//*[@class="sctn-hdr"]'

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def search(self, form: GroupMappingModel):
        self._enter_form(form)
        self.click_on_search()
        pass

    def map_to_group_name(self, form: GroupMappingModel):
        self._enter_form_group_mapping(form)
        self.click_on_map_to_group_name()
        pass

    def _enter_form(self, form: GroupMappingModel):
        self.enter_customer_name(form.customer_name)
        self.select_metrics(form.metrics)
        pass

    def _enter_form_group_mapping(self, form: GroupMappingModel):
        self._enter_form(form)
        self.enter_name_to_replace(form.name_to_replace)
        pass

    def enter_name_to_replace(self, value):
        self._driver.enter(self._name_to_replace, "Name To Replace", value, is_clear=True)

    def get_data(self):
        return self._converter.fields_to_tuple(self._add_form_group)

    def click_on_search(self):
        self._driver.click(self._search_button, "Search")
        pass

    def enter_customer_name(self, value):
        self._driver.select_by_text(self._customer_name, "Customer Name", value)
        pass

    def select_metrics(self, value):
        self._driver.select_by_text(self._metrics, "Metrics", value)
        pass

    def click_on_map_to_group_name(self):
        self._driver.click(self._map_to_group_name, "Map To Group Name")
        pass

    def click_on_reset_button(self):
        self._driver.click(self._reset_button, "reset")
        pass

    def click_on_update_button(self):
        self._driver.click(self._update_button, "update")

    def is_row_exists_with(self) -> bool:
        return self._driver.is_exists(self._delete_button)

    def click_on_edit_button(self):
        self._driver.click(self._edit_button, "Edit")

    def update_field(self, form: GroupMappingModel):
        self.enter_name_to_replace(form.name_to_replace)
        self.click_on_update_button()

    def click_on_delete_button(self):
        self._driver.click(self._delete_button, "Delete")

    def get_header_title(self):
        return self._driver.get_text(self._header_title_label, 'header title')
