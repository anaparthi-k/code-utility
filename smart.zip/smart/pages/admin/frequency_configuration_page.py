from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from models.pages.admin.frequency_configuration_model import FrequencyConfigurationModel
from pages.page_base import PageBase


class FrequencyConfigurationPage(PageBase):
    _customer_name = "//*[text()='Customer Name']/following-sibling::*//input"
    _frequency = "//*[text()='Frequency']/following-sibling::select"
    _add_frequency = '//*[@value="Add Frequency"]'
    _search_button = '//*[@value="Search"]'
    _edit_button = '//*[@title="Edit Frequency"]'
    _sae = "//*[text()='SAE']/following-sibling::*//input"
    _update_frequency = '//*[@value="Update"]'
    _header_title_label = '//*[@class="sctn-hdr"]'

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def search(self, form: FrequencyConfigurationModel):
        self._enter_form(form)
        self.click_on_search()
        pass

    def save(self, form: FrequencyConfigurationModel):
        self._enter_form(form)
        self.click_on_add_frequency()
        pass

    def update(self, form: FrequencyConfigurationModel):
        self.click_on_edit()
        self.enter_sae(form.sae)
        self.click_on_update()
        pass

    def _enter_form(self, form: FrequencyConfigurationModel):
        self.enter_customer_name(form.customer_name)
        self.select_quarter(form.quarter)
        self.enter_sae(form.sae)
        pass

    def enter_customer_name(self, value):
        self._driver.enter(self._customer_name, "Customer Name", value, is_clear=True)

    def enter_sae(self, value):
        self._driver.enter(self._sae, "SAM", value, is_clear=True)

    def select_quarter(self, value):
        self._driver.select_by_text(self._frequency, "Frequency", value)

    def click_on_add_frequency(self):
        self._driver.click(self._add_frequency, "Add Frequency")
        self._driver.wait_till_spinner_off()

    def click_on_edit(self):
        self._driver.click(self._edit_button, 'Edit Button')
        self._driver.wait_till_spinner_off()

    def click_on_update(self):
        self._driver.click(self._update_frequency, 'Update Frequency')
        self._driver.wait_till_spinner_off()

    def click_on_search(self):
        self._driver.click(self._search_button, "Search")
        self._driver.wait_till_spinner_off()

    def get_header_title(self):
        return self._driver.get_text(self._header_title_label, 'header title')
