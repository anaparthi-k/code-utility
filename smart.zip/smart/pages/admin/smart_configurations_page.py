from typing import List

from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from models.pages.admin.smart_configurations_model import SmartConfigurationsModel
from pages.page_base import PageBase


class SmartConfigurationsPage(PageBase):
    _user_name = "//*[text()='User Name']"
    _report_type = "//*[text()='Report Type']/following-sibling :: select"
    _search_button = "//*[@value='Search']"
    _save_button = "//*[text()='Save']"
    _available_report = "//*[text()='Available Reports']/following-sibling::*//li"
    _assigned_report = "//*[text()='Assigned Reports']/following-sibling::*//li"
    _available_report_selector = "//*[text()='Available Reports']/following-sibling::*//*[text()=' {0} ']"
    _assigned_report_selector = "//*[text()='Assigned Reports']/following-sibling::*//*[text()=' {0} ']"
    _all_forward_button = "//button[contains(text(),'>>')]"
    _forward_button = "//button[(contains(text(),'>')) and not(contains(text(),'>>'))]"
    _all_backward_button = "//button[contains(text(),'<<')]"
    _backward_button = "//button[(contains(text(),'<')) and not(contains(text(),'<<'))]"
    _OK_button = "//*[text()='OK']"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def perform_search(self, form: SmartConfigurationsModel):
        # self._enter_auto_populate(self._user_name, "User Name", form.user_name)
        self.enter_user_name(form.user_name)
        self._driver.select_by_text(self._report_type, "Report Type", form.report_type)
        self._driver.click(self._search_button, "search")

    def get_all_items_in_available(self):
        return self._converter.elements_text_to_array(self._available_report)

    def get_all_items_in_assigned(self):
        return self._converter.elements_text_to_array(self._assigned_report)

    def click_on_all_forward(self):
        self._driver.click(self._all_forward_button, ">> Button")

    def click_on_all_backward(self):
        self._driver.click(self._all_backward_button, "<< Button")

    def click_on_forward(self):
        self._driver.click(self._forward_button, "> Button")

    def click_on_backward(self):
        self._driver.click(self._backward_button, "< Button")

    def click_on_save(self):
        self._driver.click(self._save_button, "Save")

    def enter_user_name(self, value: str):
        self._enter_auto_populate(self._user_name, 'User Name', value)

    def no_of_items(self, table):
        return len(self._converter.elements_text_to_array(table))

    def select_available_items(self, values: List[str]):
        for value in values:
            self.select_available_item(value)

    def select_available_item(self, value: str):
        assert value is not None and len(value) > 0
        self._driver.click(self._available_report_selector.format(value), "Available item of {0}".format(value))

    def select_assigned_items(self, values: List[str]):
        for value in values:
            self.select_assigned_item(value)

    def select_assigned_item(self, value: str):
        assert value is not None and len(value) > 0
        self._driver.click(self._assigned_report_selector.format(value), "Assigned item of {0}".format(value))

    def click_on_ok(self):
        self._driver.click(self._OK_button, "OK")
