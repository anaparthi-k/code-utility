from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from pages.page_base import PageBase
from models.pages.activity_management.create_crt_projects.bp_engagement_details_subsection_model import BpEngagementDetailsSubsectionModel


class BpEngagementDetailsSubsectionPage(PageBase):
 
    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    pass
