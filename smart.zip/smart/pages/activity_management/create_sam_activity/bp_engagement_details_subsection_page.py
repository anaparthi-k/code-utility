from typing import Tuple, List
from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from models.pages.activity_management.create_sam_activity.bp_engagement_details_subsection_model \
    import BpEngagementDetailsSubsectionModel
from pages.common.form_container import FormContainer
from pages.common.pagination import Pagination
from pages.common.subsection_page import SubsectionPage


class BpEngagementDetailsSubsectionPage(SubsectionPage, FormContainer):
    _business_partner = "//app-add-update-bp-engagement//*[text()='Business Partner']/..//select"
    _routed_status = "//app-add-update-bp-engagement//*[text()='Routed Status']/..//select"
    _routed_date = "//app-add-update-bp-engagement//*[text()='Routed Date']/..//input"
    _bp_resolution = "//app-add-update-bp-engagement//*[text()='BP Resolution']/..//input"
    _bp_age = "//app-add-update-bp-engagement//*[text()='BP Age']/..//input"
    _routing_option = "//app-add-update-bp-engagement//*[text()='Routing Option']/..//input"
    _routing_detail = "//app-add-update-bp-engagement//*[text()='Routing Detail']/..//input"
    _sla = "//app-add-update-bp-engagement//*[text()='SLA']/..//input"
    _routed_to_contact = "//app-add-update-bp-engagement//*[text()='Routed to Contact']/..//input"
    _reference_numbers = "//app-add-update-bp-engagement//*[text()='Reference Number(s)']/..//input"
    _description = "//app-add-update-bp-engagement//*[text()='Description']/..//textarea"
    _resolution = "//app-add-update-bp-engagement//*[text()='Resolution']/..//textarea"
    _form_container = "//app-add-update-bp-engagement"
    _grid_container = "//app-bp-engagement-details"
    _search = "//app-add-update-bp-engagement//*[text()='']"
    _save = "//app-add-update-bp-engagement//*[@class='btn-grp']//*[contains(@class,'btn btn-primary')]"
    _reset = "//app-add-update-bp-engagement//*[text()='Reset']"
    _cancel_update = "//app-add-update-bp-engagement//*[text()='Cancel Update']"
    _form_arrow = "//app-add-update-bp-engagement//*[@data-toggle='collapse']"
    _table_arrow = "//app-bp-engagement-details//*[@data-toggle='collapse']"
    _table_edit = "//app-bp-engagement-details//*[text()='{}']/../*[1]//input"
 
    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def get_data(self) -> Tuple[str]:
        return self.get_form_data()

    def get_form_data(self) -> Tuple[str]:
        return self._converter.fields_to_tuple(self._form_container)

    def get_table_data(self) -> List[List[str]]:
        return self._converter.table_to_array(self._grid_container)

    def create_pagination(self) -> Pagination:
        return Pagination(self._driver, self._converter, self._grid_container)

    def fill_form(self, form: BpEngagementDetailsSubsectionModel) -> None:
        assert isinstance(form, BpEngagementDetailsSubsectionModel)
        if not self.is_form_section_expanded():
            self.click_on_form_expand_button()
        self.enter_routed_date(form.routed_date)
        self.enter_bp_resolution(form.bp_resolution)
        self.enter_bp_age(form.bp_age)
        self.enter_routing_option(form.routing_option)
        self.enter_routing_detail(form.routing_detail)
        self.enter_sla(form.sla)
        self.enter_routed_to_contact(form.routed_to_contact)
        self.enter_reference_numbers(form.reference_numbers)
        self.enter_description(form.description)
        self.enter_resolution(form.resolution)
        self.select_business_partner(form.business_partner)
        self.select_routed_status(form.routed_status)

    def enter_routed_date(self, value):
        self._driver.enter(self._routed_date, "Routed Date", value, is_clear=True)

    def enter_bp_resolution(self, value):
        self._driver.enter(self._bp_resolution, "BP Resolution", value, is_clear=True)

    def enter_bp_age(self, value):
        self._driver.enter(self._bp_age, "BP Age", value, is_clear=True)

    def enter_routing_option(self, value):
        self._driver.enter(self._routing_option, "Routing Option", value, is_clear=True)

    def enter_routing_detail(self, value):
        self._driver.enter(self._routing_detail, "Routing Detail", value, is_clear=True)

    def enter_sla(self, value):
        self._driver.enter(self._sla, "SLA", value, is_clear=True)

    def enter_routed_to_contact(self, value):
        self._driver.enter(self._routed_to_contact, "Routed to Contact", value, is_clear=True)

    def enter_reference_numbers(self, value):
        self._driver.enter(self._reference_numbers, "Reference Numbers", value, is_clear=True)

    def enter_description(self, value):
        self._driver.enter(self._description, "Description", value, is_clear=True)

    def enter_resolution(self, value):
        self._driver.enter(self._resolution, "Resolution", value, is_clear=True)

    def select_business_partner(self, value):
        self._driver.select_by_text(self._business_partner, "Business Partner", value)

    def select_routed_status(self, value):
        self._driver.select_by_text(self._routed_status, "Routed Status", value)

    def click_on_reset_button(self) -> None:
        self._driver.click(self._reset, "Reset")

    def click_on_save_button(self) -> None:
        self._driver.click(self._save, "Engage Business Partner")

    def click_on_cancel_button(self) -> None:
        self._driver.click(self._cancel_update, "Cancel Update")

    def click_on_search_button(self) -> None:
        self._driver.click(self._search, "")

    def click_on_form_expand_button(self) -> None:
        self._driver.click(self._form_arrow, "Form toggle")

    def is_form_section_expanded(self) -> bool:
        return self._driver.get_attribute(self._form_arrow, "Form toggle", 'aria-expanded') == 'true'

    def is_table_section_expanded(self) -> bool:
        return self._driver.get_attribute(self._table_arrow, "Table toggle", 'aria-expanded') == 'true'

    def click_on_table_expand_button(self) -> None:
        self._driver.click(self._table_arrow, "Table toggle")

    def get_bp_resolution(self) -> str:
        return self._driver.get_text(self._bp_resolution, "Bp Resolution")

    def click_table_edit_button(self, value: str):
        self._driver.click(self._table_edit.format(value), f'Table edit of {value}')
