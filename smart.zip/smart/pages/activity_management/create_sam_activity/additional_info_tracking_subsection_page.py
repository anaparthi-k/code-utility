from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from models.pages.activity_management.create_sam_activity.additional_info_tracking_subsection_model \
    import AdditionalInfoTrackingSubsectionModel
from pages.page_base import PageBase
from typing import Tuple, List
from pages.common.pagination import Pagination


class AdditionalInfoTrackingSubsectionPage(PageBase):

    _category = "//app-additional-info-tracking//*[text()='Category']/..//select"
    _sub_category = "//app-additional-info-tracking//*[text()='Sub Category']/..//select"
    _tracking_indicator = "//app-additional-info-tracking//*[text()='Tracking Indicator']/..//select"
    _additional_tracking_details = "//app-additional-info-tracking//*[text()='Additional Tracking Details']/..//textarea"
    _form_container = "//app-additional-info-tracking"
    _grid_container = "//app-additional-info-tracking//*[@*='wdgt-sctn'][2]"
    _add_info = "//app-additional-info-tracking//*[text()='Add Info']"
    _update = "//app-additional-info-tracking//*[text()='Update']"
    _reset = "//app-additional-info-tracking//*[text()='Reset']"
    _cancel = "//app-additional-info-tracking//*[text()='Cancel']"
    _form_arrow = "//app-additional-info-tracking//*[@data-toggle='collapse']"
    _table_arrow = "//app-additional-info-tracking//*[@*='wdgt-sctn'][2]//*[@data-toggle='collapse']"
    _table_edit = "//app-additional-info-tracking//*[@*='wdgt-sctn'][2]//*[text()='{}']/../*[1]/*[1]"
    _table_delete = "//app-additional-info-tracking//*[@*='wdgt-sctn'][2]//*[text()='{}']/../*[1]/*[2]"
 
    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def get_form_data(self) -> Tuple[str]:
        return self._converter.fields_to_tuple(self._form_container)   

    def get_table_data(self) -> List[List[str]]:
        return self._converter.table_to_array(self._grid_container)

    def create_pagination(self) -> Pagination:
        return Pagination(self._driver, self._converter, self._grid_container)         

    def save_fill_form(self, form: AdditionalInfoTrackingSubsectionModel):
        self.select_category(form.category)
        self.select_sub_category(form.sub_category)
        self.select_tracking_indicator(form.tracking_indicator)
        self.enter_additional_tracking_details(form.additional_tracking_details)

    def fill_form(self, form: AdditionalInfoTrackingSubsectionModel) -> None:
        assert isinstance(form, AdditionalInfoTrackingSubsectionModel)
        self.click_on_form_expand_button()
        self.save_fill_form(form)
        self.click_on_add_info_button()

    def select_category(self, value):
        self._driver.select_by_text(self._category, 'Category', value)

    def select_sub_category(self, value):
        self._driver.select_by_text(self._sub_category, 'Sub_Category', value)

    def select_tracking_indicator(self, value):
        self._driver.select_by_text(self._tracking_indicator, 'Tracking Indicator', value)   

    def enter_additional_tracking_details(self, value):
        self._driver.enter(self._additional_tracking_details, 'Additional Tracking Details', value, is_clear=False)     

    def click_on_add_info_button(self):
        self._driver.click(self._add_info, 'Add Info')    

    def click_on_reset_button(self):
        self._driver.click(self._reset, 'Reset')  

    def click_on_update_button(self):
        self._driver.click(self._update, 'Update')

    def click_on_cancel_button(self):
        self._driver.click(self._cancel, 'Cancel')         

    def click_on_form_expand_button(self) -> None:
        self._driver.click(self._form_arrow, "Form toggle")

    def is_form_section_expanded(self) -> bool:
        return self._driver.get_attribute(self._form_arrow, "Form toggle", 'aria-expanded') == 'true'

    def is_table_section_expanded(self) -> bool:
        return self._driver.get_attribute(self._table_arrow, "Table toggle", 'aria-expanded') == 'true'

    def click_on_table_expand_button(self) -> None:
        self._driver.click(self._table_arrow, "Table toggle")

    def click_on_table_edit_button(self, value: str) -> None:
        self._driver.click(self._table_edit.format(value), f'Table edit of {value}')

    def click_on_table_delete_button(self, value: str) -> None:
        self._driver.click(self._table_delete.format(value), f'Table edit of {value}')
