from typing import List
from core.driver_element_proxy import DriverElementProxy
from core.driver_proxy import DriverProxy
from models.pages.non_production_time_tracker.non_production_time_tracker_model import \
    NonProductionTimeTrackerSearchModel, NonProductionTimeTrackerAddFormModel
from pages.common.form_container import FormContainer
from pages.page_base import PageBase


class NonProductionTimeTrackerSearchForm(FormContainer, PageBase):
    _user = "//*[text()='User']"
    _supervisor = "//*[text()='Supervisor']/following-sibling::*//input"
    _from_date = "//*[text()='From Date']/following-sibling::*//input"
    _to_date = "//*[text()='To Date']/following-sibling::*//input"
    _time_category = "//*[text()='Time Category']/following-sibling::select"
    _status = "//*[text()='Status']/following-sibling::select"
    _all_day = "//*[text()='All Day']/following-sibling::*//input"
    _search_button = "//*[text()='Search']"
    _table_container = '//nonprod-timetracker-searchres'
    _table_no_records = "//nonprod-timetracker-details//*[text()='No Records Found']"
    _search_form_container = '//nonprod-timetracker-details'
    _add_time_button = "//*[text()='Add Time']"
    _cancel_button = "//*[text()='Cancel']"
    _reset_button = "//*[text()='Reset']"
    _header_title_label = '//*[@class="sctn-hdr"]'
    _delete_button_of_row = "//nonprod-timetracker-searchres//*[text()='{0}']/../*[1]/*[2]"
    _edit_button_of_row = "//nonprod-timetracker-searchres//*[text()='{0}']/../*[1]/*[1]"
    _yes_button = "//*[text()='Yes']"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        FormContainer.__init__(self, driver, converter)
        PageBase.__init__(self, driver, converter)

    def perform_search(self, form: NonProductionTimeTrackerSearchModel):
        self._enter_auto_populate(self._user, 'user', form.user)
        self._driver.enter(self._from_date, 'From Date', form.from_date, is_clear=True)
        self._driver.enter(self._to_date, 'To Date', form.to_date, is_clear=True)
        self._driver.select_by_text(self._time_category, 'Time Category', form.time_category)
        self._driver.select_by_text(self._status, 'status', form.status)

        if form.all_day is not None:
            self._driver.check(self._all_day, 'All Day', form.all_day)

        self._driver.click(self._search_button, 'Search')
        self._driver.wait_till_spinner_off()

    def click_on_add_time_button(self):
        self._driver.click(self._add_time_button, "Add Time")

    def click_on_cancel_button(self):
        self._driver.click(self._cancel_button, "Cancel")
        self.click_on_yes_button()
        self._driver.wait_till_spinner_off()

    def click_on_edit_button(self, date: str):
        self._driver.click(self._edit_button_of_row.format(date), f"Edit of {date}")

    def click_on_delete_button(self, date: str):
        self._driver.click(self._delete_button_of_row.format(date), f"Delete of {date}")

    def click_on_reset_button(self):
        self._driver.click(self._reset_button, "Reset")

    def click_on_yes_button(self):
        self._driver.click(self._yes_button, "Yes")

    def get_header_title(self):
        return self._driver.get_text(self._header_title_label, 'header title')

    def is_row_exists_with_date(self, date: str) -> bool:
        return self._driver.is_exists(self._delete_button_of_row.format(date))

    def is_grid_has_records(self) -> bool:
        return self._driver.is_exists(self._table_no_records)

    def table_rows(self) -> List[List[str]]:
        return self._converter.table_to_array(self._table_container)

    def get_data(self) -> List[List[str]]:
        return self._converter.fields_to_tuple(self._search_form_container)


class NonProductionTimeTrackerAddTimeFrom(PageBase):
    _user = "//*[text()='User']/following-sibling::*//input"
    _supervisor = "//*[text()='Supervisor']/following-sibling::input"
    _role = "//*[text()='Role']/following-sibling::input"
    _time_category = "//*[text()='Time Category']/following-sibling::select"
    _sub_category = "//*[text()='Sub Category']/following-sibling::select"
    _status = "//*[text()='Status']/following-sibling::select"
    _date = "//*[contains(text(),'Date')]/following-sibling::*/input"
    _time_spent = ""
    _time_radio_button = "//*[@id='startEndTime']"
    _start_time = "//*[@id='ddn_StartTime']"
    _end_time = "//*[@id='ddn_EndTime']"
    _hours_radio_button = "//*[@id='hoursEntered']"
    _hours = "//*[@id='txtHoursEntered']"
    _all_day_radio_button = "//*[@id='isAllDay']"
    _all_day = "//*[@id='IsAllDay']"
    _total_hours = "//*[text()='Total Hours']/following-sibling::input"
    _backup = "//*[text()='Backup']/following-sibling::*//input"
    _comments = "//*[text()='Comments']/following-sibling::textarea"
    _save_button = "//*[text()='Save']"
    _update_button = "//*[text()='Update']"
    _yes_button = "//*[text()='Yes']"
    _header_title_label = '//*[@class="sctn-hdr"]'
    _cancel_button = "//*[text()='Cancel']"
    _add_time_form_container = '//add-update-timetracker'
    _reset_button = "//*[text()='Reset']"

    def __init__(self, driver: DriverProxy, converter: DriverElementProxy):
        super().__init__(driver, converter)

    def select_time_category(self, value: str) -> None:
        self._driver.select_by_text(self._time_category, 'Time Category', value)

    def get_status_value(self) -> str:
        return self._driver.get_drop_down_text(self._status, 'status')

    def get_status_is_enabled(self) -> bool:
        return self._driver.is_enabled(self._status)

    def get_subcategory_enabled_status(self) -> bool:
        return self._driver.is_enabled(self._sub_category)

    def is_role_text(self, text: str) -> bool:
        assert text is not None and len(text) > 0
        role_text = self._driver.get_text(self._role, 'role')
        is_present = text.upper() in role_text.upper()
        self.logger.debug(f"Checking that {text} is {(is_present and '' or 'not ')}present in Role:'{role_text}'")
        return is_present

    def select_start_time(self, start: str, end: str) -> None:
        self._driver.click(self._time_radio_button, 'Time')
        self._driver.select_by_text(self._start_time, 'Start Time', start)
        self._driver.select_by_text(self._end_time, 'End Time', end)

    def enter_hours(self, hour: str) -> None:
        self._driver.click(self._hours_radio_button, 'Hours radio')
        self._driver.enter(self._hours, 'Hours', hour, is_clear=True)

    def enter_comments(self, value: str) -> None:
        self._driver.enter(self._comments, 'comments', value, is_clear=True)

    def select_all_days(self) -> None:
        self._driver.click(self._all_day_radio_button, 'All Day radio')
        self._driver.click(self._all_day, 'All Day')

    def click_on_save(self) -> None:
        self._driver.click(self._save_button, 'Save')
        self.click_on_yes_button()
        self._driver.wait_till_spinner_off()

    def click_on_update(self) -> None:
        self._driver.click(self._update_button, 'Update')
        self.click_on_yes_button()
        self._driver.wait_till_spinner_off()

    def click_on_yes_button(self):
        self._driver.click(self._yes_button, "Yes")

    def get_header_title(self):
        return self._driver.get_text(self._header_title_label, 'header title')

    def click_on_cancel_button(self):
        self._driver.click(self._cancel_button, "Cancel")
        self.click_on_yes_button()
        self._driver.wait_till_spinner_off()

    def fill(self, model: NonProductionTimeTrackerAddFormModel):
        self.enter_hours(model.hour)
        self.select_time_category(model.time_category)
        self.enter_comments(model.comments)

    def get_data(self):
        return self._converter.fields_to_tuple(self._add_time_form_container)

    def click_on_reset_button(self):
        self._driver.click(self._reset_button, "Reset")
