import logging
import time
import pytest
from _pytest.nodes import Item
from _pytest.runner import CallInfo
from selenium import webdriver
from selenium.webdriver import DesiredCapabilities
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.remote.webdriver import WebDriver
from webdriver_manager.firefox import GeckoDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager
from core.driver_proxy import DriverProxy
from core.driver_element_proxy import DriverElementProxy
from instances.factories.factory_instance import FactoryInstance
from instances.pages.page_instance import PageInstance
from instances.verifications.verification_instance import VerificationInstance
from instances.workflows.workflow_instance import WorkflowInstance
from models.references.workflow_parameter_model import WorkflowParameterModel
from test_cases.test_fixture_base import TestFixtureBase
from utils import config_reader
from utils.path import Path


@pytest.fixture(scope="class")
def setup(request):
    driver_ref: WebDriver
    browser_name = config_reader.config_get("driver", "browser")

    if browser_name == "chrome":
        folder = config_reader.config_get("driver", "folder")
        options = Options()
        options.add_argument("--start-maximized")
        options.add_argument("--disable-notifications")
        options.add_argument("--incognito")
        import os
        browser_path = os.path.join(folder, 'chrome.exe')
        driver_ref = webdriver.Chrome(chrome_options=options, executable_path=browser_path)
    elif browser_name == "edge":
        driver_ref = webdriver.Edge(executable_path=EdgeChromiumDriverManager().install())
    elif browser_name == "firefox":
        driver_ref = webdriver.Firefox(executable_path=GeckoDriverManager().install())
    elif browser_name == "remote":
        driver_ref = get_remote_browser()
    else:
        raise TypeError
    driver_ref.maximize_window()
    _enter_url(driver_ref)
    wait_secs = config_reader.config_get("driver", "implicit_wait_secs")
    driver_ref.implicitly_wait(wait_secs)
    request.cls.driver = DriverProxy(driver_ref)
    request.cls.converter = DriverElementProxy(driver_ref)
    request.cls.page = PageInstance(request.cls.driver, request.cls.converter)
    request.cls.verification = VerificationInstance(request.cls.driver)
    request.cls.factory = FactoryInstance()
    parameter = _create_parameter_model(request.cls)
    request.cls.workflow = WorkflowInstance(parameter)
    yield
    driver_ref.quit()


def get_remote_browser():
    options = webdriver.ChromeOptions()
    options.add_argument("no-sandbox")
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=800,600")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--headless")
    driver = webdriver.Remote(
        command_executor=f"http://localhost:4444/wd/hub",
        desired_capabilities=DesiredCapabilities.CHROME,
        options=options,
    )
    return driver


def _create_parameter_model(test: TestFixtureBase) -> WorkflowParameterModel:
    parameter = WorkflowParameterModel()
    parameter.driver = test.driver
    parameter.converter = test.converter
    parameter.page = test.page
    parameter.factory = test.factory
    parameter.verification = test.verification
    parameter.assertion = test.assertion
    return parameter


def _enter_url(driver_ref: WebDriver):
    logger_ref = _get_logger('TEST')
    sso_enable_status = config_reader.config_get("sso", "enable").lower()
    url = config_reader.config_get("basic info", "test_site_url")

    is_sso_enabled = sso_enable_status == 'true' or sso_enable_status == 'yes' or sso_enable_status == 'y'
    logger_ref.debug(f"Verified that SSO is {is_sso_enabled and 'enabled' or 'not enabled'} in the config")

    if is_sso_enabled:
        try:
            wait_secs = int(config_reader.config_get("sso", "action_wait_secs"))
            logger_ref.debug(f"Opening the url as https:{url}")
            driver_ref.get(url)
            time.sleep(wait_secs)
            _pop_up_close_trail5(logger_ref)
            time.sleep(wait_secs)
            password, user_name = _read_credential(logger_ref)
            logger_ref.debug(f"Entering the user name in the browser")
            driver_ref.find_element_by_xpath('//*[@id="username"]').send_keys(user_name)
            logger_ref.debug(f"Entering the password in the browser")
            driver_ref.find_element_by_xpath('//*[@id="password"]').send_keys(password)
            logger_ref.debug(f"Clicking on Submit in the browser")
            driver_ref.find_element_by_xpath('//button').click()
            time.sleep(wait_secs)
        except Exception as e:
            driver_ref.quit()
            raise Exception(f'Failed to perform the operation due to {str(e)}')
    else:
        driver_ref.get(url)


def _pop_up_close_trail1(logger_ref: logging.Logger):
    from core.keyboard import Keyboard
    password, user_name = _read_credential(logger_ref)
    logger_ref.debug(f"Entering the user name in the windows credentials popup")
    Keyboard.write(user_name)
    Keyboard.tab()
    logger_ref.debug(f"Entering the password in the windows credentials popup")
    Keyboard.write(password)
    Keyboard.tab()
    logger_ref.debug(f"Skipping more choices in the windows credentials popup")
    Keyboard.tab()
    Keyboard.tab()
    logger_ref.debug(f"Click on OK in the windows credentials popup")
    Keyboard.enter()


def _pop_up_close_trail2(logger_ref: logging.Logger):
    from core.keyboard import Keyboard
    logger_ref.debug(f"Pressing the Esc in the windows credentials popup")
    Keyboard.escape()


def _pop_up_close_trail3(logger_ref: logging.Logger):
    from core.keyboard import Keyboard
    logger_ref.debug(f"Pressing the Alt + F4 in the windows credentials popup")
    Keyboard.alt_f4()


def _pop_up_close_trail4(logger_ref: logging.Logger):
    from core.keyboard import Keyboard
    logger_ref.debug(f"Pressing TAB 5 times to move cancel button in the windows credentials popup")
    Keyboard.tab()
    Keyboard.tab()
    Keyboard.tab()
    Keyboard.tab()
    Keyboard.tab()
    Keyboard.enter()


def _pop_up_close_trail5(logger_ref: logging.Logger):
    logger_ref.debug(f"Pressing TAB 5 times to move cancel button in the windows credentials popup")
    from tkinter import Tk
    root = Tk()
    height = root.winfo_screenheight()
    width = root.winfo_screenwidth()
    import mouse
    mouse.move(width / 2, height / 2, absolute=True, duration=0.1)
    mouse.click(mouse.LEFT)
    _pop_up_close_trail1(logger_ref)


def _read_credential(logger_ref: logging.Logger):
    try:
        # import mysql.connector
        # import pandas as pd
        # table_name = config_reader.config_get("sso", "table_name")
        # connection_string = config_reader.config_get("sso", "connection_string")
        # logger_ref.debug(f"Read the credentials form server at {connection_string}")
        # import json
        # conn_data = json.loads(connection_string)
        # sql_connector = mysql.connector.connect(**conn_data)
        #
        # query = f'SELECT * FROM {table_name}'
        # logger_ref.debug(f"Reading the value by query '{query}'")
        # table = pd.read_sql(query, sql_connector)

        import pandas as pd
        file_name = config_reader.config_get("sso", "file_path")
        logger_ref.debug(f"Reading the credentials form file")
        table = pd.read_csv(file_name, encoding="utf-8", delimiter=",")

        filtered_data = table[table.name == 'user_name']
        user_name = filtered_data.at[filtered_data.index[0], 'value']
        logger_ref.debug(f"User name {(user_name is None or len(user_name) == 0 and 'not ' or '')}has value")

        filtered_data = table[table.name == 'password']
        password = filtered_data.at[filtered_data.index[0], 'value']
        logger_ref.debug(f"password {(password is None or len(password) == 0 and 'not ' or '')}has value")

        return password, user_name
    except Exception as e:
        logger_ref.debug(f"Failed to connect to database due to {str(e)}")
        logger_ref.error(f"Failed to connect to database due to {str(e)}", exc_info=e)
        raise Exception('No data found in DB')


@pytest.hookimpl()
def pytest_runtest_call(item: Item):
    logger_ref = _get_logger(item.name)
    current_test = getattr(item, 'cls')
    current_test.set_logger(current_test, logger_ref)


def _get_logger(name: str) -> logging.Logger:
    logger_ref = logging.getLogger(name)
    logger_ref.setLevel(logging.DEBUG)
    log_path = Path.get_full_path('reports\\logs\\logfile_' + time.strftime("%Y-%m-%d") + '.log')
    Path.create_directory(log_path)
    file_handler = logging.FileHandler(log_path, mode="a")
    formatter = logging.Formatter("%(asctime)s :%(levelname)s : %(name)s :%(message)s")
    file_handler.setFormatter(formatter)
    logger_ref.addHandler(file_handler)
    return logger_ref


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item: Item, call: CallInfo):
    # All code prior to yield statement would be ran prior
    # to any other of the same fixtures defined

    outcome = yield  # Run all other pytest_runtest_makereport non wrapped hooks
    report = outcome.get_result()

    if report.when == "call" and report.failed:
        current_test = getattr(item, 'cls')
        logger: logging.Logger = current_test.logger
        try:  # Just to not crash py.test reporting
            current_test = getattr(item, 'cls')
            driver: DriverProxy = current_test.driver
            file_name = current_test.__name__ + "_" + item.name
            img_full_path = driver.capture_screenshot_full(file_name)

            if item.config.pluginmanager.hasplugin('html'):
                pytest_html = item.config.pluginmanager.getplugin('html')
                extra = getattr(report, 'extra', [])
                extra.append(pytest_html.extras.image(img_full_path))
                report.extra = extra

        except Exception as e:
            logger.error(f"Current Test result  {call.result} "
                         f"failed to save the screenshot due to {str(e)} more details", exc_info=e)
            pass
