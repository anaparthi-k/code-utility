from test_cases.test_fixture_base import TestFixtureBase


class TestScorecardGeneration(TestFixtureBase):
    _DOWNLOAD_SUCCESS_MESSAGE = 'Success!\nFor the selected clients,{} PPT files were generated successfully'

    def test_generate_csv(self):
        self.page.common.menu.open_scorecard_generation()
        search_form = self.factory.page.scorecard.scorecard_generation.create_generate_csv()
        self.page.scorecard.scorecard_generation.generate_csv(search_form)
        pass

    def test_generate_single_ppt(self):
        self.page.common.menu.open_scorecard_generation()
        search_form = self.factory.page.scorecard.scorecard_generation.create_generate_single_ppt()
        self.page.scorecard.scorecard_generation.generate_single_ppt(search_form)
        count = self.page.scorecard.scorecard_generation.ppt_download_count
        self.verification.toaster.equals(self._DOWNLOAD_SUCCESS_MESSAGE.format(count))
        pass

    def test_generate_multiple_ppt(self):
        self.page.common.menu.open_scorecard_generation()
        search_form = self.factory.page.scorecard.scorecard_generation.create_generate_multiple_ppt()
        self.page.scorecard.scorecard_generation.generate_multiple_ppt(search_form)
        count = self.page.scorecard.scorecard_generation.ppt_download_count
        self.verification.toaster.equals(self._DOWNLOAD_SUCCESS_MESSAGE.format(count))
        pass

    def test_generate_all_ppt(self):
        self.page.common.menu.open_scorecard_generation()
        search_form = self.factory.page.scorecard.scorecard_generation.create_generate_csv()
        self.page.scorecard.scorecard_generation.generate_all_ppt(search_form)
        count = self.page.scorecard.scorecard_generation.ppt_download_count
        self.verification.toaster.equals(self._DOWNLOAD_SUCCESS_MESSAGE.format(count))
        pass
