from test_cases.test_fixture_base import TestFixtureBase
from utils.fie import clean_file_in_download


class TestScorecardHistory(TestFixtureBase):

    def test_view_history(self):
        self.page.common.menu.open_scorecard_history()
        search_form = self.factory.page.scorecard.scorecard_history.create_view_history()
        self.page.scorecard.scorecard_history.view_history(search_form)
        self.verification.element.validate(search_form.customer_name)
        pass

    def test_download_button(self):
        customer_name = "ASRS"
        clean_file_in_download(customer_name + '*.zip')
        self.page.common.menu.open_scorecard_history()
        search_form = self.factory.page.scorecard.scorecard_history.create_view_history()
        self.page.scorecard.scorecard_history.view_history(search_form)
        self.verification.element.validate(search_form.customer_name)
        self.page.scorecard.scorecard_history.click_on_action_download()
        downloaded_file_name = search_form.customer_name + search_form.from_date[6:10] + 'Q2.zip'
        self.assertion.is_file_exist_in_downloads(downloaded_file_name)
        pass

    def test_reset_button(self):
        self.page.common.menu.open_scorecard_history()
        before_reset = self.page.scorecard.scorecard_history.get_data()
        search_form = self.factory.page.scorecard.scorecard_history.create_view_history()
        self.page.scorecard.scorecard_history.view_history(search_form)
        self.page.scorecard.scorecard_history.click_on_reset()
        after_reset = self.page.scorecard.scorecard_history.get_data()
        self.assertion.equals(before_reset, after_reset, 'Reset form data in search form')
        pass
