from test_cases.test_fixture_base import TestFixtureBase


class TestCrtResolutionSubsection(TestFixtureBase):
    # self.factory.page.case_management.create_crt_request.crt_resolution_subsection
    # self.page.case_management.create_crt_request.crt_resolution_subsection
    pass
