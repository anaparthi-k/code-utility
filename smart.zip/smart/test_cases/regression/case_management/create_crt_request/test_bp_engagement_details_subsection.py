from test_cases.test_fixture_base import TestFixtureBase


class TestBpEngagementDetailsSubsection(TestFixtureBase):
    # self.factory.page.case_management.create_crt_request.bp_engagement_details_subsection
    # self.page.case_management.create_crt_request.bp_engagement_details_subsection
    pass
