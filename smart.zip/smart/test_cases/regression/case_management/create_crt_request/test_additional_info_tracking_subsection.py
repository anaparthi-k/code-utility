from test_cases.test_fixture_base import TestFixtureBase


class TestAdditionalInfoTrackingSubsection(TestFixtureBase):
    # self.factory.page.case_management.create_crt_request.additional_info_tracking_subsection
    # self.page.case_management.create_crt_request.additional_info_tracking_subsection
    pass
