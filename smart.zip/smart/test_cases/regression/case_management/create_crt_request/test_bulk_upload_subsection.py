from test_cases.test_fixture_base import TestFixtureBase


class TestBulkUploadSubsection(TestFixtureBase):
    # self.factory.page.case_management.create_crt_request.bulk_upload_subsection
    # self.page.case_management.create_crt_request.bulk_upload_subsection
    pass
