from test_cases.test_fixture_base import TestFixtureBase


class TestAdherenceSectionSubsection(TestFixtureBase):
    # self.factory.page.case_management.create_crt_request.adherence_section_subsection
    # self.page.case_management.create_crt_request.adherence_section_subsection
    pass
