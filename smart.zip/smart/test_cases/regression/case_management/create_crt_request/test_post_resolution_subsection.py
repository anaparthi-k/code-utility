from test_cases.test_fixture_base import TestFixtureBase


class TestPostResolutionSubsection(TestFixtureBase):
    # self.factory.page.case_management.create_crt_request.post_resolution_subsection
    # self.page.case_management.create_crt_request.post_resolution_subsection
    pass
