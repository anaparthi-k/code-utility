from test_cases.test_fixture_base import TestFixtureBase


class TestMemberInformationSubsection(TestFixtureBase):
    # self.factory.page.case_management.create_sam_request.member_information_subsection
    # self.page.case_management.create_sam_request.member_information_subsection
    pass
