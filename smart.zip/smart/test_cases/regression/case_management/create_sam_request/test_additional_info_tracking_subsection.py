import pytest
from test_cases.test_fixture_base import TestFixtureBase


class TestAdditionalInfoTrackingSubsection(TestFixtureBase):
   
    @pytest.mark.order(1)
    def test_save(self):
        self.page.common.menu.open_sam_request()
        factory = self.factory.page.case_management.create_sam_request.additional_info_tracking_subsection
        form = factory.create_save()
        page = self.page.case_management.create_sam_request.additional_info_tracking_subsection
        self.workflow.smart.subsection.verify_form_saved_with_spinner(page, form,
                                                                      f'{form.category} details are saved Successfully')
        pass

    @pytest.mark.order(2)
    def test_edit(self):
        self.page.common.menu.open_sam_request()
        factory = self.factory.page.case_management.create_sam_request.additional_info_tracking_subsection
        save_form = factory.create_save()
        page = self.page.case_management.create_sam_request.additional_info_tracking_subsection
        edit_form = factory.create_edit()
        self.workflow.smart.subsection.verify_form_edit(page, edit_form, save_form.category,
                                                        'details are updated Successfully')
        pass

    @pytest.mark.order(3)
    def test_delete(self):
        self.page.common.menu.open_sam_request()
        factory = self.factory.page.case_management.create_sam_request.additional_info_tracking_subsection
        page = self.page.case_management.create_sam_request.additional_info_tracking_subsection
        edit_form = factory.create_edit()
        self.workflow.smart.subsection.verify_form_delete(page, edit_form.category,
                                                          f'Do you want to delete {edit_form.category} ?',
                                                          f'{edit_form.category} details are deleted Successfully')
        pass

    pass
