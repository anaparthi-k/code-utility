from test_cases.test_fixture_base import TestFixtureBase


class TestSamResolutionSubsection(TestFixtureBase):
    # self.factory.page.case_management.create_sam_request.sam_resolution_subsection
    # self.page.case_management.create_sam_request.sam_resolution_subsection
    pass
