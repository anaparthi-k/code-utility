from test_cases.test_fixture_base import TestFixtureBase


class TestSamRequestSubsection(TestFixtureBase):
    # self.factory.page.case_management.create_sam_request.sam_request_subsection
    # self.page.case_management.create_sam_request.sam_request_subsection
    pass
