import pytest
from test_cases.test_fixture_base import TestFixtureBase


class TestFollowUpNeededSubsection(TestFixtureBase):
    
    @pytest.mark.order(1)
    def test_save(self):
        self.page.common.menu.open_sam_request()
        factory = self.factory.page.case_management.create_sam_request.follow_up_needed_subsection
        form = factory.create_save()
        page = self.page.case_management.create_sam_request.follow_up_needed_subsection
        self.workflow.smart.subsection.verify_form_saved_with_spinner(page, form,
                                                                      'Added SuccessFully')
        pass

    @pytest.mark.order(2)
    def test_edit(self):
        self.page.common.menu.open_sam_request()
        factory = self.factory.page.case_management.create_sam_request.follow_up_needed_subsection
        save_form = factory.create_save()
        page = self.page.case_management.create_sam_request.follow_up_needed_subsection
        edit_form = factory.create_edit()
        self.workflow.smart.subsection.verify_form_edit(page, edit_form, save_form.follow_up_resolution,
                                                        'Added SuccessFully')
        pass

    pass
