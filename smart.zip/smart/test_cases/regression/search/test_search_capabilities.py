from datetime import datetime, timedelta
from typing import List
import pytest
from test_cases.test_fixture_base import TestFixtureBase
from utils.constants import DATE_FORMAT


class TestSearchCapabilities(TestFixtureBase):
    # self.factory.page.search.search_capabilities
    # self.page.search.search_capabilities

    def test_capability_status_should_open(self):
        self._verify_status_should_open()

    def test_capability_owner_filter(self):
        self._verify_owner_filter()

    def test_capability_submitter_filter(self):
        self._verify_submitter_filter()

    def test_capability_status_complete_should_have_completion_date(self):
        self._verify_status_complete_should_have_completion_date()

    def test_capability_reset_functionality(self):
        def search_in_page():
            search = self.factory.page.search.search_capabilities.create_capabilities_search()
            self.page.search.search_capabilities.capabilities_search(search)

        self._verify_reset(search_in_page)

    def test_capability_completion_date_difference(self):
        self._verify_completion_date_difference()

    def test_capability_submission_date_difference(self):
        self._verify_submission_date_difference()

    def _verify_status_should_open(self):
        self.page.common.menu.open_search_capabilities()
        page = self.page.search.search_capabilities
        page.click_on_reset()
        page.select_status('Scheduled')
        page.click_on_search_capability_requests_with_wait()
        pagination = page.create_pagination()
        self.verification.pagination.validate_equals(pagination, column=8, value='Scheduled')

    def _verify_owner_filter(self):
        self.page.common.menu.open_search_capabilities()
        page = self.page.search.search_capabilities
        page.click_on_reset()
        name = self.page.common.menu.display_name()
        page.enter_owner(name)
        page.click_on_search_capability_requests_with_wait()
        pagination = page.create_pagination()
        self.verification.pagination.validate_contains(pagination, column=4, value=name.replace(',', ''))

    def _verify_submitter_filter(self):
        self.page.common.menu.open_search_capabilities()
        page = self.page.search.search_capabilities
        page.click_on_reset()
        name = self.page.common.menu.display_name()
        page.enter_submitter(name)
        page.click_on_search_capability_requests_with_wait()
        pagination = page.create_pagination()
        self.verification.pagination.validate_contains(pagination, column=3, value=name.replace(',', ','))

    def _verify_status_complete_should_have_completion_date(self):
        self.page.common.menu.open_search_capabilities()
        page = self.page.search.search_capabilities
        page.click_on_reset()
        page.select_status('Completed')
        page.click_on_search_capability_requests_with_wait()
        pagination = page.create_pagination()
        self.verification.pagination.validate_not_equals(pagination, column=9, value='')

    def _verify_reset(self, action: any):
        assert action is not None
        self.page.common.menu.open_search_capabilities()
        search_capabilities_page = self.page.search.search_capabilities
        search_capabilities_page.click_on_reset()
        before_reset = search_capabilities_page.get_data()
        action()
        search_capabilities_page.click_on_reset()
        after_reset = search_capabilities_page.get_data()
        self.assertion.equals(before_reset, after_reset, 'Reset form data in search request form')

    def _verify_completion_date_difference(self):
        def enter_value(from_date: str, to_date: str):
            page = self.page.search.search_capabilities
            page.enter_from_completion_date(from_date)
            page.enter_to_completion_date(to_date)

        self._verify_date_difference(enter_value,
                                     'Warning\nFrom Completion Date should be within the 90 days' 
                                     ' before the To Completion Date')
    
    def _verify_submission_date_difference(self):
        def enter_value(from_date: str, to_date: str):
            page = self.page.search.search_capabilities
            page.enter_from_submitted_date(from_date)
            page.enter_to_submitted_date(to_date)

        self._verify_date_difference(enter_value,
                                     'Warning\nFrom Submitted Date should be within the 90 days' 
                                     ' before the To Submitted Date')

    def _verify_date_difference(self, action: any, message: str):
        from_date = datetime.now().strftime(DATE_FORMAT)
        to_date = (datetime.now() + timedelta(days=91)).strftime(DATE_FORMAT)
        self.page.common.menu.open_search_capabilities()
        page = self.page.search.search_capabilities
        page.click_on_reset()
        action(from_date, to_date)
        page.click_on_search_capability_requests()
        self.verification.toaster.equals(message)
