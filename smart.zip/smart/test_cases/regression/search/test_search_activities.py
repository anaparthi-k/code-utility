from datetime import datetime, timedelta
from typing import List
import pytest
from test_cases.test_fixture_base import TestFixtureBase
from utils.constants import DATE_FORMAT


@pytest.mark.regression
class TestSearchActivity(TestFixtureBase):
    SAM_SEARCH_TYPE = 'SAM Activity'
    CRT_SEARCH_TYPE = 'CRT Projects'

    def test_sam_status_should_open(self):
        self._verify_status_should_open(self.SAM_SEARCH_TYPE)

    def test_sam_owner_filter(self):
        self._verify_owner_filter(self.SAM_SEARCH_TYPE)

    def test_sam_status_close_should_have_resolution_date(self):
        self._verify_status_close_should_have_resolution_date(self.SAM_SEARCH_TYPE)

    def test_sam_reset_functionality(self):
        def search_in_page():
            search = self.factory.page.search.search_activities.create_sact_search()
            self.page.search.search_activities.sam_activity_search(search)

        self._verify_reset(self.SAM_SEARCH_TYPE, search_in_page)

    def test_sam_fields_visibility(self):
        page = self.page.search.search_activities
        field_names = ['call_tracking_id',
                       'member_id',
                       'member_first_name',
                       'member_last_name',
                       'group_name'
                       ]
        fields = [page.is_visible_call_tracking_id,
                  page.is_visible_member_id,
                  page.is_visible_member_first_name,
                  page.is_visible_member_last_name,
                  page.is_visible_group_name
                  ]

        self._fields_visibility(self.SAM_SEARCH_TYPE, True, field_names, fields)

    def test_sam_created_date_difference(self):
        self._verify_created_date_difference(self.SAM_SEARCH_TYPE)

    def test_sam_resolution_date_difference(self):
        self._verify_resolution_date_difference(self.SAM_SEARCH_TYPE)

    def test_sam_bp_routed_date_difference(self):
        self._verify_bp_routed_date_difference(self.SAM_SEARCH_TYPE)

    def test_sam_call_tracking_date_difference(self):
        self._verify_call_tracking_date_difference(self.SAM_SEARCH_TYPE)

    def test_sam_follow_up_date_difference(self):
        self._verify_follow_up_date_difference(self.SAM_SEARCH_TYPE)

    def test_crt_status_should_open(self):
        self._verify_status_should_open(self.CRT_SEARCH_TYPE)

    def test_crt_owner_filter(self):
        self._verify_owner_filter(self.CRT_SEARCH_TYPE)

    def test_crt_status_close_should_have_resolution_date(self):
        self._verify_status_close_should_have_resolution_date(self.CRT_SEARCH_TYPE)

    def test_crt_reset_functionality(self):
        def search_in_page():
            search = self.factory.page.search.search_activities.create_cact_search()
            self.page.search.search_activities.crt_projects_search(search)

        self._verify_reset(self.CRT_SEARCH_TYPE, search_in_page)

    def test_crt_fields_visibility(self):
        page = self.page.search.search_activities
        field_names = ['call_tracking_id',
                       'member_id',
                       'member_first_name',
                       'member_last_name',
                       ]
        fields = [page.is_visible_call_tracking_id,
                  page.is_visible_member_id,
                  page.is_visible_member_first_name,
                  page.is_visible_member_last_name
                  ]

        self._fields_visibility(self.CRT_SEARCH_TYPE, False, field_names, fields)

    def test_crt_created_date_difference(self):
        self._verify_created_date_difference(self.CRT_SEARCH_TYPE)

    def test_crt_resolution_date_difference(self):
        self._verify_resolution_date_difference(self.CRT_SEARCH_TYPE)

    def test_crt_bp_routed_date_difference(self):
        self._verify_bp_routed_date_difference(self.CRT_SEARCH_TYPE)

    def test_crt_follow_up_date_difference(self):
        self._verify_follow_up_date_difference(self.CRT_SEARCH_TYPE)

    def _verify_status_should_open(self, search_type: str):
        self.page.common.menu.open_search_activities()
        page = self.page.search.search_activities
        page.click_on_reset()
        page.select_search_type(search_type)
        page.select_activity_status('Open')
        page.click_on_search_activities_with_wait()
        pagination = page.create_pagination()
        self.verification.pagination.validate_equals(pagination, column=3, value='Open')

    def _verify_owner_filter(self, search_type: str):
        self.page.common.menu.open_search_activities()
        page = self.page.search.search_activities
        page.click_on_reset()
        page.select_search_type(search_type)
        name = self.page.common.menu.display_name()
        page.enter_owner(name)
        page.click_on_search_activities_with_wait()
        pagination = page.create_pagination()
        self.verification.pagination.validate_contains(pagination, column=2, value=name.replace(',', ','))

    def _verify_status_close_should_have_resolution_date(self, search_type: str):
        self.page.common.menu.open_search_activities()
        page = self.page.search.search_activities
        page.click_on_reset()
        page.select_search_type(search_type)
        page.select_activity_status('Closed')
        page.click_on_search_activities_with_wait()
        pagination = page.create_pagination()
        self.verification.pagination.validate_not_equals(pagination, column=8, value='')

    def _verify_reset(self, search_type: str, action: any):
        assert action is not None
        self.page.common.menu.open_search_activities()
        search_activities_page = self.page.search.search_activities
        search_activities_page.select_search_type(search_type)
        search_activities_page.click_on_reset()
        before_reset = search_activities_page.get_data()
        action()
        search_activities_page.click_on_reset()
        after_reset = search_activities_page.get_data()
        self.assertion.equals(before_reset, after_reset, 'Reset form data in search request form')

    def _fields_visibility(self, search_type: str, is_visible: bool, field_names: List[str], fields: List[any]):
        assert len(field_names) == len(fields)
        self.page.common.menu.open_search_activities()
        page = self.page.search.search_activities
        page.click_on_reset()
        page.select_search_type(search_type)
        field_name: str = ''
        state: bool = False
        for index, (filed, field_name) in enumerate(zip(fields, field_names)):
            state = is_visible == filed()
        if not state:
            self.logger.debug(f"{field_name} should {is_visible and 'visible' or 'not visible'} in the page"
                              f" but {state and 'visible' or 'not visible'}")
        assert state

    def _verify_created_date_difference(self, search_type: str):
        def enter_value(from_date: str, to_date: str):
            page = self.page.search.search_activities
            page.enter_from_created_date(from_date)
            page.enter_to_created_date(to_date)

        self._verify_date_difference(search_type,
                                     enter_value,
                                     'Warning\nFrom Created Date should be within the 90 days before the'
                                     ' To Created Date')

    def _verify_resolution_date_difference(self, search_type: str):
        def enter_value(from_date: str, to_date: str):
            page = self.page.search.search_activities
            page.enter_from_resolution_date(from_date)
            page.enter_to_resolution_date(to_date)

        self._verify_date_difference(search_type,
                                     enter_value,
                                     'Warning\nFrom Resolution Date should be within the 90 days before the'
                                     ' To Resolution Date')

    def _verify_bp_routed_date_difference(self, search_type: str):
        def enter_value(from_date: str, to_date: str):
            page = self.page.search.search_activities
            page.enter_from_bp_routed_date(from_date)
            page.enter_to_bp_routed_date(to_date)

        self._verify_date_difference(search_type,
                                     enter_value,
                                     'Warning\nFrom BP Routed Date should be within the 90 days before the'
                                     ' To BP Routed Date')

    def _verify_call_tracking_date_difference(self, search_type: str):
        def enter_value(from_date: str, to_date: str):
            page = self.page.search.search_activities
            page.enter_from_call_tracking_date(from_date)
            page.enter_to_call_tracking_date(to_date)

        self._verify_date_difference(search_type,
                                     enter_value,
                                     'Warning\nFrom Call Tracking Date should be within the 90 days before the'
                                     ' To Call Tracking Date')

    def _verify_follow_up_date_difference(self, search_type: str):
        def enter_value(from_date: str, to_date: str):
            page = self.page.search.search_activities
            page.enter_from_follow_up_date(from_date)
            page.enter_to_follow_up_date(to_date)

        self._verify_date_difference(search_type,
                                     enter_value,
                                     'Warning\nFrom Follow Up Date should be within the 90 days before the'
                                     ' To Follow Up Date')

    def _verify_date_difference(self, search_type: str, action: any, message: str):
        from_date = datetime.now().strftime(DATE_FORMAT)
        to_date = (datetime.now() + timedelta(days=91)).strftime(DATE_FORMAT)
        self.page.common.menu.open_search_activities()
        page = self.page.search.search_activities
        page.click_on_reset()
        page.select_search_type(search_type)
        action(from_date, to_date)
        page.click_on_search_activities()
        self.verification.toaster.equals(message)
