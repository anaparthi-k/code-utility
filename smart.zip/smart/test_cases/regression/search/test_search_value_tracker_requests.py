from datetime import datetime, timedelta
from typing import List
import pytest
from test_cases.test_fixture_base import TestFixtureBase
from utils.constants import DATE_FORMAT


class TestSearchValueTrackerRequests(TestFixtureBase):
    # self.factory.page.search.search_value_tracker_requests
    # self.page.search.search_value_tracker_requests

    def test_value_tracker_requests_status_should_open(self):
        self._verify_status_should_open()

    def test_value_tracker_requests_owner_filter(self):
        self._verify_owner_filter()

    def test_value_tracker_requests_owner_team_filter(self):
        self._verify_owner_team_filter()

    def test_value_tracker_requests_status_complete_should_have_completion_date(self):
        self._verify_status_complete_should_have_completion_date()

    def test_value_tracker_requests_reset_functionality(self):
        def search_in_page():
            search = self.factory.page.search.search_value_tracker_requests.create_value_tracker_requests_search()
            self.page.search.search_value_tracker_requests.value_tracker_requests_search(search)

        self._verify_reset(search_in_page)

    def test_value_tracker_requests_start_date_difference(self):
        self._verify_start_date_difference()

    def test_value_tracker_requests_completion_date_difference(self):
        self._verify_completion_date_difference()

    def test_value_tracker_requests_bp_routed_date_difference(self):
        self._verify_bp_routed_date_difference()

    def test_value_tracker_requests_follow_up_date_difference(self):
        self._verify_follow_up_date_difference()
    
    def _verify_status_should_open(self):
        self.page.common.menu.open_search_value_tracker_requests()
        page = self.page.search.search_value_tracker_requests
        page.click_on_reset()
        page.select_request_status('InProgress')
        page.click_on_search_value_tracker_requests_with_wait()
        pagination = page.create_pagination()
        self.verification.pagination.validate_equals(pagination, column=5, value='InProgress')

    def _verify_owner_filter(self):
        self.page.common.menu.open_search_value_tracker_requests()
        page = self.page.search.search_value_tracker_requests
        page.click_on_reset()
        name = self.page.common.menu.display_name()
        page.enter_owner(name)
        page.click_on_search_value_tracker_requests_with_wait()
        pagination = page.create_pagination()
        self.verification.pagination.validate_contains(pagination, column=2, value=name.replace(',', ''))

    def _verify_owner_team_filter(self):
        self.page.common.menu.open_search_value_tracker_requests()
        page = self.page.search.search_value_tracker_requests
        page.click_on_reset()
        page.select_owner_team('Audit Manager')
        page.click_on_search_value_tracker_requests_with_wait()
        pagination = page.create_pagination()
        self.verification.pagination.validate_equals(pagination, column=3, value='Audit Manager')

    def _verify_status_complete_should_have_completion_date(self):
        self.page.common.menu.open_search_value_tracker_requests()
        page = self.page.search.search_value_tracker_requests
        page.click_on_reset()
        page.select_request_status('Completed')
        page.click_on_search_value_tracker_requests_with_wait()
        pagination = page.create_pagination()
        self.verification.pagination.validate_not_equals(pagination, column=7, value='')

    def _verify_reset(self, action: any):
        assert action is not None
        self.page.common.menu.open_search_value_tracker_requests()
        search_value_tracker_requests_page = self.page.search.search_value_tracker_requests
        search_value_tracker_requests_page.click_on_reset()
        before_reset = search_value_tracker_requests_page.get_data()
        action()
        search_value_tracker_requests_page.click_on_reset()
        after_reset = search_value_tracker_requests_page.get_data()
        self.assertion.equals(before_reset, after_reset, 'Reset form data in search request form')

    def _verify_start_date_difference(self):
        def enter_value(from_date: str, to_date: str):
            page = self.page.search.search_value_tracker_requests
            page.enter_from_start_date(from_date)
            page.enter_to_start_date(to_date)

        self._verify_date_difference(enter_value,
                                     'Warning\nFrom Start Date should be within the 90 days'
                                     ' before the To Start Date')

    def _verify_completion_date_difference(self):
        def enter_value(from_date: str, to_date: str):
            page = self.page.search.search_value_tracker_requests
            page.enter_from_completion_date(from_date)
            page.enter_to_completion_date(to_date)

        self._verify_date_difference(enter_value,
                                     'Warning\nFrom Resolution Date should be within the 90 days'
                                     ' before the To Resolution Date')

    def _verify_bp_routed_date_difference(self):
        def enter_value(from_date: str, to_date: str):
            page = self.page.search.search_value_tracker_requests
            page.enter_from_bp_routed_date(from_date)
            page.enter_to_bp_routed_date(to_date)

        self._verify_date_difference(enter_value,
                                     'Warning\nFrom BP Routed Date should be within the 90 days' 
                                     ' before the To BP Routed Date')

    def _verify_follow_up_date_difference(self):
        def enter_value(from_date: str, to_date: str):
            page = self.page.search.search_value_tracker_requests
            page.enter_from_follow_up_date(from_date)
            page.enter_to_follow_up_date(to_date)

        self._verify_date_difference(enter_value,
                                     'Warning\nFrom Follow Up Date should be within the 90 days' 
                                     ' before the To Follow Up Date')

    def _verify_date_difference(self, action: any, message: str):
        from_date = datetime.now().strftime(DATE_FORMAT)
        to_date = (datetime.now() + timedelta(days=91)).strftime(DATE_FORMAT)
        self.page.common.menu.open_search_value_tracker_requests()
        page = self.page.search.search_value_tracker_requests
        page.click_on_reset()
        action(from_date, to_date)
        page.click_on_search_value_tracker_requests()
        self.verification.toaster.equals(message)