from test_cases.test_fixture_base import TestFixtureBase


class TestSearchDeliverables(TestFixtureBase):
    # self.factory.page.search.search_deliverables
    # self.page.search.search_deliverables
    pass
