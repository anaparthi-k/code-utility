from test_cases.test_fixture_base import TestFixtureBase


class TestManageUser(TestFixtureBase):

    def test_search_button(self):
        self.page.common.menu.open_manage_user()
        search_form = self.factory.page.admin.manage_user_search.create_search()
        self.page.admin.manage_user_search.perform_search(search_form)
        self.verification.element.validate(search_form.ms_id)
        pass

    def test_search_reset_button(self):
        self.page.common.menu.open_manage_user()
        before_reset = self.page.admin.manage_user_search.get_data()
        search_form = self.factory.page.admin.manage_user_search.create_search()
        self.page.admin.manage_user_search.perform_search(search_form)
        self.page.admin.manage_user_search.click_on_reset_button()
        after_reset = self.page.admin.manage_user_search.get_data()
        self.assertion.equals(before_reset, after_reset, 'Reset form data in search form')
        pass

    def test_search_edit_button(self):
        pass

    def test_add_user_button_in_search_page(self):
        self.page.common.menu.open_manage_user()
        self.page.admin.manage_user_search.click_on_add_user_button()
        header_title = self.page.admin.manage_user_search.get_header_text()
        self.assertion.equals('User Management - Add User', header_title, 'Header title')
        pass

    def test_add_user_button_in_add_user_page(self):
        self.page.common.menu.open_manage_user()
        self.page.admin.manage_user_search.click_on_add_user_button()
        search_form = self.factory.page.admin.manage_user_add.create_add()
        self.page.admin.manage_user_add.add_user(search_form)
        self.page.admin.manage_user_add.click_on_yes_button()
        self.verification.toaster.equals(f"Warning\nUser Already Exists! Not Able to Add User")
        pass

    def test_add_user_cancel_button(self):
        self.page.common.menu.open_manage_user()
        self.page.admin.manage_user_search.click_on_add_user_button()
        old_header_title = self.page.admin.manage_user_add.get_header_text()
        self.page.admin.manage_user_add.click_on_cancel_button()
        new_header_title = self.page.admin.manage_user_search.get_header_text()
        self.assertion.not_equals(old_header_title, new_header_title, 'Header title')
        pass

    def test_add_user_reset_button(self):
        self.page.common.menu.open_manage_user()
        self.page.admin.manage_user_search.click_on_add_user_button()
        before_reset = self.page.admin.manage_user_add.get_data()
        search_form = self.factory.page.admin.manage_user_add.create_add()
        self.page.admin.manage_user_add.enter_form(search_form)
        self.page.admin.manage_user_add.click_on_reset_button()
        after_reset = self.page.admin.manage_user_add.get_data()
        self.assertion.equals(before_reset, after_reset, 'Reset form data in search form')
        pass
