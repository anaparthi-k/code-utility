from test_cases.test_fixture_base import TestFixtureBase


class TestSmartConfigurations(TestFixtureBase):

    def test_selected_move_left_to_right(self):
        self.page.common.menu.open_smart_configurations()
        search_form = self.factory.page.admin.smart_configurations.create_search()
        page = self.page.admin.smart_configurations
        page.perform_search(search_form)
        items = page.get_all_items_in_available()
        if len(items) == 0:
            page.click_on_forward()
            self.assertion.equals('No reports present in assigned reports section.',
                                  self.page.common.dialog.get_text(),
                                  "Dialog text validation")
            page.click_on_ok()
            page.click_on_all_backward()
            items = page.get_all_items_in_available()
        odd_items = items[::2]
        page.select_available_items(odd_items)
        self.page.admin.smart_configurations.click_on_forward()
        item_in_available = self.page.admin.smart_configurations.get_all_items_in_available()
        items_in_assigned = self.page.admin.smart_configurations.get_all_items_in_assigned()
        self.assertion.validate_intersection(item_in_available, items_in_assigned)
        self.page.admin.smart_configurations.click_on_save()
        self.verification.toaster.equals("Success\nReport access updated successfully")
        pass

    def test_selected_move_right_to_left(self):
        self.page.common.menu.open_smart_configurations()
        search_form = self.factory.page.admin.smart_configurations.create_search()
        page = self.page.admin.smart_configurations
        page.perform_search(search_form)
        items = page.get_all_items_in_assigned()
        if len(items) == 0:
            page.click_on_backward()
            self.assertion.equals('No reports present in assigned reports section.',
                                  self.page.common.dialog.get_text(),
                                  "Dialog text validation")
            page.click_on_ok()
            page.click_on_all_forward()
            items = page.get_all_items_in_assigned()
        odd_items = items[::2]
        page.select_assigned_items(odd_items)
        self.page.admin.smart_configurations.click_on_backward()
        items_in_available = self.page.admin.smart_configurations.get_all_items_in_available()
        items_in_assigned = self.page.admin.smart_configurations.get_all_items_in_assigned()
        self.assertion.validate_intersection(items_in_available, items_in_assigned)
        self.page.admin.smart_configurations.click_on_save()
        self.verification.toaster.equals('Success\nReport access updated successfully')
        pass

    def test_complete_move_left_to_right(self):
        self.page.common.menu.open_smart_configurations()
        search_form = self.factory.page.admin.smart_configurations.create_search()
        self.page.admin.smart_configurations.perform_search(search_form)
        page = self.page.admin.smart_configurations
        items = page.get_all_items_in_available()
        if len(items) == 0:
            page.click_on_all_forward()
            self.assertion.equals('No reports present in available reports section.',
                                  self.page.common.dialog.get_text(),
                                  "Dialog text validation")
            page.click_on_ok()
            page.click_on_all_backward()
        self.page.admin.smart_configurations.click_on_all_forward()
        items_in_assigned = self.page.admin.smart_configurations.get_all_items_in_available()
        items_in_available = self.page.admin.smart_configurations.get_all_items_in_assigned()
        self.assertion.validate_intersection(items_in_available, items_in_assigned)
        self.page.admin.smart_configurations.click_on_save()
        self.verification.toaster.equals('Success\nReport access updated successfully')
        pass

    def test_complete_right_to_left(self):
        self.page.common.menu.open_smart_configurations()
        search_form = self.factory.page.admin.smart_configurations.create_search()
        page = self.page.admin.smart_configurations
        page.perform_search(search_form)
        items = page.get_all_items_in_assigned()
        if len(items) == 0:
            page.click_on_backward()
            self.assertion.equals('No reports present in assigned reports section.',
                                  self.page.common.dialog.get_text(),
                                  "Dialog text validation")
            page.click_on_ok()
            page.click_on_all_forward()
        self.page.admin.smart_configurations.click_on_all_backward()
        items_in_assigned = self.page.admin.smart_configurations.get_all_items_in_assigned()
        items_in_available = self.page.admin.smart_configurations.get_all_items_in_available()
        self.assertion.validate_intersection(items_in_available, items_in_assigned)
        self.page.admin.smart_configurations.click_on_save()
        self.verification.toaster.equals('Success\nReport access updated successfully')
        pass
