from test_cases.test_fixture_base import TestFixtureBase


class TestGroupMapping(TestFixtureBase):

    def test_search(self):
        self.page.common.menu.open_group_mapping()
        search_form = self.factory.page.admin.group_mapping.create_search()
        self.page.admin.group_mapping.search(search_form)
        self.verification.element.validate(search_form.customer_name)
        self.verification.element.validate(search_form.metrics)
        pass

    def test_map_to_group_name(self):
        self.page.common.menu.open_group_mapping()
        map_to_group_name_form = self.factory.page.admin.group_mapping.create_map_to_group_name()
        self.page.admin.group_mapping.map_to_group_name(map_to_group_name_form)
        self.verification.element.validate(map_to_group_name_form.customer_name)
        self.verification.element.validate(map_to_group_name_form.metrics)
        self.verification.element.validate(map_to_group_name_form.name_to_replace)
        pass

    def test_reset_in_search(self):
        self.page.common.menu.open_group_mapping()
        before_reset = self.page.admin.group_mapping.get_data()
        search_form = self.factory.page.admin.group_mapping.create_search()
        self.page.admin.group_mapping.search(search_form)
        self.page.admin.group_mapping.click_on_reset_button()
        after_reset = self.page.admin.group_mapping.get_data()
        self.assertion.equals(before_reset, after_reset, 'Reset form data in search form')
        pass

    def test_update(self):
        self.page.common.menu.open_group_mapping()
        search_form = self.factory.page.admin.group_mapping.create_search()
        self.page.admin.group_mapping.search(search_form)
        self.page.admin.group_mapping.click_on_edit_button()
        update_form = self.factory.page.admin.group_mapping.create_update()
        self.page.admin.group_mapping.update_field(update_form)
        self.verification.element.validate(update_form.name_to_replace)
        pass

    def test_delete(self):
        self.page.common.menu.open_group_mapping()
        search_form = self.factory.page.admin.group_mapping.create_search()
        self.page.admin.group_mapping.search(search_form)
        if not self.page.admin.group_mapping.is_row_exists_with():
            add_form = self.factory.page.admin.group_mapping.create_map_to_group_name()
            self.page.admin.group_mapping.map_to_group_name(add_form)
        self._delete_row()

    def _delete_row(self):
        self.page.admin.group_mapping.click_on_delete_button()
        dialog_text = self.page.common.dialog.get_text()
        self.logger.debug(dialog_text)
        self.page.common.dialog.click_yes_button()
        self.verification.toaster.validate_any_list_item("Deleted\nDeleted successfully")
        self.driver.wait_till_spinner_off()
