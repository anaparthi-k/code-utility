from core.keyboard import Keyboard
from test_cases.test_fixture_base import TestFixtureBase
from typing import Final


class TestScorecardUpdate(TestFixtureBase):
    _FILE_PATH: Final = 'resources\\admin\\scorecard_update\\calpers_2021_Q1_2021-25-8.pptx'

    def test_search(self):
        self.page.common.menu.open_scorecard_update()
        search_form = self.factory.page.admin.scorecard_update.create_search()
        self.page.admin.scorecard_update.search(search_form)
        Keyboard.escape()
        self.verification.element.validate(search_form.customer)
        pass

    def test_upload(self):
        self.page.common.menu.open_scorecard_update()
        upload_form = self.factory.page.admin.scorecard_update.create_upload(self._FILE_PATH)
        self.page.admin.scorecard_update.upload(upload_form)
        self.verification.element.validate(upload_form.description)
        pass

    def test_reset(self):
        self.page.common.menu.open_scorecard_update()

        def enter_data():
            upload_form = self.factory.page.admin.scorecard_update.create_upload(self._FILE_PATH)
            self.page.admin.scorecard_update.fill_upload(upload_form)
        self.verification.reset.validate(self.page.admin.scorecard_update, enter_data)
        self._verify_description_is_not_exists()
        pass

    def test_delete(self):
        self.page.common.menu.open_scorecard_update()
        upload_form = self.factory.page.admin.scorecard_update.create_upload(self._FILE_PATH)
        self.page.admin.scorecard_update.fill_upload(upload_form)
        self.page.admin.scorecard_update.click_on_delete()
        self._verify_description_is_not_exists()
        pass

    def _verify_description_is_not_exists(self):
        is_description_exists = self.page.admin.scorecard_update.is_description_exists()
        self.logger.debug(f"Verifying that description should not exists but exist status is:"
                          f" {is_description_exists}")
        assert is_description_exists
