from test_cases.test_fixture_base import TestFixtureBase


class TestNotificationsConfiguration(TestFixtureBase):

    def test_header_is_matched(self):
        self.page.common.menu.open_notifications_configuration()
        header_title = self.page.admin.notification_configuration_search.get_header_text()
        self.assertion.equals('Notifications-Configuration | Search', header_title, 'Header title')
        pass

    def test_search_button_in_search_page(self):
        self.page.common.menu.open_notifications_configuration()
        search_form = self.factory.page.admin.notification_configuration_search.create_search()
        self.page.admin.notification_configuration_search.perform_search(search_form)
        self.verification.element.validate(search_form.metric_name)
        pass

    def test_search_reset_in_search_page(self):
        self.page.common.menu.open_notifications_configuration()
        before_reset = self.page.admin.notification_configuration_search.get_data()
        search_form = self.factory.page.admin.notification_configuration_search.create_search()
        self.page.admin.notification_configuration_search.perform_search(search_form)
        self.page.admin.notification_configuration_search.click_on_reset_button()
        after_reset = self.page.admin.notification_configuration_search.get_data()
        self.assertion.equals(before_reset, after_reset, 'Reset form data in search form')
        pass

    def test_search_cancel_should_redirect_to_home(self):
        self.page.common.menu.open_notifications_configuration()
        old_header_title = self.page.admin.notification_configuration_search.get_header_text()
        self.page.admin.notification_configuration_search.click_on_cancel()
        new_header_title = self.page.admin.notification_configuration_search.get_header_text()
        self.assertion.not_equals(old_header_title, new_header_title, 'Header title')
        pass

    def test_add_notification(self):
        self.page.common.menu.open_notifications_configuration()
        search_form = self.factory.page.admin.notification_configuration_add.create_add()
        self.page.admin.notification_configuration_add.perform_add_notification(search_form)
        self.assertion.equals('Do you want to add this notification?', self.page.common.dialog.get_text(), "Dialog text validation")
        self.page.admin.notification_configuration_add.click_on_yes_button()
        self.verification.toaster.equals(f'Success\nNotification is configured successfully for Metric:{search_form.metric_name} - Key:{search_form.key_name} - Customer:{search_form.customer_name}')
        pass

    def test_add_reset_in_add_page(self):
        self.page.common.menu.open_notifications_configuration()
        self.page.admin.notification_configuration_add.click_on_search_add_notifications()
        before_reset = self.page.admin.notification_configuration_add.get_data()
        search_form = self.factory.page.admin.notification_configuration_add.create_add()
        self.page.admin.notification_configuration_add.enter_form(search_form)
        self.page.admin.notification_configuration_add.click_on_reset_button()
        after_reset = self.page.admin.notification_configuration_add.get_data()
        self.assertion.equals(before_reset, after_reset, 'Reset form data in search form')
        pass

    def test_add_cancel_should_redirect_to_search_page(self):
        self.page.common.menu.open_notifications_configuration()
        self.page.admin.notification_configuration_search.click_on_add()
        old_header_title = self.page.admin.notification_configuration_add.get_header_text()
        self.page.admin.notification_configuration_add.click_on_cancel_button()
        new_header_title = self.page.admin.notification_configuration_search.get_header_text()
        self.assertion.not_equals(old_header_title, new_header_title, 'Header title')
        pass
