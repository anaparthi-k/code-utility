import pytest
from test_cases.test_fixture_base import TestFixtureBase


class TestFrequencyConfiguration(TestFixtureBase):

    @pytest.mark.order(2)
    def test_search(self):
        self.page.common.menu.open_frequency_configuration()
        search_form = self.factory.page.admin.frequency_configuration.create_search()
        self.page.admin.frequency_configuration.search(search_form)
        self.verification.element.validate(search_form.customer_name)
        pass

    @pytest.mark.order(3)
    def test_save(self):
        self.page.common.menu.open_frequency_configuration()
        search_form = self.factory.page.admin.frequency_configuration.create_search()
        self.page.admin.frequency_configuration.search(search_form)
        self.verification.element.validate(search_form.customer_name)
        pass

    @pytest.mark.order(1)
    def test_update(self):
        self.page.common.menu.open_frequency_configuration()
        search_form = self.factory.page.admin.frequency_configuration.create_search()
        self.page.admin.frequency_configuration.search(search_form)
        search_form = self.factory.page.admin.frequency_configuration.create_update()
        self.page.admin.frequency_configuration.update(search_form)
        self.verification.element.validate(search_form.sae)
        pass
