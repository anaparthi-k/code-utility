from test_cases.test_fixture_base import TestFixtureBase
import pytest
from utils.csv import read_csv_file


class TestRecurringDeliverables(TestFixtureBase):

    def test_header_is_matched(self):
        self.page.common.menu.open_create_recurring_deliverables()
        header_title = self.page.recurring_deliverables.creation.get_header_text()
        self.assertion.equals('Create Recurring Deliverables', header_title, 'Header title')
        pass

    def test_cancel_should_redirect_to_home(self):
        self.page.common.menu.open_create_recurring_deliverables()
        page = self.page.recurring_deliverables.creation
        old_header_title = page.get_header_text()
        page.click_on_cancel()
        self.page.common.dialog.click_yes_button()
        new_header_title = page.get_header_text()
        self.assertion.not_equals(old_header_title, new_header_title, 'Header title')
        pass

    def test_save(self):
        self.page.common.menu.open_create_recurring_deliverables()
        form = self.factory.page.recurring_deliverables.creation.create_save()
        self.page.recurring_deliverables.creation.save_create_form(form)
        self.verification.toaster.contains('is Added Successfully')
        pass

    @pytest.mark.parametrize('line', read_csv_file('resources\\recurring_deliverables\\create_recurring_deliverables\\edit.csv'))
    def test_edit_data_loaded(self, line):
        child_task_id = line[0]
        self._open_recurring_delivery(child_task_id)
        all_filed_text = self.page.recurring_deliverables.creation.get_all_filed_text()
        self.assertion.equals(line[1:], all_filed_text, 'All fields text from csv')
        pass

    @pytest.mark.parametrize('line', read_csv_file('resources\\recurring_deliverables\\create_recurring_deliverables\\open_task.csv'))
    def test_quality_enabled_after_child_task_complete(self, line):
        child_task_id = line[0]
        self._open_recurring_delivery(child_task_id)
        form = self.factory.page.recurring_deliverables.child_task.create_edit()
        page = self.page.recurring_deliverables.child_task
        page.click_on_edit_button(child_task_id)
        page.fill_data(form)
        page.click_on_update()
        assert page.is_quality_check_enabled()
        assert page.is_date_enabled()
        pass

    @pytest.mark.parametrize('line', read_csv_file('resources\\recurring_deliverables\\create_recurring_deliverables\\open_task.csv'))
    def test_attachment_is_uploaded(self, line):
        child_task_id = line[0]
        self._open_recurring_delivery(child_task_id)
        form = self.factory.workflow.smart.attachment.create_add()
        self.workflow.smart.attachment.verify_attachment_is_uploaded(form)
        pass

    @pytest.mark.parametrize('line', read_csv_file('resources\\recurring_deliverables\\create_recurring_deliverables\\open_task.csv'))
    def test_reset_during_edit(self, line):
        child_task_id = line[0]
        self._open_recurring_delivery(child_task_id)
        page = self.page.recurring_deliverables.creation
        before_reset_data = page.get_data()
        form = self.factory.page.recurring_deliverables.creation.create_save()
        page.enter_form_data(form)
        page.click_on_reset()
        after_reset_data = page.get_data()
        self.assertion.equals(before_reset_data, after_reset_data, 'Update Reset Validaiton')
        pass

    def _open_recurring_delivery(self, child_task_id):
        self.page.common.menu.open_search_deliverables()
        self.page.search.search_deliverables.enter_child_task_id(child_task_id)
        self.page.search.search_deliverables.click_on_search_tasks()
        self.page.search.search_deliverables.click_on_edit_button(child_task_id)

    pass
