from test_cases.test_fixture_base import TestFixtureBase


class TestCreateCapabilityRequest(TestFixtureBase):
    # self.factory.page.capability_request.create_capability_request
    # self.page.capability_request.create_capability_request
    pass
