from test_cases.test_fixture_base import TestFixtureBase


class TestHome(TestFixtureBase):
    # self.factory.page.home.home
    # self.page.home.home
    pass
