from test_cases.test_fixture_base import TestFixtureBase


class TestReport(TestFixtureBase):
    # self.factory.page.report.report
    # self.page.report.report
    pass
