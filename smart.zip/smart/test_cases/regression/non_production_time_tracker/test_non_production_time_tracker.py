from datetime import datetime, timedelta
from test_cases.test_fixture_base import TestFixtureBase
from utils.constants import DATE_FORMAT
from models.pages.non_production_time_tracker.non_production_time_tracker_model import \
    NonProductionTimeTrackerSearchModel


class TestNonProductionTimeTracker(TestFixtureBase):

    def test_page_loaded(self):
        self.page.common.menu.open_non_production_time_tracker()
        self._verify_search_form_header_title()
        pass

    def test_date_range_with_in_15_days(self):
        self.page.common.menu.open_non_production_time_tracker()
        search = self.page.non_production_time_tracker.search
        if not search.is_grid_has_records():
            rows = search.table_rows()
            from_date = (datetime.now() - timedelta(days=15)).strftime(DATE_FORMAT)
            to_date = datetime.now().strftime(DATE_FORMAT)
            self.assertion.table_column_with_in_date_range(rows, 3, DATE_FORMAT, from_date, to_date)
        pass

    def test_clicking_on_add_time_opens_add_time_form(self):
        self._open_add_time_form()
        self._verify_add_time_form_header_title()
        pass

    def test_pto_status_should_be_pending(self):
        self._select_pto_in_time_category()
        status = self.page.non_production_time_tracker.add_time.get_status_value()
        self.assertion.equals('Pending', status, "Status should be pending")
        pass

    def test_pto_status_enabled_for_admin_user(self):
        self._select_pto_in_time_category()
        add_time = self.page.non_production_time_tracker.add_time
        is_admin = add_time.is_role_text('admin')
        self.assertion.equals(is_admin, add_time.get_status_is_enabled(), "PTO enable status for admin")
        pass

    def _select_pto_in_time_category(self):
        self._open_add_time_form()
        add_time = self.page.non_production_time_tracker.add_time
        add_time.select_time_category('PTO')

    def test_project_should_enable_subcategory_in_add_form(self):
        self._open_add_time_form()
        add_time = self.page.non_production_time_tracker.add_time
        add_time.select_time_category('Project')
        self.assertion.equals(add_time.get_subcategory_enabled_status(), True,
                              "Add time form sub category enabled status for project")
        pass

    def test_clicking_on_cancel_in_add_time_should_go_to_search_page(self):
        self._open_add_time_form()
        self._verify_add_time_form_header_title()
        self.page.non_production_time_tracker.add_time.click_on_cancel_button()
        self._verify_search_form_header_title()
        pass

    def test_reset_in_search(self):
        self.page.common.menu.open_non_production_time_tracker()

        def enter_data():
            search_form = self.factory.page.non_production_time_tracker.search.create_search()
            search_form.user = self.page.common.menu.display_name()
            self.page.non_production_time_tracker.search.perform_search(search_form)

        self.verification.reset.validate(self.page.non_production_time_tracker.search, enter_data)
        pass

    def test_add_time_form_save_time_spent_start_end_time_with_7_5_hours(self):
        self._open_add_time_form_by_cleaning_up_current_rows()
        form = self.page.non_production_time_tracker.add_time
        form.select_time_category('Training')
        form.select_start_time('9:00 AM', '12:00 PM')
        form.click_on_save()
        self.verification.toaster.equals(
            "Add Time Tracker Details\nSuccess: Non-Production Time Tracker Added Successfully")
        pass

    def test_edit_record(self):
        date_value = datetime.now().strftime(DATE_FORMAT)
        self.page.common.menu.open_non_production_time_tracker()
        search_form = self.page.non_production_time_tracker.search
        if not search_form.is_row_exists_with_date(date_value):
            self._save_record_and_back_to_search_page()
        search_form.click_on_edit_button(date_value)
        form = self.page.non_production_time_tracker.add_time
        form.select_time_category('Meeting')
        form.click_on_update()
        self.verification.toaster.equals(
            "Update Time Tracker Details\nSuccess: Non-Production Time Tracker Updated Successfully")
        self.page.non_production_time_tracker.add_time.click_on_cancel_button()
        self.verification.element.validate('Meeting')
        pass

    def test_delete_record(self):
        date_value = datetime.now().strftime(DATE_FORMAT)
        self.page.common.menu.open_non_production_time_tracker()
        search_form = self.page.non_production_time_tracker.search
        if not search_form.is_row_exists_with_date(date_value):
            self._save_record_and_back_to_search_page()
        self._delete_rows_of_date(date_value)
        pass

    def test_add_time_form_save_time_spent_hours_with_7_5_hours(self):
        self._open_add_time_form_by_cleaning_up_current_rows()
        form = self.page.non_production_time_tracker.add_time
        form.select_time_category('Other')
        form.enter_hours('4.5')
        form.click_on_save()
        self.verification.toaster.equals(
            "Add Time Tracker Details\nSuccess: Non-Production Time Tracker Added Successfully")
        pass

    def test_add_time_form_save_time_spent_all_days(self):
        self._open_add_time_form_by_cleaning_up_current_rows()
        form = self.page.non_production_time_tracker.add_time
        form.select_time_category('Other')
        form.select_all_days()
        form.click_on_save()
        self.verification.toaster.equals(
            "Add Time Tracker Details\nSuccess: Non-Production Time Tracker Added Successfully")
        pass

    def test_reset_button_click_in_add_time_form(self):
        self._open_add_time_form()
        add_time = self.page.non_production_time_tracker.add_time
        before_form_data = add_time.get_data()
        model = self.factory.page.non_production_time_tracker.add_time.create_add()
        add_time.fill(model)
        self.page.non_production_time_tracker.add_time.click_on_reset_button()
        after_form_data = add_time.get_data()
        self.logger.debug(f"Before entering data:{str(before_form_data)}")
        self.logger.debug(f"After entering data:{str(after_form_data)}")
        assert before_form_data == after_form_data
        pass

    def _save_record_and_back_to_search_page(self):
        self._open_add_time_form_by_cleaning_up_current_rows()
        add_time = self.page.non_production_time_tracker.add_time
        add_time.select_time_category('Other')
        add_time.enter_hours('4.5')
        add_time.click_on_save()
        add_time.click_on_cancel_button()

    def _open_add_time_form_by_cleaning_up_current_rows(self):
        self.page.common.menu.open_non_production_time_tracker()
        self._delete_all_current_date_rows()
        self.page.non_production_time_tracker.search.click_on_add_time_button()

    def _delete_all_current_date_rows(self):
        date_value = datetime.now().strftime(DATE_FORMAT)

        form = NonProductionTimeTrackerSearchModel()
        form.user = self.page.common.menu.display_name()
        form.from_date = date_value
        form.to_date = date_value
        search_form = self.page.non_production_time_tracker.search
        search_form.perform_search(form)
        while search_form.is_row_exists_with_date(date_value):
            self._delete_rows_of_date(date_value)

        search_form.click_on_reset_button()

        form.all_day = True
        search_form.perform_search(form)
        while search_form.is_row_exists_with_date(date_value):
            self._delete_rows_of_date(date_value)

    def _delete_rows_of_date(self, date: str):
        self.page.non_production_time_tracker.search.click_on_delete_button(date)
        dialog_text = self.page.common.dialog.get_text()
        self.logger.debug(f"Trying to validate '{date}' exits in the dialog box text '{dialog_text}'")
        assert date in dialog_text
        self.page.common.dialog.click_yes_button()
        self.verification.toaster.equals(
            "Deleted Successfully\nSuccess: Non-Production Time Tracker Deleted Successfully")
        self.driver.wait_till_spinner_off()

    def _verify_search_form_header_title(self):
        header = self.page.non_production_time_tracker.search.get_header_title()
        self.assertion.equals("Non Production Time Tracker", header, "Search Form header title")

    def _verify_add_time_form_header_title(self):
        header = self.page.non_production_time_tracker.add_time.get_header_title()
        self.assertion.equals('Non Production Time Tracker | Add', header, "Add Time Form header title")

    def _open_add_time_form(self):
        self.page.common.menu.open_non_production_time_tracker()
        self.page.non_production_time_tracker.search.click_on_add_time_button()
        self.driver.wait_till_spinner_off()
