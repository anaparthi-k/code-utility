from test_cases.test_fixture_base import TestFixtureBase


class TestCrtResolutionSubsection(TestFixtureBase):
    # self.factory.page.activity_management.create_crt_projects.crt_resolution_subsection
    # self.page.activity_management.create_crt_projects.crt_resolution_subsection
    pass
