from test_cases.test_fixture_base import TestFixtureBase


class TestPostResolutionSubsection(TestFixtureBase):
    # self.factory.page.activity_management.create_crt_projects.post_resolution_subsection
    # self.page.activity_management.create_crt_projects.post_resolution_subsection
    pass
