from test_cases.test_fixture_base import TestFixtureBase


class TestGroupInformationSubsection(TestFixtureBase):
    # self.factory.page.activity_management.create_crt_projects.group_information_subsection
    # self.page.activity_management.create_crt_projects.group_information_subsection
    pass
