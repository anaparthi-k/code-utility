from test_cases.test_fixture_base import TestFixtureBase


class TestAdditionalInfoTrackingSubsection(TestFixtureBase):
    # self.factory.page.activity_management.create_crt_projects.additional_info_tracking_subsection
    # self.page.activity_management.create_crt_projects.additional_info_tracking_subsection
    pass
