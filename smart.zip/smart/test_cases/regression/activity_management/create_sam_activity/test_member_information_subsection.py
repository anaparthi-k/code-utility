from test_cases.test_fixture_base import TestFixtureBase


class TestMemberInformationSubsection(TestFixtureBase):
    # self.factory.page.activity_management.create_sam_activity.member_information_subsection
    # self.page.activity_management.create_sam_activity.member_information_subsection
    pass
