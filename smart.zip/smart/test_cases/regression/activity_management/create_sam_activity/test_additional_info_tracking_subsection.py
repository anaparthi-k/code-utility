from test_cases.test_fixture_base import TestFixtureBase


class TestAdditionalInfoTrackingSubsection(TestFixtureBase):
    # self.factory.page.activity_management.create_sam_activity.additional_info_tracking_subsection
    # self.page.activity_management.create_sam_activity.additional_info_tracking_subsection

    # def test_save(self):
    #     self.page.common.menu.open_sam_activity_management()
    #     form = self.factory.page.activity_management.create_sam_activity.additional_info_tracking_subsection.create_save()
    #     self.page.activity_management.create_sam_activity.additional_info_tracking_subsection.fill_form(form)
    #     self.verification.toaster.equals(f'{form.category} details are saved Successfully')
    #     pass

    def test_save(self):
        self.page.common.menu.open_sam_activity_management()
        factory = self.factory.page.activity_management.create_sam_activity.additional_info_tracking_subsection
        form = factory.create_save()
        page = self.page.activity_management.create_sam_activity.additional_info_tracking_subsection
        self.workflow.smart.subsection.verify_form_saved_with_spinner(page, form,
                                                                      f'{form.category} details are saved Successfully')
        pass
        
    def test_edit(self):
        self.page.common.menu.open_sam_activity_management()
        factory = self.factory.page.activity_management.create_sam_activity.additional_info_tracking_subsection
        save_form = factory.create_save()
        page = self.page.activity_management.create_sam_activity.additional_info_tracking_subsection
        edit_form = factory.create_edit()
        self.workflow.smart.subsection.verify_form_edit(page, edit_form, save_form.category,
                                                        'details are updated Successfully')
        pass

    # def test_edit(self):
    #     self.page.common.menu.open_sam_activity_management()
    #     form = self.factory.page.activity_management.create_sam_activity.additional_info_tracking_subsection.create_save()
    #     self.page.activity_management.create_sam_activity.additional_info_tracking_subsection.save_fill_form(form)
    #     self.page.activity_management.create_sam_activity.additional_info_tracking_subsection.click_on_table_edit_button()
    #     edit_form = self.factory.page.activity_management.create_sam_activity.additional_info_tracking_subsection.create_edit()
    #     self.page.activity_management.create_sam_activity.additional_info_tracking_subsection.click_on_update_button()
    #     self.verification.toaster.equals(f'{form.category} details are updated Successfully')
    #     pass

    # def test_delete(self):
    #     self.page.common.menu.open_sam_activity_management()
    #     form = self.factory.page.activity_management.create_sam_activity.additional_info_tracking_subsection.create_save()
    #     self.page.activity_management.create_sam_activity.additional_info_tracking_subsection.save_fill_form(form)
    #     self.page.activity_management.create_sam_activity.additional_info_tracking_subsection.click_on_table_delete_button()
    #     self.verification.toaster.equals(f'{form.category} details are deleted Successfully')
    #     pass

    def test_delete(self):
        self.page.common.menu.open_sam_activity_management()
        factory = self.factory.page.activity_management.create_sam_activity.additional_info_tracking_subsection
        page = self.page.activity_management.create_sam_activity.additional_info_tracking_subsection
        edit_form = factory.create_edit()
        self.workflow.smart.subsection.verify_form_delete(page, edit_form.category,
                                                          f'Do you want to delete {edit_form.category} ?',
                                                          f'{edit_form.category} details are deleted Successfully')
        pass

    pass
