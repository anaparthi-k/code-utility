from test_cases.test_fixture_base import TestFixtureBase


class TestSamRequestSubsection(TestFixtureBase):
    # self.factory.page.activity_management.create_sam_activity.sam_activity_subsection
    # self.page.activity_management.create_sam_activity.sam_activity_subsection
    pass
