from test_cases.test_fixture_base import TestFixtureBase


class TestCallTrackingSectionSubsection(TestFixtureBase):
    # self.factory.page.activity_management.create_sam_activity.calltracking_section_subsection
    # self.page.activity_management.create_sam_activity.calltracking_section_subsection
 
    def test_save(self):
        self.page.common.menu.open_sam_activity_management()
        factory = self.factory.page.activity_management.create_sam_activity.calltracking_section_subsection
        form = factory.create_save()
        page = self.page.activity_management.create_sam_activity.calltracking_section_subsection
        self.workflow.smart.subsection.verify_form_saved_with_spinner(page, form,
                                                                      f'is added Successfully')
        pass

    def test_edit(self):
        self.page.common.menu.open_sam_activity_management()
        factory = self.factory.page.activity_management.create_sam_activity.calltracking_section_subsection
        save_form = factory.create_save()
        page = self.page.activity_management.create_sam_activity.calltracking_section_subsection
        edit_form = factory.create_edit()
        self.workflow.smart.subsection.verify_form_edit(page, edit_form, save_form.inboundoutbound,
                                                        'is updated Successfully')
        pass

    pass
