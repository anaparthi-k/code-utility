from test_cases.test_fixture_base import TestFixtureBase
import datetime


class TestBpEngagementDetailsSubsection(TestFixtureBase):
    _SAVE_VALIDATION_MSG = ' is saved Successfully'
    _UPDATE_VALIDATION_MSG = ' is updated Successfully'
    _MANDATORY_FIELDS_WARNING = ' Warning \nPlease Enter Mandatory fields'
    _BUSINESS_PARTNER_DEFAULT_VALUE = 'AARP Medicare Supplement  (email) (5) '
    _BUSINESS_PARTNER_ALT_VALUE = 'Account Management Team (email) (2) '

    # self.factory.page.activity_management.create_sam_activity.bp_engagement_details_subsection
    # self.page.activity_management.create_sam_activity.bp_engagement_details_subsection
    
    def test_routed_status_for_save(self):
        self._open_form()
        self._verify_save_with_route(self._BUSINESS_PARTNER_DEFAULT_VALUE,
                                     self._SAVE_VALIDATION_MSG)
        pass

    def test_routed_status_for_edit(self):
        self._open_form()
        self._verify_save_with_route(self._BUSINESS_PARTNER_DEFAULT_VALUE,
                                     self._SAVE_VALIDATION_MSG)
        self._edit_gird(self._BUSINESS_PARTNER_DEFAULT_VALUE)
        self._verify_save_with_route(self._BUSINESS_PARTNER_ALT_VALUE,
                                     self._UPDATE_VALIDATION_MSG)
        pass

    def test_reset_during_edit(self):
        self._open_form()
        self._verify_save_with_route(self._BUSINESS_PARTNER_DEFAULT_VALUE,
                                     self._SAVE_VALIDATION_MSG)
        self._edit_gird(self._BUSINESS_PARTNER_DEFAULT_VALUE)
        page = self.page.activity_management.create_sam_activity.bp_engagement_details_subsection

        def enter_form_data():
            factory = self.factory.page.activity_management.create_sam_activity.bp_engagement_details_subsection
            form = factory.create_form_data()
            page.fill_form(form)
            pass

        self.verification.reset.validate(page, enter_form_data)
        pass

    def test_cancel_update_edit(self):
        factory = self.factory.page.activity_management.create_sam_activity.bp_engagement_details_subsection
        page = self.page.activity_management.create_sam_activity.bp_engagement_details_subsection
        self._open_form()
        page.click_on_reset_button()
        before_reset_data = page.get_data()
        self._verify_save_with_route(self._BUSINESS_PARTNER_DEFAULT_VALUE,
                                     self._SAVE_VALIDATION_MSG)
        self._edit_gird(self._BUSINESS_PARTNER_DEFAULT_VALUE)
        form = factory.create_form_data()
        page.fill_form(form)
        page.click_on_cancel_button()
        after_reset_data = page.get_data()
        self.assertion.equals(before_reset_data, after_reset_data, 'Cancel update validation')
        pass

    def _verify_save_with_route(self,
                                business_partner: str,
                                validation_msg: str):
        page = self.page.activity_management.create_sam_activity.bp_engagement_details_subsection
        page.select_business_partner(business_partner)
        page.select_routed_status('Routed')
        page.click_on_save_button()
        self.verification.toaster.equals(self._MANDATORY_FIELDS_WARNING)
        page.enter_description(f'Sample value on {datetime.datetime.now()}')
        page.click_on_save_button()
        self.verification.toaster.contains(validation_msg)

    def test_routed_status_withdrawn_for_save(self):
        self._open_form()
        self._verify_save_with_withdrawn(self._BUSINESS_PARTNER_DEFAULT_VALUE,
                                         self._SAVE_VALIDATION_MSG)
        pass

    def test_routed_status_withdrawn_for_edit(self):
        self._open_form()
        self._verify_save_with_withdrawn(self._BUSINESS_PARTNER_DEFAULT_VALUE,
                                         self._SAVE_VALIDATION_MSG)
        self._edit_gird(self._BUSINESS_PARTNER_DEFAULT_VALUE)
        self._verify_save_with_withdrawn(self._BUSINESS_PARTNER_ALT_VALUE,
                                         self._UPDATE_VALIDATION_MSG)
        pass

    def _verify_save_with_withdrawn(self,
                                    business_partner: str,
                                    validation_msg: str):
        page = self.page.activity_management.create_sam_activity.bp_engagement_details_subsection
        page.select_business_partner(business_partner)
        page.select_routed_status('Withdrawn')
        page.click_on_save_button()
        self.verification.toaster.contains(validation_msg)
        pass

    def test_routed_status_close_for_save(self):
        self._open_form()
        self._verify_saved_with_closed(self._BUSINESS_PARTNER_DEFAULT_VALUE,
                                       self._SAVE_VALIDATION_MSG)
        pass

    def test_routed_status_close_for_edit(self):
        self._open_form()
        self._verify_saved_with_closed(self._BUSINESS_PARTNER_DEFAULT_VALUE,
                                       self._SAVE_VALIDATION_MSG)
        self._edit_gird(self._BUSINESS_PARTNER_DEFAULT_VALUE)
        self._verify_saved_with_closed(self._BUSINESS_PARTNER_ALT_VALUE,
                                       self._UPDATE_VALIDATION_MSG)
        pass

    def _verify_saved_with_closed(self, business_partner: str, validation_msg: str):
        page = self.page.activity_management.create_sam_activity.bp_engagement_details_subsection
        page.select_business_partner(business_partner)
        page.select_routed_status('Closed')
        self.page.common.dialog.click_yes_button()
        resolution_date = page.get_bp_resolution()
        self.assertion.date_equals(datetime.datetime.now(), resolution_date,
                                   'bp resolution current date validation')
        page.click_on_save_button()
        self.verification.toaster.contains(validation_msg)

    def _edit_gird(self, value: str):
        page = self.page.activity_management.create_sam_activity.bp_engagement_details_subsection
        if not page.is_table_section_expanded():
            page.click_on_table_expand_button()
        page.click_table_edit_button(value)

    def _open_form(self):
        self.page.common.menu.open_sam_activity_management()
        page = self.page.activity_management.create_sam_activity.bp_engagement_details_subsection
        if not page.is_form_section_expanded():
            page.click_on_form_expand_button()

    pass
