from test_cases.test_fixture_base import TestFixtureBase


class TestFollowUpNeededSubsection(TestFixtureBase):
    # self.factory.page.activity_management.create_sam_activity.follow_up_needed_subsection
    # self.page.activity_management.create_sam_activity.follow_up_needed_subsection
    pass
