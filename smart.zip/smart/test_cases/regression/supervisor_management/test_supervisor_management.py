from test_cases.test_fixture_base import TestFixtureBase
from datetime import datetime
from utils import constants


class TestSupervisorManagement(TestFixtureBase):

    def test_search_button(self):
        self.page.common.menu.open_supervisor_management()
        search_form = self.factory.page.supervisor_management.supervisor_management_search.create_search()
        self.page.supervisor_management.supervisor_management_search.perform_search(search_form)
        self.verification.element.validate(search_form.user_name)
        pass

    def test_search_reset_button(self):
        self.page.common.menu.open_supervisor_management()
        before_reset = self.page.supervisor_management.supervisor_management_search.get_data()
        search_form = self.factory.page.supervisor_management.supervisor_management_search.create_search()
        self.page.supervisor_management.supervisor_management_search.perform_search(search_form)
        self.page.supervisor_management.supervisor_management_search.click_on_reset_button()
        after_reset = self.page.supervisor_management.supervisor_management_search.get_data()
        self.assertion.equals(before_reset, after_reset, 'Reset form data in search form')
        pass

    def test_search_edit_button(self):
        self.page.common.menu.open_supervisor_management()
        search_form = self.factory.page.supervisor_management.supervisor_management_search.create_search()
        self.page.supervisor_management.supervisor_management_search.perform_search(search_form)
        self.page.supervisor_management.supervisor_management_search.click_on_edit_button()
        edit_start_date = datetime.today().date().strftime(constants.DATE_FORMAT)
        self.page.supervisor_management.supervisor_management_add.enter_edit_details(edit_start_date)
        self.page.supervisor_management.supervisor_management_search.click_on_update_button()
        dialog_text = self.page.common.dialog.get_text()
        self.assertion.equals(f"User and Supervisor mapping updated "
                              f"successfully for the user: {search_form.user_full_name}", 
                              dialog_text, "Alert Confirmation Message")
        pass

    def test_add_button(self):
        self.page.common.menu.open_supervisor_management()
        self.page.supervisor_management.supervisor_management_search.click_on_add_button()
        header_title = self.page.supervisor_management.supervisor_management_add.get_header_text()
        self.assertion.equals('Supervisor Management | Add', header_title, 'Header title')
        pass

    def test_add_save_button(self):
        self.page.common.menu.open_supervisor_management()
        self.page.supervisor_management.supervisor_management_search.click_on_add_button()
        search_form = self.factory.page.supervisor_management.supervisor_management_add.create_add()
        self.page.supervisor_management.supervisor_management_add.add_supervisor(search_form)
        dialog_text = self.page.common.dialog.get_text()
        self.assertion.equals(f"User: {search_form.user_full_name} "
                              f"assigned with Supervisor : {search_form.supervisor_full_name} "
                              f"successfully", 
                              dialog_text, "Alert Confirmation Message")
        self.page.supervisor_management.supervisor_management_add.click_on_save_ok_button()
        pass

    def test_add_cancel_button(self):
        self.page.common.menu.open_supervisor_management()
        self.page.supervisor_management.supervisor_management_search.click_on_add_button()
        old_header_title = self.page.supervisor_management.supervisor_management_search.get_header_text()
        self.page.supervisor_management.supervisor_management_add.click_on_cancel_button()
        new_header_title = self.page.supervisor_management.supervisor_management_add.get_header_text()
        self.assertion.not_equals(old_header_title, new_header_title, 'Header title')
        pass

    def test_add_reset_button(self):
        self.page.common.menu.open_supervisor_management()
        self.page.supervisor_management.supervisor_management_search.click_on_add_button()
        before_reset = self.page.supervisor_management.supervisor_management_add.get_data()
        search_form = self.factory.page.supervisor_management.supervisor_management_add.create_add()
        self.page.supervisor_management.supervisor_management_add.enter_form(search_form)
        self.page.supervisor_management.supervisor_management_add.click_on_reset_button()
        after_reset = self.page.supervisor_management.supervisor_management_add.get_data()
        self.assertion.equals(before_reset, after_reset, 'Reset form data in search form')
        pass
