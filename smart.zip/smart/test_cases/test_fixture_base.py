import logging
from typing import List
import pytest
from core.driver_proxy import DriverProxy
from core.driver_element_proxy import DriverElementProxy
from instances.factories.factory_instance import FactoryInstance
from instances.pages.page_instance import PageInstance
from instances.verifications.verification_instance import VerificationInstance
from instances.workflows.workflow_instance import WorkflowInstance
from pages.page_base import PageBase
from utils.assertion import Assertion
import inspect
from verifications.verification_base import VerificationBase
from workflows.workflow_base import WorkflowBase


@pytest.mark.usefixtures("setup")
class TestFixtureBase:
    logger: logging.Logger
    driver: DriverProxy
    converter: DriverElementProxy
    assertion: Assertion = Assertion()
    page: PageInstance
    workflow: WorkflowInstance
    factory: FactoryInstance
    verification: VerificationInstance

    def set_logger(self, logger: logging.Logger):
        self.logger = logger
        self.driver.logger = self.logger
        self.converter.logger = self.logger
        self.assertion.logger = self.logger
        self._set_logger(self.page, PageBase, logger, list())
        self._set_logger(self.verification, VerificationBase, logger, list())
        self._set_logger(self.workflow, WorkflowBase, logger, list())
        pass

    @staticmethod
    def _set_logger(instance: any, type_ref: any, logger: logging.Logger, visitors: List[any]):
        if instance is None:
            pass

        current = instance
        properties = inspect.getmembers(current)
        visitors.append(current)
        for property_info in properties:
            name = property_info[0]
            if not name.startswith('_'):
                value = current.__getattribute__(name)
                if not visitors.__contains__(value):
                    TestFixtureBase._set_logger(value, type_ref, logger, visitors)
                    if hasattr(value, 'logger'):
                        value.logger = logger
