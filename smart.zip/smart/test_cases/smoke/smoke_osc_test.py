import pytest
from test_cases.test_fixture_base import TestFixtureBase


@pytest.mark.smoke
class TestSmokeOSC(TestFixtureBase):

    def test_scorecard_gen_page_load(self):
        self.page.common.menu.open_scorecard_generation()
        header = self.page.scorecard.scorecard_generation.get_header_title()
        self.assertion.equals("Scorecard Generation", header, "Scorecard Generation Page Name")
        self.driver.capture_screenshot_full('Scorecard_Generation')

    def test_scorecard_hist_page_load(self):
        self.page.common.menu.open_scorecard_history()
        header = self.page.scorecard.scorecard_history.get_header_title()
        self.assertion.equals("Scorecard History", header, "Scorecard History Page Name")
        self.driver.capture_screenshot_full('Scorecard_Generation_History')

    def test_group_mapping_page_load(self):
        self.page.common.menu.open_group_mapping()
        header = self.page.admin.group_mapping.get_header_title()
        self.assertion.equals("Group Mapping", header, "Group Mapping Page Name")
        self.driver.capture_screenshot_full('OSC_Group_Mapping')

    def test_frequency_configuration_page_load(self):
        self.page.common.menu.open_frequency_configuration()
        header = self.page.admin.frequency_configuration.get_header_title()
        self.assertion.equals("Frequency Configuration", header, "Frequency Configuration Page Name")
        self.driver.capture_screenshot_full('OSC_Frequency_Configuration')

    def test_scorecard_update_page_load(self):
        self.page.common.menu.open_scorecard_update()
        header = self.page.admin.scorecard_update.get_header_title()
        self.assertion.equals("Scorecard Update", header, "Scorecard Update Page Name")
        self.driver.capture_screenshot_full('OSC_Scorecard_Update')

    def test_notifications_configuration_page_load(self):
        self.page.common.menu.open_notifications_configuration()
        header = self.page.admin.notification_configuration_search.get_header_title()
        self.assertion.equals("Notifications-Configuration | Search", header, "Notifications Configuration Page Name")
        self.driver.capture_screenshot_full('OSC_Notifications_Configuration')
