import pytest
from test_cases.test_fixture_base import TestFixtureBase


@pytest.mark.smoke
class TestSmokeSmart(TestFixtureBase):

    def test_create_sam_request_page_load(self):
        self.page.common.menu.open_sam_request()
        self.driver.capture_screenshot_full('Create_SAM_Request')
        pass

    def test_create_crt_request_page_load(self):
        self.page.common.menu.open_crt_request()
        self.driver.capture_screenshot_full('Create_CRT_Request')
        pass

    def test_create_sam_activity_page_load(self):
        self.page.common.menu.open_sam_activity_management()
        self.driver.capture_screenshot_full('Create_SAM_Activity')
        pass

    def test_create_crt_projects_page_load(self):
        self.page.common.menu.open_crt_activity_management()
        self.driver.capture_screenshot_full('Create_CRT_Projects')
        pass
